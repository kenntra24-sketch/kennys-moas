# KENNY'S MOAS — Module d'Assistance Scolaire

Application d'organisation scolaire : cours, devoirs, notes, révisions, bibliothèque de fichiers, emploi du temps. Elle tourne **dans le navigateur, hors ligne** :
tes données restent sur ton appareil. Synchronisation Google Drive facultative. Version : `source/package.json` · historique : `CHANGELOG.md`.

## Ce que contient ce dépôt

| Où | Quoi |
|---|---|
| **`index.html`** (racine) | **L'application, déjà compilée.** Une seule page d'entrée. Avec `app.js`, `app.css`, `sw.js`, les icônes, `pdf.*.mjs`, `splash/`, `config.local.js`. |
| `legacy/index.html` | Page de la version d'origine, ouverte depuis Réglages → Google Drive → « synchronisation avancée » (fichiers, historique, Picker). |
| `LANCER.bat` + `serve.py` | Lancement local sous Windows (Python requis). |
| `source/` | Le code source (React + TypeScript) pour **modifier** l'appli. `source/index.html` est le fichier source de développement : ne l'ouvre pas, il s'affiche en blanc. |
| `docs/` | Documentation et notes de l'application d'origine. |

## Utiliser

- **Sur ton PC** : double-clique sur `LANCER.bat` → `http://127.0.0.1:8765` (les données de l'ancienne version, stockées pour cette adresse, sont retrouvées).
- **En ligne (GitHub Pages)** — voir ci-dessous.
- **Secours sans Python** : double-clique sur `index.html` (pas de lecteur PDF ni de mode hors-ligne dans ce mode).

## Mettre en ligne (GitHub Pages)

1. Sur GitHub : **Settings → Pages → Build and deployment → Source : « Deploy from a branch »**, branche `main`, dossier **`/ (root)`**, puis Save.
2. Après une minute, l'appli est sur `https://TON-PSEUDO.github.io/NOM-DU-DEPOT/`.
3. Pour que la connexion Google Drive marche en ligne, ajoute `https://TON-PSEUDO.github.io` (le domaine seul, sans le chemin) aux **origines JavaScript autorisées** de ton ID client dans Google Cloud Console.
4. Les données restent dans ton navigateur : elles ne sont pas partagées entre l'adresse en ligne et `127.0.0.1:8765` (utilise la sauvegarde/restauration Google Drive pour les transférer).

## Google Drive

Les identifiants (ID client OAuth + clé API) sont dans `config.local.js` (racine) et `source/public/config.local.js`, **inclus volontairement** (choix du propriétaire, usage personnel).
Si le dépôt est public, n'importe qui peut les lire : restreins la clé API dans Google Cloud (référents `http://127.0.0.1:8765/*`, `http://localhost:8765/*` et ton adresse GitHub Pages ; APIs Drive et Picker uniquement),
garde l'écran de consentement en mode Test avec ton compte comme seul utilisateur test, et si besoin supprime-les puis recrée-en. Configuration détaillée : `docs/legacy/SETUP.md`.

## Reconstruire l'application (une seule chaîne officielle)

La production utilise **un seul build : esbuild** (`source/tools/build-standalone.mjs`). Les versions d'esbuild, react et react-dom sont **figées** dans `source/package.json`.
L'ancienne chaîne Vite/Figma est archivée dans `source/figma-only/` : elle ne fonctionne pas hors de Figma et n'est pas utilisée.

**Normalement, tu n'as rien à compiler à la main** : tu modifies `source/`, tu pousses sur `main`, et GitHub Actions (`.github/workflows/build.yml`) fait seul : installation → build → copie à la racine → tests → vérification → publication. (Onglet **Actions** pour suivre.)

En local, si besoin :

```bash
cd source
corepack enable                      # une seule fois : active le pnpm fixé dans package.json (pnpm@10.34.3)
pnpm install --frozen-lockfile       # installe EXACTEMENT ce que dit pnpm-lock.yaml (échoue sinon)
pnpm run check                       # build + tests + vérification
# puis copier à la racine : source/public/* puis dist/{index.html,app.js,app.css,sw.js}
pnpm run verify:rebuild              # confirme que la racine correspond bien au source
```

- La **version du service worker (BUILD_ID) est calculée automatiquement** à chaque build : plus rien à incrémenter à la main.
- La **version du produit** est dans `source/package.json` (champ `version`) ; elle s'affiche en bas de Réglages.
- `pnpm run verify` contrôle des invariants (fichiers présents, chemins relatifs, artefacts issus du même build), pas des textes d'interface.
- **Un seul gestionnaire : pnpm** (version exacte dans `source/package.json`, champ `packageManager`). **Un seul verrou : `source/pnpm-lock.yaml`.** `package-lock.json` et `yarn.lock` sont interdits (`verify` échoue s'ils apparaissent). Le verrou de l'ancienne chaîne Figma est archivé sous un autre nom (`source/figma-only/pnpm-lock.ARCHIVE-figma-obsolete.yaml`) : il ne correspond plus au projet.
- **Le verrou `source/pnpm-lock.yaml` n'existe pas encore** dans ce zip (génération impossible sans réseau). Tant qu'il est absent, le workflow s'arrête avec un message explicite et rien n'est publié. Pour le créer sans terminal : onglet **Actions** → **Générer le verrou pnpm** → *Run workflow* (une seule fois). Ce workflow crée le verrou, prouve qu'il s'installe, le commite, puis lance de lui-même **Compiler, tester, publier** (nécessaire : un commit fait par un workflow ne déclenche pas les autres ; GitHub l'interdit, sauf lancement explicite). Ensuite il ne sert plus jamais : chaque push utilise le verrou commité. Ou, en local : `cd source && pnpm install` puis commiter `pnpm-lock.yaml`.
- **Statut réel** : la chaîne est cohérente et verrouillée par 52 tests, mais **n'a jamais été exécutée avec un vrai pnpm** (pas de réseau côté assistant). Elle ne sera dite « validée » qu'après un premier passage au vert de « Compiler, tester, publier » sur GitHub.
- Non couvert à ce jour : vérification des types TypeScript (jamais validée).

## Publier sur GitHub

```bash
git init                                   # une seule fois, à la racine du projet (le dossier qui contient index.html)
git add -A && git commit -m "P1 : liens, remarques, catégories, remplacement de fichier"
git branch -M main
git remote add origin https://github.com/TON-PSEUDO/NOM-DU-DEPOT.git
git push -u origin main
```

Puis sur GitHub : **Settings → Pages → Source : « Deploy from a branch »**, branche `main`, dossier **`/ (root)`** → Save. Adresse finale : `https://TON-PSEUDO.github.io/NOM-DU-DEPOT/` (une minute de délai). Pour les mises à jour suivantes : `git add -A && git commit -m "…" && git push`. Le fichier `.nojekyll` (déjà présent) doit rester à la racine.

## Modifier le code

Dans `source/` : `pnpm install --frozen-lockfile`, modifier `src/`, puis `pnpm run check`. Poussez sur `main` : le workflow republie. Voir `source/RELAIS-FUSION.md` et `source/REFONTE-UI-02.md` pour l'état d'avancement.
