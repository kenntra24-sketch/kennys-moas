import React, { useState, useEffect, useCallback } from 'react';
import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';
import SearchOverlay from './components/SearchOverlay';
import Dashboard from './views/Dashboard';
import Library from './views/Library';
import { HomeworkView, HomeworkForm } from './views/Homework';
import { GradesView, GradeForm } from './views/Grades';
import { ScheduleView, EventForm } from './views/Schedule';
import { ReviewsView } from './views/Reviews';
import { ErrorsView, ErrorForm } from './views/Errors';
import { GoalsView } from './views/Goals';
import { SettingsView, applyAppearance } from './views/Settings';
import { FaqView } from './views/StubViews';
import { AskHost, ChooseHost, ToastHost, AskText } from './components/ui';
import { useTimer, mmss, isActive, start as startTimer } from './lib/timer';
import { autoBackup, exportFull } from './lib/backup';
import { checkReminders } from './lib/reminders';
import { migrateFiles } from './lib/migrate';
import { checkIntegrity } from './lib/relations';
import { dbAll } from './lib/db';
import { getData, setData, useStore } from './lib/store';
import { ViewId, Theme } from './types';
import { useDriveStatus } from './lib/drive';
import {
  IcoHome, IcoBook, IcoHW, IcoCal, IcoGrades, IcoTimer, IcoLightbulb, IcoTarget,
} from './components/Icons';

const MOBILE_NAV: { id: ViewId; label: string; icon: React.ReactNode }[] = [
  { id: 'dashboard', label: 'Accueil', icon: <IcoHome size={20} /> },
  { id: 'library', label: 'Biblio', icon: <IcoBook size={20} /> },
  { id: 'homework', label: 'Devoirs', icon: <IcoHW size={20} /> },
  { id: 'schedule', label: 'Agenda', icon: <IcoCal size={20} /> },
  { id: 'grades', label: 'Notes', icon: <IcoGrades size={20} /> },
];

export default function App() {
  const [view, setView] = useState<ViewId>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem('km:theme') as Theme | null;
    return saved ?? 'light';
  });
  const [searchOpen, setSearchOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [createMenuOpen, setCreateMenuOpen] = useState(false);
  const driveStatus = useDriveStatus();
  const [form, setForm] = useState<null | 'hw' | 'grade' | 'event' | 'error'>(null);
  const [globalPrompt, setGlobalPrompt] = useState<null | 'subject' | 'goal'>(null);
  const timer = useTimer();
  useStore();
  const timerActive = timer.running || timer.rem !== timer.dur;
  const timerDisplay = mmss(timer.rem);
  void isActive;

  // Apparence personnalisée, sauvegarde automatique, rappels
  useEffect(() => {
    applyAppearance();
    /* Fichiers : catégorie (migration) puis réparation silencieuse des liens orphelins. Si la Bibliothèque est VIDE (stockage vidé/évincé par le navigateur,
       restauration à venir), on ne supprime AUCUN lien vers des fichiers : ils pourraient revenir avec une sauvegarde. */
    (async () => { try { await migrateFiles(); const all = await dbAll<{ id: string }>('files'); checkIntegrity(all.length ? new Set(all.map(f => f.id)) : null); } catch (e) { console.error('[MOAS] contrôle d’intégrité :', e); } })();
    autoBackup();
    const a = setInterval(() => autoBackup(), 30 * 60 * 1000);
    checkReminders();
    const r = setInterval(checkReminders, 60 * 1000);
    return () => { clearInterval(a); clearInterval(r); };
  }, []);

  // Apply theme
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.setAttribute('data-theme', 'dark');
    } else if (theme === 'light') {
      root.removeAttribute('data-theme');
    } else {
      const mq = window.matchMedia('(prefers-color-scheme: dark)');
      if (mq.matches) root.setAttribute('data-theme', 'dark');
      else root.removeAttribute('data-theme');
    }
    localStorage.setItem('km:theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(t => t === 'dark' ? 'light' : 'dark');
  };

  const runCommand = useCallback((cmd: string) => {
    if (cmd === 'add-homework') setForm('hw');
    else if (cmd === 'add-grade') setForm('grade');
    else if (cmd === 'add-event') setForm('event');
    else if (cmd === 'add-error') setForm('error');
    else if (cmd === 'add-subject') setGlobalPrompt('subject');
    else if (cmd === 'add-goal') setGlobalPrompt('goal');
    else if (cmd === 'pomodoro') { setView('reviews'); startTimer(); }
    else if (cmd === 'export') exportFull();
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setSearchOpen(s => !s);
      }
      const target = e.target as HTMLElement | null;
      const typing = target?.tagName === 'INPUT' || target?.tagName === 'TEXTAREA' || target?.tagName === 'SELECT' || target?.isContentEditable;
      if (!typing && e.key === '+' && !e.metaKey && !e.ctrlKey && !e.altKey) {
        e.preventDefault();
        setCreateMenuOpen(s => !s);
      }
      if (e.key === 'Escape') { setSearchOpen(false); setCreateMenuOpen(false); }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const handleNavigate = useCallback((v: string) => {
    const validViews: ViewId[] = ['dashboard', 'library', 'homework', 'schedule', 'grades', 'reviews', 'errors', 'goals', 'settings', 'faq'];
    if (validViews.includes(v as ViewId)) {
      setView(v as ViewId);
    }
  }, []);

  const breadcrumb = view === 'dashboard' ? [] : ['KENNY\'S MOAS'];

  return (
    <div className="app-shell">
      <Sidebar
        view={view}
        onView={v => { setView(v); setMobileMenuOpen(false); }}
        collapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed(s => !s)}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
      />

      <div className="main-wrap">
        <Topbar
          view={view}
          theme={theme}
          onTheme={toggleTheme}
          onSearch={() => setSearchOpen(true)}
          driveStatus={driveStatus}
          onDrive={() => setView('settings')}
          onTimer={() => setView('reviews')}
          timerActive={timerActive}
          timerDisplay={timerDisplay}
          breadcrumb={breadcrumb}
          onMobileMenu={() => setMobileMenuOpen(true)}
          createMenuOpen={createMenuOpen}
          onCreateMenu={setCreateMenuOpen}
          onCommand={runCommand}
          onNavigate={handleNavigate}
        />

        <main className="main-content">
          {/* Breadcrumb */}
          {view !== 'dashboard' && (
            <div className="breadcrumb">
              <span className="crumb" onClick={() => setView('dashboard')}>Tableau de bord</span>
              <span>›</span>
              <span className="crumb current">{VIEW_LABELS[view]}</span>
            </div>
          )}

          {/* Views */}
          {view === 'dashboard' && <Dashboard onView={setView} onCommand={runCommand} />}
          {view === 'library' && <Library onView={setView} />}
          {view === 'homework' && <HomeworkView />}
          {view === 'schedule' && <ScheduleView />}
          {view === 'grades' && <GradesView />}
          {view === 'reviews' && <ReviewsView />}
          {view === 'errors' && <ErrorsView />}
          {view === 'goals' && <GoalsView />}
          {view === 'settings' && <SettingsView theme={theme} onTheme={setTheme} />}
          {view === 'faq' && <FaqView />}
        </main>
      </div>

      {/* Mobile bottom nav */}
      <nav className="mobile-nav">
        {MOBILE_NAV.map(item => (
          <button
            key={item.id}
            className={`mobile-nav-btn${view === item.id ? ' active' : ''}`}
            onClick={() => setView(item.id)}
          >
            {item.icon}
            {item.label}
          </button>
        ))}
      </nav>

      {/* Search overlay */}
      {searchOpen && (
        <SearchOverlay
          onClose={() => setSearchOpen(false)}
          onNavigate={handleNavigate}
          onCommand={runCommand}
        />
      )}

      {form === 'hw' && <HomeworkForm onClose={() => setForm(null)} />}
      {form === 'grade' && <GradeForm onClose={() => setForm(null)} />}
      {form === 'event' && <EventForm onClose={() => setForm(null)} />}
      {form === 'error' && <ErrorForm onClose={() => setForm(null)} />}
      {globalPrompt === 'subject' && <AskText title="Nouvelle matière" label="Nom de la matière" onClose={() => setGlobalPrompt(null)} onOk={name => { const n = name.trim(); if (!n) return; const subjects = getData('subjects'); if (subjects.some(s => s.name.toLowerCase() === n.toLowerCase())) { import('./lib/toast').then(({ toast }) => toast('Cette matière existe déjà', 'warn')); return; } setData('subjects', [...subjects, { name: n, coef: 1 }]); import('./lib/toast').then(({ toast }) => toast('Matière ajoutée')); }} />}
      {globalPrompt === 'goal' && <AskText title="Objectif" label="Objectif de moyenne générale (/20)" type="number" initial={getData('goal') ?? 14} onClose={() => setGlobalPrompt(null)} onOk={value => { const n = parseFloat(value); if (!(n > 0 && n <= 20)) { import('./lib/toast').then(({ toast }) => toast('Valeur invalide (0–20)', 'warn')); return; } setData('goal', n); import('./lib/toast').then(({ toast }) => toast('Objectif enregistré')); }} />}
      <ToastHost />
      <AskHost />
      <ChooseHost />
    </div>
  );
}

const VIEW_LABELS: Record<ViewId, string> = {
  dashboard: 'Tableau de bord',
  library: 'Bibliothèque',
  homework: 'Devoirs',
  schedule: 'Emploi du temps',
  grades: 'Notes & Progression',
  reviews: 'Révisions',
  errors: 'Remarques',
  goals: 'Objectifs',
  settings: 'Réglages',
  faq: 'Aide & FAQ',
};
