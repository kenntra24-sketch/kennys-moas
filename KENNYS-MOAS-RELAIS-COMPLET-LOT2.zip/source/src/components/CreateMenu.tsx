import React, { useEffect, useRef } from 'react';
import {
  IcoPlus, IcoBook, IcoFile, IcoHW, IcoGrades, IcoCal, IcoTimer, IcoLightbulb, IcoTarget,
} from './Icons';
import { importFiles } from '../lib/files';

interface Props {
  open: boolean;
  onOpen: () => void;
  onClose: () => void;
  onCommand: (command: string) => void;
  onNavigate: (view: string) => void;
}

const ITEMS = [
  { label: 'Matière', hint: 'Créer une nouvelle matière', icon: <IcoBook size={17} />, tone: 'olive', action: 'command', value: 'add-subject' },
  { label: 'Fichier', hint: 'Importer un document ou une image', icon: <IcoFile size={17} />, tone: 'blue', action: 'file' },
  { label: 'Devoir', hint: 'Créer une nouvelle échéance', icon: <IcoHW size={17} />, tone: 'terracotta', action: 'command', value: 'add-homework' },
  { label: 'Note', hint: 'Enregistrer une note', icon: <IcoGrades size={17} />, tone: 'plum', action: 'command', value: 'add-grade' },
  { label: 'Événement', hint: 'Ajouter au calendrier', icon: <IcoCal size={17} />, tone: 'amber', action: 'command', value: 'add-event' },
  { label: 'Révision', hint: 'Lancer une session de travail', icon: <IcoTimer size={17} />, tone: 'sage', action: 'command', value: 'pomodoro' },
  { label: 'Erreur', hint: 'Enregistrer un point à revoir', icon: <IcoLightbulb size={17} />, tone: 'rose', action: 'command', value: 'add-error' },
  { label: 'Objectif', hint: 'Définir une cible de progression', icon: <IcoTarget size={17} />, tone: 'indigo', action: 'command', value: 'add-goal' },
] as const;

export default function CreateMenu({ open, onOpen, onClose, onCommand, onNavigate }: Props) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    const onPointer = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    };
    window.addEventListener('keydown', onKey);
    document.addEventListener('mousedown', onPointer);
    return () => {
      window.removeEventListener('keydown', onKey);
      document.removeEventListener('mousedown', onPointer);
    };
  }, [open, onClose]);

  const run = async (item: typeof ITEMS[number]) => {
    onClose();
    if (item.action === 'command') onCommand(item.value);
    else if (item.action === 'view') onNavigate(item.value);
    else {
      const input = document.createElement('input');
      input.type = 'file'; input.multiple = true; input.accept = '*/*';
      input.onchange = async () => {
        const files = Array.from(input.files || []);
        if (files.length) await importFiles(files);
      };
      input.click();
    }
  };

  return (
    <div className={`create-menu-wrap${open ? ' open' : ''}`} ref={ref}>
      <button className={`create-trigger${open ? ' open' : ''}`} onClick={onOpen} aria-expanded={open} aria-haspopup="menu">
        <span className="create-trigger-plus"><IcoPlus size={16} /></span>
        <span>Ajouter</span>
      </button>
      {open && (
        <div className="create-menu" role="menu">
          <div className="create-menu-head">
            <div>
              <div className="create-menu-title">Nouvel élément</div>
              <div className="create-menu-sub">Créer sans changer de page</div>
            </div>
            <div className="create-menu-kbd">+</div>
          </div>
          <div className="create-menu-grid">
            {ITEMS.map(item => (
              <button key={item.label} className="create-menu-item" role="menuitem" onClick={() => run(item)}>
                <span className={`create-menu-icon ${item.tone}`}>{item.icon}</span>
                <span className="create-menu-item-copy">
                  <strong>{item.label}</strong>
                  <small>{item.hint}</small>
                </span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
