import React, { useState, useRef } from 'react';
import { IcoUpload, IcoPdf, IcoImage, IcoFile, IcoSheet, IcoPresentation, IcoAudio } from './Icons';

interface Props {
  onFiles: (files: File[]) => void;
}

/* Types ENREGISTRÉS ; seuls PDF et images sont AFFICHABLES dans le lecteur (les autres se téléchargent). */
const ACCEPT_TYPES = [
  { label: 'PDF', icon: <IcoPdf size={13} /> },
  { label: 'Images', icon: <IcoImage size={13} /> },
  { label: 'Word', icon: <IcoFile size={13} /> },
  { label: 'Excel', icon: <IcoSheet size={13} /> },
  { label: 'PowerPoint', icon: <IcoPresentation size={13} /> },
  { label: 'Audio', icon: <IcoAudio size={13} /> },
];

export default function DropZone({ onFiles }: Props) {
  const [isDragOver, setIsDragOver] = useState(false);
  const [isDragActive, setIsDragActive] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const dragCounter = useRef(0);

  const handleDragEnter = (e: React.DragEvent) => {
    e.preventDefault();
    dragCounter.current++;
    setIsDragOver(true);
    setIsDragActive(true);
  };
  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    dragCounter.current--;
    if (dragCounter.current === 0) {
      setIsDragOver(false);
      setIsDragActive(false);
    }
  };
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    dragCounter.current = 0;
    setIsDragOver(false);
    setIsDragActive(false);
    const files = Array.from(e.dataTransfer.files);
    if (files.length) onFiles(files);
  };
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length) onFiles(files);
    e.target.value = '';
  };

  return (
    <div
      className={`drop-zone${isDragOver ? ' drag-over' : ''}`}
      onClick={() => inputRef.current?.click()}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={e => e.preventDefault()}
      onDrop={handleDrop}
    >
      <input
        ref={inputRef}
        type="file"
        multiple
        hidden
        accept="*/*"
        onChange={handleChange}
      />

      <div className="drop-zone-icon">
        <IcoUpload size={26} />
      </div>

      {isDragOver ? (
        <>
          <h3 style={{ color: 'var(--p)' }}>Dépose ici !</h3>
          <p>Tes fichiers vont être importés automatiquement.</p>
        </>
      ) : (
        <>
          <h3>Glisse tes fichiers ici</h3>
          <p>
            ou <span style={{ color: 'var(--p)', fontWeight: 700, textDecoration: 'underline' }}>parcourir</span> depuis ton ordinateur
          </p>
        </>
      )}

      <div className="drop-type-pills" onClick={e => e.stopPropagation()}>
        {ACCEPT_TYPES.map(t => (
          <span key={t.label} className="type-pill">
            <span className="type-pill-icon">{t.icon}</span>{t.label}
          </span>
        ))}
      </div>
      <p className="muted" style={{ fontSize: 12, marginTop: 8 }} onClick={e => e.stopPropagation()}>
        Tous ces types sont enregistrés. Pour l'instant, seuls les PDF et les images s'affichent dans l'application ; les autres se téléchargent.
      </p>
    </div>
  );
}
