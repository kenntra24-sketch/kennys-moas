import { memo, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { IcoBookmark, IcoBookmarkList, IcoChevronLeft, IcoChevronRight, IcoDownload, IcoFitPage, IcoFitWidth, IcoMinus, IcoMore, IcoNote, IcoPlus, IcoPrint, IcoUpDown, IcoX } from './Icons';
import { toast } from '../lib/toast';
import type { LibFile } from '../lib/db';
import { getRead, kindOf, loadPdfJs, patchFile, progressPct, saveRead } from '../lib/files';
import { download, todayISO, uid } from '../lib/util';
import { getData, setData, useStore } from '../lib/store';
import { getRelated, linkObjects, removeAllReferencesTo } from '../lib/relations';
import { GENRE_LABEL, REMARK_GENRES, type ErrorItem, type RemarkGenre } from '../lib/model';

/* Messages d'erreur PDF.js les plus courants, traduits pour l'utilisateur (diagnostic PHASE 1). */
function pdfErrorMessage(e: any): string {
  if (location.protocol === 'file:') return 'Le lecteur PDF nécessite de lancer l’app avec LANCER.bat (il ne fonctionne pas en ouvrant directement le fichier). Utilise « Télécharger » en attendant.';
  const name = e?.name || '';
  if (name === 'PasswordException') return 'Ce PDF est protégé par un mot de passe — il ne peut pas être affiché ici. Utilise « Télécharger ».';
  if (name === 'InvalidPDFException') return 'Ce fichier n’est pas un PDF valide (ou est corrompu). Utilise « Télécharger » pour vérifier.';
  if (name === 'MissingPDFException') return 'Le contenu du fichier est introuvable — réimporte-le dans la Bibliothèque.';
  return 'Impossible d’afficher ce PDF. Utilise « Télécharger » en attendant.';
}

/* Lecteur plein écran (v1.4.1, Phases 2-3) : PDF (PDF.js local, page rendue à la demande, reprise à la dernière page lue), images,
   sinon téléchargement. Portail sur <body> ; #root inert ; défilement de fond bloqué ; Échap/« Retour » ferment et rendent le focus.
   Remonté à chaque changement de fichier (`key={file.id}` côté appelant) : état toujours neuf.
   ZOOM (Phase 3) — même sens que l'app d'origine (magasin `read`, champ `zoom`) : multiplicateur de la largeur de la fenêtre de lecture,
   1 = « ajuster largeur » (affiché 100 %), plage 0,5–3, pas 0,15. « Ajuster page » calcule le multiplicateur qui fait tenir la page entière
   (champ optionnel `fit: 'width' | 'page'`, ré-appliqué au redimensionnement). Le champ `mode` (disposition) n'est pas touché. */
const ZMIN = 0.5, ZMAX = 3, ZSTEP = 0.15;
/* Une page du PDF : rendue seulement quand elle est proche de l'écran (IntersectionObserver), libérée quand elle s'éloigne (mémoire des mobiles).
   Le canvas et la couche de texte (sélection) vivent ici ; la taille CSS vient de la mise en page calculée par le lecteur. */
const GAP_ROOT_MARGIN = '120% 0px';
const PdfPage = memo(function PdfPage({ doc, index, w, h, scale, root, eager, reg }: { doc: any; index: number; w: number; h: number; scale: number; root: React.RefObject<HTMLDivElement | null>; eager: boolean; reg: (i: number, el: HTMLDivElement | null) => void }) {
  const box = useRef<HTMLDivElement>(null); const canvas = useRef<HTMLCanvasElement>(null); const text = useRef<HTMLDivElement>(null);
  const [vis, setVis] = useState(eager); const prev = useRef<any>(null);
  useEffect(() => {
    if (eager) { setVis(true); return; }
    const el = box.current; if (!el || typeof IntersectionObserver === 'undefined') { setVis(true); return; }
    const io = new IntersectionObserver(es => es.forEach(e => setVis(e.isIntersecting)), { root: root.current, rootMargin: GAP_ROOT_MARGIN });
    io.observe(el); return () => io.disconnect();
  }, [eager, root]);
  useEffect(() => {
    const c = canvas.current;
    if (!vis) { if (c) { c.width = 0; c.height = 0; } text.current?.replaceChildren(); return; }
    let dead = false; let task: any = null; let layer: any = null;
    const t = setTimeout(async () => {              // petit délai : un défilement rapide ne déclenche pas le rendu de toutes les pages traversées
      try {
        try { await prev.current?.promise; } catch { /* annulé */ }
        const p = await doc.getPage(index); if (dead || !c) return;
        let dpr = Math.min(window.devicePixelRatio || 1, 2);
        while (w * h * dpr * dpr > 16e6 && dpr > 0.5) dpr *= 0.8;   // plafond mémoire du canvas (mobiles)
        const vp = p.getViewport({ scale: scale * dpr });
        c.width = Math.round(vp.width); c.height = Math.round(vp.height); c.style.width = w + 'px'; c.style.height = h + 'px';
        task = p.render({ canvasContext: c.getContext('2d')!, viewport: vp }); prev.current = task;
        await task.promise; if (dead) return;
        try {
          const lib = await loadPdfJs(); const tl = text.current;
          if (tl && lib.TextLayer && !dead) {
            tl.replaceChildren(); tl.style.setProperty('--scale-factor', String(scale));
            layer = new lib.TextLayer({ textContentSource: p.streamTextContent(), container: tl, viewport: p.getViewport({ scale }) });
            await layer.render();
          }
        } catch (e: any) { if (!dead && e?.name !== 'AbortException') console.warn('[KENNY\'S MOAS] Couche de texte indisponible', index, e); }
      } catch (e: any) { if (!dead && e?.name !== 'RenderingCancelledException') console.error('[KENNY\'S MOAS] Échec du rendu de page PDF', index, e); }
    }, 60);
    return () => { dead = true; clearTimeout(t); task?.cancel?.(); layer?.cancel?.(); };
  }, [vis, scale, doc, index, w, h]);
  return <div className="rd-page" data-page={index} ref={el => { (box as any).current = el; reg(index, el); }} style={{ width: w, height: h }}><canvas ref={canvas} /><div className="textLayer" ref={text} /></div>;
});

const GAP = 10;
type Sz = { w: number; h: number };

const r2 = (n: number) => Math.round(n * 100) / 100;
const clampZ = (z: number) => Math.min(ZMAX, Math.max(ZMIN, r2(z)));

export function FileViewer({ file, onClose }: { file: LibFile; onClose: () => void }) {
  useStore();
  const kind = kindOf(file);
  const [url, setUrl] = useState(''); const [page, setPage] = useState(1); const [pages, setPages] = useState(0); const [err, setErr] = useState('');
  const [zoom, setZoom] = useState(1); const [fit, setFit] = useState<'width' | 'page' | null>('width');
  const [box, setBox] = useState({ w: 0, h: 0 }); const [marks, setMarks] = useState<{ p: number; label?: string }[]>([]); const [menu, setMenu] = useState(false); const [panel, setPanel] = useState(false); const [resumed, setResumed] = useState(0);
  const [pdfDoc, setPdfDoc] = useState<any>(null); const [sizes, setSizes] = useState<Sz[]>([]); const [continuous, setContinuous] = useState(true);
  /* Remarques depuis le lecteur */
  const [remOpen, setRemOpen] = useState(false); const [sel, setSel] = useState<{ text: string; page: number } | null>(null);
  const [rGenre, setRGenre] = useState<RemarkGenre>('à retenir'); const [rText, setRText] = useState(''); const [rPage, setRPage] = useState(1); const [rQuote, setRQuote] = useState(''); const [delAsk, setDelAsk] = useState('');
  const doc = useRef<any>(null); const stageRef = useRef<HTMLDivElement>(null); const root = useRef<HTMLDivElement>(null);
  const pageEls = useRef<(HTMLDivElement | null)[]>([]); const anchor = useRef({ page: 1, frac: 0 }); const lock = useRef(0); const raf = useRef(0);
  const pagesRef = useRef(0); pagesRef.current = pages; const closeRef = useRef(onClose); closeRef.current = onClose;
  const menuRef = useRef(false); menuRef.current = menu || panel || remOpen; const pageRef = useRef(1); pageRef.current = page;
  const fileIdRef = useRef(file.id); const lastPct = useRef(-1); const restored = useRef(false); const contRef = useRef(true); contRef.current = continuous;

  /* Mise en page : taille CSS de chaque page selon « ajuster largeur / page » ou le zoom (même sens que l'app d'origine : 1 = ajuster largeur). */
  const layout = useMemo(() => {
    if (!sizes.length || !box.w || !box.h) return null;
    const items = sizes.map(sz => {
      const base = box.w / sz.w;
      const ez = fit === 'page' ? Math.max(0.3, Math.min(1, (box.h / sz.h) / base)) : fit === 'width' ? 1 : zoom;
      const scale = base * ez; return { scale, ez: r2(ez), w: sz.w * scale, h: sz.h * scale };
    });
    return { items };
  }, [sizes, box.w, box.h, zoom, fit]);
  const shown = layout?.items[Math.min(page, layout.items.length) - 1]?.ez ?? zoom; const shownRef = useRef(1); shownRef.current = shown;

  const zoomBy = (d: number) => { setFit(null); setZoom(clampZ(shownRef.current + d)); };
  const fitWidth = () => { setFit('width'); setZoom(1); };
  const fitPage = () => setFit('page');
  /* Aller à une page : en défilement continu on fait défiler jusqu'à elle ; `lock` empêche le détecteur de défilement de « corriger » aussitôt le numéro. */
  const goto = (p: number) => {
    const n = Math.min(Math.max(1, p), Math.max(pagesRef.current, 1)); setPanel(false); setPage(n);
    if (contRef.current) { anchor.current = { page: n, frac: 0 }; lock.current = Date.now() + 500; const el = pageEls.current[n - 1]; if (el && stageRef.current) stageRef.current.scrollTop = Math.max(0, el.offsetTop - 8); }
  };
  const gotoRef = useRef(goto); gotoRef.current = goto;
  const reg = useRef((i: number, el: HTMLDivElement | null) => { pageEls.current[i - 1] = el; }).current;

  /* Mode lecture : #root inerte, pas de défilement de fond, focus restitué à la fermeture ; clavier. */
  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    const app = document.getElementById('root');
    app?.setAttribute('inert', ''); document.body.classList.add('noscroll');
    root.current?.querySelector<HTMLElement>('[data-autofocus]')?.focus();
    const key = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); if (menuRef.current) { setMenu(false); setPanel(false); setRemOpen(false); } else closeRef.current(); }
      else if (e.ctrlKey || e.metaKey || e.altKey || tag === 'TEXTAREA' || tag === 'INPUT' || tag === 'SELECT') return;
      else if (e.key === 'ArrowRight' || (!contRef.current && e.key === 'PageDown')) gotoRef.current(pageRef.current + 1);
      else if (e.key === 'ArrowLeft' || (!contRef.current && e.key === 'PageUp')) gotoRef.current(pageRef.current - 1);
      else if (e.key === '+' || e.key === '=') zoomBy(ZSTEP);
      else if (e.key === '-') zoomBy(-ZSTEP);
      else if (e.key === '0') fitWidth();
    };
    window.addEventListener('keydown', key);
    return () => {
      window.removeEventListener('keydown', key); app?.removeAttribute('inert'); document.body.classList.remove('noscroll'); prev?.focus?.();
      /* Sauvegarde finale à la fermeture — seulement si le PDF a bien été chargé, pour ne jamais écraser la position avec la page 1 par défaut. */
      if (pagesRef.current > 0 && restored.current) { const pg = pageRef.current, n = pagesRef.current;
        saveRead(fileIdRef.current, { page: pg }).then(() => patchFile(fileIdRef.current, { progress: progressPct(pg, n) })).catch(() => {}); }
    };
  }, []);

  /* Taille utile de la fenêtre de lecture (anti-rebond 300 ms sur redimensionnement). */
  useEffect(() => {
    const el = stageRef.current; if (!el) return;
    const measure = () => { const cs = getComputedStyle(el); setBox({ w: Math.max(0, el.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight)), h: Math.max(0, el.clientHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom)) }); };
    measure(); let t: any; const ro = new ResizeObserver(() => { clearTimeout(t); t = setTimeout(measure, 300); }); ro.observe(el);
    return () => { clearTimeout(t); ro.disconnect(); };
  }, []);

  useEffect(() => { if (kind === 'image') { const u = URL.createObjectURL(file.blob); setUrl(u); return () => URL.revokeObjectURL(u); } }, [file, kind]);
  useEffect(() => {
    if (kind !== 'pdf') return;
    let dead = false;
    (async () => {
      try {
        const lib = await loadPdfJs();
        const buf = await file.blob.arrayBuffer();
        if (dead) return;
        const d = await lib.getDocument({ data: buf }).promise;
        if (dead) { d.destroy?.(); return; }
        /* Reprise : page/zoom/marque-pages/disposition lus dans le magasin `read` (et non `files.progress`, qui est un pourcentage). */
        let rec: any = null; try { rec = await getRead(file.id); } catch { /* reprise facultative */ }
        if (dead) { d.destroy?.(); return; }
        /* Dimensions de toutes les pages (par lots) : nécessaires pour réserver la place de chaque page dans le défilement continu. */
        const sz: Sz[] = new Array(d.numPages);
        for (let i = 1; i <= d.numPages && !dead; i += 16) {
          await Promise.all(Array.from({ length: Math.min(16, d.numPages - i + 1) }, async (_, k) => { const pg = await d.getPage(i + k); const v = pg.getViewport({ scale: 1 }); sz[i + k - 1] = { w: v.width, h: v.height }; pg.cleanup?.(); }));
        }
        if (dead) { d.destroy?.(); return; }
        if (typeof rec?.zoom === 'number' && isFinite(rec.zoom)) setZoom(clampZ(rec.zoom));
        setFit(rec?.fit === 'page' ? 'page' : rec?.fit === 'width' || !rec?.zoom || Math.abs(rec.zoom - 1) < 0.005 ? 'width' : null);
        if (Array.isArray(rec?.bookmarks)) setMarks(rec.bookmarks);
        const startAt = Math.min(Math.max(1, rec?.page || 1), d.numPages);
        anchor.current = { page: startAt, frac: 0 };
        doc.current = d; restored.current = true; setContinuous(rec?.continuous !== false); setSizes(sz); setPdfDoc(d); setPage(startAt); setPages(d.numPages); if (startAt > 1) setResumed(startAt);
      } catch (e) {
        console.error('[KENNY\'S MOAS] Échec du chargement du PDF', file.name, e);
        if (!dead) setErr(pdfErrorMessage(e));
      }
    })();
    return () => { dead = true; doc.current?.destroy?.(); doc.current = null; };
  }, [file, kind]);

  /* Défilement continu : (1) à chaque changement de mise en page, on retrouve l'endroit qu'on lisait (page + fraction) ;
     (2) au défilement, on déduit la page affichée et on mémorise l'ancre. */
  useLayoutEffect(() => {
    const st = stageRef.current; if (!st || !layout || !continuous) return;
    const a = anchor.current; const el = pageEls.current[a.page - 1];
    if (el) st.scrollTop = Math.max(0, el.offsetTop + a.frac * el.offsetHeight - 8);
  }, [layout, continuous]);
  useEffect(() => { if (!continuous) stageRef.current?.scrollTo?.({ top: 0 }); }, [page, continuous]);
  const onScroll = () => {
    if (raf.current || !contRef.current) return;
    raf.current = requestAnimationFrame(() => {
      raf.current = 0; const st = stageRef.current; const els = pageEls.current; if (!st || !contRef.current || !els.length) return;
      const find = (y: number) => { let lo = 0, hi = els.length - 1, ans = 0; while (lo <= hi) { const m = (lo + hi) >> 1; const el = els[m]; if (!el) { hi = m - 1; continue; } if (el.offsetTop <= y) { ans = m; lo = m + 1; } else hi = m - 1; } return ans; };
      const ti = find(st.scrollTop + 8); const te = els[ti];
      if (te) anchor.current = { page: ti + 1, frac: Math.max(0, Math.min(1, (st.scrollTop + 8 - te.offsetTop) / Math.max(1, te.offsetHeight))) };
      if (Date.now() > lock.current) { const n = find(st.scrollTop + st.clientHeight * 0.3) + 1; if (n !== pageRef.current) setPage(n); }
    });
  };
  const toggleLayout = () => { const next = !continuous; if (next) anchor.current = { page: pageRef.current, frac: 0 }; setContinuous(next); toast(next ? 'Défilement continu' : 'Page par page'); };

  /* Sauvegarde de la position (anti-rebond) : page, zoom, ajustement, disposition. */
  useEffect(() => {
    if (!pages || !restored.current) return;
    const t = setTimeout(() => {
      saveRead(file.id, { page, zoom: r2(shown), fit: fit || undefined, continuous })
        .then(() => { const pct = progressPct(page, pages); if (pct !== lastPct.current) { lastPct.current = pct; return patchFile(file.id, { progress: pct }); } }).catch(() => {});
    }, 600);
    return () => clearTimeout(t);
  }, [page, pages, zoom, fit, continuous, shown]);

  useEffect(() => { if (resumed && page !== resumed) setResumed(0); }, [page]);
  useEffect(() => { if (!resumed) return; const t = setTimeout(() => setResumed(0), 8000); return () => clearTimeout(t); }, [resumed]);
  const removeMark = async (idx: number) => { const next = marks.filter((_, i) => i !== idx); setMarks(next); await saveRead(file.id, { bookmarks: next }); };
  const marked = marks.some(m => m.p === page);
  const toggleMark = async () => {
    const next = marked ? marks.filter(m => m.p !== page) : [...marks, { p: page, label: `Page ${page}` }].sort((a, b) => a.p - b.p);
    setMarks(next); await saveRead(file.id, { bookmarks: next });
    toast(marked ? `Marque-page retiré (page ${page})` : `Marque-page ajouté (page ${page})`);
  };
  /* Impression : on ouvre le fichier dans un nouvel onglet (l'impression du canvas interne est de mauvaise qualité). */
  const print = () => {
    setMenu(false);
    const u = URL.createObjectURL(file.blob); const w = window.open(u, '_blank');
    if (!w) { toast('Le navigateur a bloqué l’ouverture — autorise les fenêtres pop-up puis réessaie.', 'warn'); URL.revokeObjectURL(u); return; }
    setTimeout(() => URL.revokeObjectURL(u), 120000);
  };

  /* ── Remarques : texte sélectionné dans le PDF (mémorisé, avec sa page) ; remarques du fichier = liens `remark ↔ file` portant la page ── */
  useEffect(() => {
    const on = () => {
      const s = window.getSelection(); const t = (s?.toString() || '').replace(/\s+/g, ' ').trim(); if (!t) return;
      const n = s?.anchorNode; const el = n && (n.nodeType === 1 ? (n as Element) : n.parentElement); const pg = el?.closest?.('.rd-page');
      if (pg && stageRef.current?.contains(pg)) setSel({ text: t.slice(0, 400), page: Number(pg.getAttribute('data-page')) || pageRef.current });
    };
    document.addEventListener('selectionchange', on); return () => document.removeEventListener('selectionchange', on);
  }, []);
  const allErrors = getData('errors');
  const fileRemarks = (getRelated({ type: 'file', id: file.id }).remark || []).map(l => ({ page: l.page, e: allErrors.find(e => e.id === l.id) })).filter((x): x is { page: number | undefined; e: ErrorItem } => !!x.e).sort((a, b) => (a.page ?? 0) - (b.page ?? 0));
  const openRemark = () => { setPanel(false); setMenu(false); setRPage(sel?.page ?? pageRef.current); setRQuote(sel?.text || ''); setRemOpen(true); };
  const saveRemark = () => {
    const text = rText.trim(); if (!text) { toast('Écris ta remarque', 'warn'); return; }
    const pg = Math.min(Math.max(1, Math.round(rPage) || 1), Math.max(pages, 1)); const id = uid();
    const rec: ErrorItem = { id, subject: file.subject || getData('subjects')[0]?.name || '', chapter: '', question: rGenre === 'erreur' ? rQuote : '', mistake: rGenre === 'erreur' ? text : '', method: '', fileId: file.id, linkType: 'file', linkId: file.id,
      date: todayISO(), boite: 0, prochaineRevision: todayISO(), links: [], source: { type: 'file', id: file.id, page: pg }, genre: rGenre, texte: text, quote: rQuote || undefined };
    setData('errors', [...getData('errors'), rec]);
    linkObjects({ type: 'remark', id }, { type: 'file', id: file.id }, { page: pg });
    setRText(''); setRQuote(''); setSel(null); window.getSelection()?.removeAllRanges(); toast(`Remarque ajoutée (page ${pg})`);
  };
  const deleteRemark = (id: string) => {
    if (delAsk !== id) { setDelAsk(id); return; }
    const snap = getData('errors'); const refs = removeAllReferencesTo({ type: 'remark', id });
    setData('errors', getData('errors').filter(e => e.id !== id)); setDelAsk('');
    toast('Remarque supprimée', 'ok', { label: 'Annuler', cb: () => { setData('errors', snap); refs.undo(); } });
  };

  const nav = kind === 'pdf' && pages > 0;
  const showPages = nav && layout && pdfDoc ? (continuous ? layout.items.map((_, i) => i) : [Math.min(page, layout.items.length) - 1]) : [];
  return createPortal(
    <div className={`reader${remOpen ? ' has-rem' : ''}`} role="dialog" aria-modal="true" aria-label={`Lecture : ${file.name}`} ref={root}>
      <header className="rd-bar">
        <button className="btn ghost sm rd-back" onClick={onClose} data-autofocus aria-label="Retour à la Bibliothèque"><IcoChevronLeft size={16} /><span>Retour</span></button>
        <div className="rd-title"><div className="rd-name" title={file.name}>{file.name}</div>{file.subject && <div className="rd-sub">{file.subject}</div>}</div>
        {nav && <div className="rd-pager">
          <button className="icon-btn" disabled={page <= 1} onClick={() => goto(page - 1)} aria-label="Page précédente"><IcoChevronLeft size={16} /></button>
          <span className="rd-pageno" aria-live="polite">Page {page} / {pages}</span>
          <button className="icon-btn" disabled={page >= pages} onClick={() => goto(page + 1)} aria-label="Page suivante"><IcoChevronRight size={16} /></button>
        </div>}
        <div className="rd-more">
          <button className="icon-btn" onClick={() => { setPanel(false); setMenu(m => !m); }} aria-label="Plus d’actions" aria-haspopup="menu" aria-expanded={menu}><IcoMore size={16} /></button>
          {menu && <><div className="rd-menu-bg" onClick={() => setMenu(false)} />
            <div className="rd-menu" role="menu">
              {(kind === 'pdf' || kind === 'image') && <button role="menuitem" onClick={print}><IcoPrint size={15} />Imprimer</button>}
              <button role="menuitem" onClick={() => { setMenu(false); download(file.name, file.blob); }}><IcoDownload size={15} />Télécharger</button>
            </div></>}
        </div>
      </header>
      {nav && <div className="rd-tools" role="toolbar" aria-label="Affichage">
        <button className="icon-btn" onClick={() => zoomBy(-ZSTEP)} disabled={shown <= ZMIN} aria-label="Réduire le zoom"><IcoMinus size={15} /></button>
        <span className="rd-zoom" aria-live="polite">{Math.round(shown * 100)} %</span>
        <button className="icon-btn" onClick={() => zoomBy(ZSTEP)} disabled={shown >= ZMAX} aria-label="Augmenter le zoom"><IcoPlus size={15} /></button>
        <span className="rd-sep" />
        <button className={`icon-btn${fit === 'width' ? ' on' : ''}`} onClick={fitWidth} aria-pressed={fit === 'width'} aria-label="Ajuster à la largeur" title="Ajuster à la largeur"><IcoFitWidth size={16} /></button>
        <button className={`icon-btn${fit === 'page' ? ' on' : ''}`} onClick={fitPage} aria-pressed={fit === 'page'} aria-label="Ajuster à la page" title="Ajuster à la page"><IcoFitPage size={16} /></button>
        <button className={`icon-btn${continuous ? ' on' : ''}`} onClick={toggleLayout} aria-pressed={continuous} aria-label="Défilement continu" title={continuous ? 'Défilement continu (cliquer pour passer en page par page)' : 'Page par page (cliquer pour défiler en continu)'}><IcoUpDown size={16} /></button>
        <span className="rd-sep" />
        <button className={`icon-btn${marked ? ' on' : ''}`} onClick={toggleMark} aria-pressed={marked} aria-label={marked ? 'Retirer le marque-page' : 'Ajouter un marque-page'} title="Marque-page"><IcoBookmark size={16} style={marked ? { fill: 'currentColor' } : undefined} /></button>
        <div className="rd-bm">
          <button className={`icon-btn${panel ? ' on' : ''}`} onClick={() => { setMenu(false); setPanel(v => !v); }} aria-expanded={panel} aria-haspopup="dialog" aria-label={`Marque-pages (${marks.length})`} title="Marque-pages"><IcoBookmarkList size={16} />{marks.length > 0 && <span className="rd-badge">{marks.length}</span>}</button>
          {panel && <><div className="rd-menu-bg" onClick={() => setPanel(false)} />
            <div className="rd-panel" role="dialog" aria-label="Marque-pages">
              <h3>Marque-pages</h3>
              {marks.length === 0 ? <p className="muted">Aucun marque-page. Utilise le bouton marque-page pour retenir une page.</p>
                : <ul>{marks.map((m, i) => <li key={`${m.p}-${i}`}>
                    <button className="rd-bm-go" onClick={() => goto(m.p)} aria-current={m.p === page ? 'page' : undefined}><span>{m.label || `Page ${m.p}`}</span><span className="muted">p.{m.p}</span></button>
                    <button className="icon-btn" onClick={() => removeMark(i)} aria-label={`Supprimer le marque-page ${m.label || `page ${m.p}`}`}><IcoX size={14} /></button>
                  </li>)}</ul>}
            </div></>}
        </div>
        <button className={`icon-btn${remOpen ? ' on' : ''}`} onClick={() => (remOpen ? setRemOpen(false) : openRemark())} aria-expanded={remOpen} aria-label={`Remarques sur ce fichier (${fileRemarks.length})`} title="Remarques sur ce fichier"><IcoNote size={16} />{fileRemarks.length > 0 && <span className="rd-badge">{fileRemarks.length}</span>}</button>
      </div>}
      {resumed > 0 && <div className="rd-resume" role="status"><span>Reprise à la page {resumed}.</span><button className="btn ghost sm" onClick={() => { setResumed(0); goto(1); }}>Depuis le début</button><button className="icon-btn" onClick={() => setResumed(0)} aria-label="Fermer"><IcoX size={14} /></button></div>}
      {nav && sel && !remOpen && <div className="rd-selpill" role="status"><button className="btn sm" onClick={openRemark}><IcoNote size={14} /> Remarque sur la sélection (p. {sel.page})</button><button className="icon-btn" onClick={() => setSel(null)} aria-label="Ignorer la sélection"><IcoX size={14} /></button></div>}
      <div className="rd-body">
      <div className="rd-stage" ref={stageRef} onScroll={onScroll}>
        {err ? <p className="muted rd-msg">{err}</p>
          : kind === 'pdf' ? (showPages.length ? showPages.map(i => { const it = layout!.items[i]; return <PdfPage key={i} doc={pdfDoc} index={i + 1} w={it.w} h={it.h} scale={it.scale} root={stageRef} eager={!continuous} reg={reg} />; }) : <p className="muted rd-msg">Chargement…</p>)
          : kind === 'image' ? <img src={url} alt={file.name} />
          : <p className="muted rd-msg">Ce type de fichier est bien enregistré dans ta bibliothèque, mais l'application ne sait pas encore l'afficher (seuls les PDF et les images s'ouvrent pour l'instant). Utilise « Télécharger » pour l'ouvrir dans une autre application.</p>}
      </div>
      {remOpen && <aside className="rd-rem" aria-label="Remarques sur ce fichier">
        <div className="row spread"><h3>Remarques</h3><button className="icon-btn" onClick={() => setRemOpen(false)} aria-label="Fermer le panneau"><IcoX size={15} /></button></div>
        <div className="rd-rem-form">
          {rQuote && <div className="rd-quote"><span>« {rQuote.length > 160 ? rQuote.slice(0, 160) + '…' : rQuote} »</span><button className="icon-btn" onClick={() => setRQuote('')} aria-label="Retirer le passage"><IcoX size={12} /></button></div>}
          <div className="row" style={{ gap: 8 }}>
            <select className="input" value={rGenre} onChange={e => setRGenre(e.target.value as RemarkGenre)} aria-label="Genre de la remarque">{REMARK_GENRES.map(g => <option key={g} value={g}>{GENRE_LABEL[g]}</option>)}</select>
            <label className="row" style={{ gap: 4, fontSize: 12.5, flex: 'none' }}>p. <input className="input" type="number" min={1} max={pages} style={{ width: 64 }} value={rPage} onChange={e => setRPage(Number(e.target.value))} aria-label="Page de la remarque" /></label>
          </div>
          <textarea className="input" rows={3} placeholder="Ma remarque sur cette page…" value={rText} onChange={e => setRText(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) saveRemark(); }} />
          <div className="row spread"><button className="btn ghost sm" onClick={() => setRPage(page)}>Page affichée ({page})</button><button className="btn sm" onClick={saveRemark}>Ajouter</button></div>
        </div>
        <div className="rd-rem-list">
          {fileRemarks.length === 0 ? <p className="muted">Aucune remarque sur ce fichier. Sélectionne un passage du PDF puis appuie sur « Remarque sur la sélection », ou écris-la ici.</p>
            : fileRemarks.map(({ page: pg, e }) => <div key={e.id} className="rd-rem-item">
                <button className="rd-rem-go" onClick={() => pg && goto(pg)} title="Aller à la page">
                  <span className="row" style={{ gap: 6 }}><span className="badge">{pg ? `p.${pg}` : 'fichier'}</span><span className="badge">{GENRE_LABEL[(e.genre || 'erreur') as RemarkGenre]}</span></span>
                  {typeof e.quote === 'string' && e.quote && <em className="muted">« {e.quote.length > 90 ? e.quote.slice(0, 90) + '…' : e.quote} »</em>}
                  <span>{e.texte || e.mistake || e.question}</span>
                </button>
                <button className={`btn sm ${delAsk === e.id ? 'danger' : 'ghost'}`} onClick={() => deleteRemark(e.id)} onBlur={() => setDelAsk('')}>{delAsk === e.id ? 'Confirmer ?' : 'Supprimer'}</button>
              </div>)}
        </div>
      </aside>}
      </div>
    </div>, document.body);
}
