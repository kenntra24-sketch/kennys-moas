import React from 'react';

type IconProps = { size?: number; strokeWidth?: number; className?: string; style?: React.CSSProperties };
const Ico = (paths: string) => ({ size = 18, strokeWidth = 1.9, className = '', style }: IconProps) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
    strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" className={className} style={style}>
    <g dangerouslySetInnerHTML={{ __html: paths }} />
  </svg>
);

export const IcoHome = Ico('<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1z" fill="currentColor" fill-opacity=".18"/><path d="M9.5 21v-6.5h5V21"/>');
export const IcoBook = Ico('<path d="M12 6.5C10.5 5 8 4.5 4 4.5v13c4 0 6.5.5 8 2 1.5-1.5 4-2 8-2v-13c-4 0-6.5.5-8 2z" fill="currentColor" fill-opacity=".18"/><path d="M12 6.5v13"/>');
export const IcoHW = Ico('<rect x="5" y="4" width="14" height="17" rx="2" fill="currentColor" fill-opacity=".18"/><path d="M9 3h6v3H9z"/><path d="m9 13.5 2.2 2.2L15.5 11"/>');
export const IcoCal = Ico('<rect x="3.5" y="5" width="17" height="16" rx="2.5" fill="currentColor" fill-opacity=".18"/><path d="M8 3v4M16 3v4M3.5 10h17"/><circle cx="8.5" cy="14.5" r=".9" fill="currentColor"/><circle cx="12" cy="14.5" r=".9" fill="currentColor"/><circle cx="15.5" cy="14.5" r=".9" fill="currentColor"/><circle cx="8.5" cy="18" r=".9" fill="currentColor"/>');
export const IcoGrades = Ico('<rect x="4" y="12" width="4" height="8" rx="1" fill="currentColor" fill-opacity=".18"/><rect x="10" y="7" width="4" height="13" rx="1" fill="currentColor" fill-opacity=".18"/><rect x="16" y="3" width="4" height="17" rx="1" fill="currentColor" fill-opacity=".18"/><path d="M3 21h18"/>');
export const IcoTimer = Ico('<circle cx="12" cy="13.5" r="7.5" fill="currentColor" fill-opacity=".18"/><path d="M12 9.5v4l2.5 2M10 2.5h4M12 2.5v3.5M18.5 6.5l1.2-1.2"/>');
export const IcoLightbulb = Ico('<path d="M12 2.5a6.5 6.5 0 0 0-3.8 11.8c.5.4.8 1 .8 1.7v.5h6V16c0-.7.3-1.3.8-1.7A6.5 6.5 0 0 0 12 2.5z" fill="currentColor" fill-opacity=".18"/><path d="M9.5 19.5h5M10.5 22h3"/>');
export const IcoTarget = Ico('<circle cx="12" cy="12" r="9" fill="currentColor" fill-opacity=".18"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/><path d="m16 8 5-5M18.5 3H21v2.5"/>');
export const IcoSettings = Ico('<path d="M4 7h9M17 7h3M4 17h3M11 17h9M4 12h3M11 12h9"/><circle cx="15" cy="7" r="2" fill="currentColor" fill-opacity=".18"/><circle cx="9" cy="17" r="2" fill="currentColor" fill-opacity=".18"/><circle cx="9" cy="12" r="2" fill="currentColor" fill-opacity=".18"/>');
export const IcoHelp = Ico('<circle cx="12" cy="12" r="9.5" fill="currentColor" fill-opacity=".18"/><path d="M9.2 9.2a3 3 0 0 1 5.6 1.2c0 1.9-2.8 2.4-2.8 4"/><circle cx="12" cy="17.5" r=".9" fill="currentColor"/>');
export const IcoSearch = Ico('<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>');
export const IcoPlus = Ico('<path d="M12 5v14M5 12h14"/>');
export const IcoUpload = Ico('<path d="M12 3v12"/><path d="m7 8 5-5 5 5"/><path d="M4 21h16"/>');
export const IcoGrid = Ico('<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>');
export const IcoList = Ico('<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>');
export const IcoChevronLeft = Ico('<path d="m15 18-6-6 6-6"/>');
export const IcoChevronRight = Ico('<path d="m9 18 6-6-6-6"/>');
export const IcoMoon = Ico('<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>');
export const IcoSun = Ico('<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>');
/* Sauvegarde Drive : nuage + flèche vers le haut (le triangle Google n'était pas compris). Le nom IcoDrive est gardé pour les imports existants. */
export const IcoCloudUp = Ico('<path d="M7 18a4.5 4.5 0 0 1-.6-8.96A6 6 0 0 1 17.9 8.6 4.7 4.7 0 0 1 17 18"/><path d="M12 21v-8"/><path d="m8.8 15.6 3.2-3.2 3.2 3.2"/>');
export const IcoDrive = IcoCloudUp;
export const IcoFile = Ico('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/>');

export const IcoDownload = Ico('<path d="M12 3v11"/><path d="m7 10 5 5 5-5"/><path d="M4 21h16"/>');
export const IcoEdit = Ico('<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L8 18l-4 1 1-4Z"/>');
export const IcoTrash = Ico('<path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 15H6L5 6"/><path d="M10 11v6M14 11v6"/>');
export const IcoPdf = Ico('<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/><path d="M8 15h2.5a1.5 1.5 0 0 0 0-3H8v6m5 0 2.5-3-2.5-3"/>');
export const IcoImage = Ico('<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>');
export const IcoSheet = Ico('<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h8"/>');
export const IcoPresentation = Ico('<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M12 16v4M8 20h8"/>');
export const IcoAudio = Ico('<path d="M7 18V8l10-3v10"/><circle cx="5" cy="18" r="3"/><circle cx="15" cy="15" r="3"/>');

export const IcoClose = Ico('<path d="M18 6 6 18"/><path d="m6 6 12 12"/>');
export const IcoMenu = Ico('<line x1="4" y1="7" x2="20" y2="7"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="17" x2="20" y2="17"/>');
export const IcoArrowRight = Ico('<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>');
export const IcoStar = Ico('<path d="m12 2.5 2.9 5.9 6.5.9-4.7 4.6 1.1 6.5L12 17.3 6.2 20.4l1.1-6.5L2.6 9.3l6.5-.9z"/>');

export const IcoMinus = Ico('<path d="M5 12h14"/>');
export const IcoFitWidth = Ico('<path d="M3 5v14M21 5v14"/><path d="M7 12h10"/><path d="m10 9-3 3 3 3M14 9l3 3-3 3"/>');
export const IcoFitPage = Ico('<path d="M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M8 21H5a2 2 0 0 1-2-2v-3M16 21h3a2 2 0 0 0 2-2v-3"/><rect x="8" y="7" width="8" height="10" rx="1"/>');
export const IcoPrint = Ico('<path d="M6 9V3h12v6"/><path d="M6 18H4a1 1 0 0 1-1-1v-6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v6a1 1 0 0 1-1 1h-2"/><rect x="6" y="14" width="12" height="7" rx="1"/>');
export const IcoBookmark = Ico('<path d="M6 3h12a1 1 0 0 1 1 1v17l-7-4-7 4V4a1 1 0 0 1 1-1z"/>');
export const IcoMore = Ico('<circle cx="5" cy="12" r="1.3"/><circle cx="12" cy="12" r="1.3"/><circle cx="19" cy="12" r="1.3"/>');
export const IcoBookmarkList = Ico('<path d="M9 4h9a1 1 0 0 1 1 1v14"/><path d="M5 6a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v14l-4-2.5L5 20V6z"/>');
export const IcoX = Ico('<path d="M6 6l12 12M18 6 6 18"/>');
export const IcoNote = Ico('<path d="M5 4.5h14a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1h-8l-4.5 3.5v-3.5H5a1 1 0 0 1-1-1v-10a1 1 0 0 1 1-1z" fill="currentColor" fill-opacity=".18"/><path d="M8 9h8M8 12.5h5"/>');
export const IcoUpDown = Ico('<path d="M12 3v18M8 7l4-4 4 4M8 17l4 4 4-4"/>');
