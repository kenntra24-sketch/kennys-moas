import React, { useState, useEffect, useRef } from 'react';
import { IcoSearch, IcoBook, IcoHW, IcoCal, IcoGrades, IcoHome, IcoClose, IcoLightbulb } from './Icons';
import { getData } from '../lib/store';
import { listFiles } from '../lib/files';
import type { LibFile } from '../lib/db';
import { GRADE_TYPES } from '../lib/model';
import { fmtD } from '../lib/util';

const gradeTypeName = (t?: string) => GRADE_TYPES.find(x => x[0] === t)?.[1] || 'Note';

interface SearchResult {
  id: string;
  name: string;
  sub: string;
  icon: React.ReactNode;
  action: string;
}

const NAV: SearchResult[] = [
  { id: 'n-dashboard', name: 'Tableau de bord', sub: 'Navigation', icon: <IcoHome size={16} />, action: 'dashboard' },
  { id: 'n-library', name: 'Bibliothèque', sub: 'Navigation', icon: <IcoBook size={16} />, action: 'library' },
  { id: 'n-homework', name: 'Devoirs', sub: 'Navigation', icon: <IcoHW size={16} />, action: 'homework' },
  { id: 'n-schedule', name: 'Emploi du temps & calendrier', sub: 'Navigation', icon: <IcoCal size={16} />, action: 'schedule' },
  { id: 'n-grades', name: 'Notes & progression', sub: 'Navigation', icon: <IcoGrades size={16} />, action: 'grades' },
];

const QUICK_CMDS = [
  { prefix: '+ devoir', desc: 'Ajouter un devoir', cmd: 'add-homework' },
  { prefix: '+ note', desc: 'Ajouter une note', cmd: 'add-grade' },
  { prefix: '+ événement', desc: 'Ajouter un événement au calendrier', cmd: 'add-event' },
  { prefix: 'pomodoro', desc: 'Démarrer le minuteur', cmd: 'pomodoro' },
  { prefix: 'export', desc: 'Exporter toutes les données', cmd: 'export' },
];

/** Recherche globale réelle : devoirs, notes, remarques, événements, fichiers de la bibliothèque, pages. */
function buildIndex(files: LibFile[]): SearchResult[] {
  const out: SearchResult[] = [...NAV];
  getData('homework').forEach(h => out.push({ id: 'h' + h.id, name: h.title, sub: `Devoirs · ${h.subject || '—'}${h.due ? ' · ' + fmtD(h.due) : ''}${h.done ? ' · fait' : ''}`, icon: <IcoHW size={16} />, action: 'homework' }));
  getData('grades').forEach(g => out.push({ id: 'g' + g.id, name: `${g.subject} — ${g.rawScore}/${g.maxScore}${g.desc ? ' · ' + g.desc : ''}`, sub: `Notes · ${gradeTypeName(g.type)}`, icon: <IcoGrades size={16} />, action: 'grades' }));
  getData('errors').forEach(e => out.push({ id: 'e' + e.id, name: e.mistake || e.question || e.texte || 'Remarque', sub: `Remarques · ${e.subject}${e.chapter ? ' · ' + e.chapter : ''}`, icon: <IcoLightbulb size={16} />, action: 'errors' }));
  getData('events').forEach(e => out.push({ id: 'v' + e.id, name: e.title, sub: `Calendrier · ${fmtD(e.date)}${e.subject ? ' · ' + e.subject : ''}`, icon: <IcoCal size={16} />, action: 'schedule' }));
  files.forEach(f => out.push({ id: 'f' + f.id, name: f.name, sub: `Bibliothèque · ${f.subject || 'Sans matière'}${(f.tags || []).length ? ' · ' + f.tags.join(', ') : ''}`, icon: <IcoBook size={16} />, action: 'library' }));
  return out;
}
const norm = (x: string) => x.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');

interface Props {
  onClose: () => void;
  onNavigate: (view: string) => void;
  onCommand?: (cmd: string) => void;
}

export default function SearchOverlay({ onClose, onNavigate, onCommand }: Props) {
  const [query, setQuery] = useState('');
  const [selected, setSelected] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const [files, setFiles] = useState<LibFile[]>([]);
  useEffect(() => { listFiles().then(setFiles).catch(() => {}); }, []);
  const index = React.useMemo(() => buildIndex(files), [files]);

  useEffect(() => {
    inputRef.current?.focus();
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowDown') setSelected(s => Math.min(s + 1, filtered.length - 1));
      if (e.key === 'ArrowUp') setSelected(s => Math.max(s - 1, 0));
      if (e.key === 'Enter') {
        const item = filtered[selected];
        if (item) { onNavigate(item.action); onClose(); }
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [selected, query]);

  const q = norm(query.trim());
  const filtered = (q
    ? index.filter(r => norm(r.name).includes(q) || norm(r.sub).includes(q))
    : NAV).slice(0, 40);

  return (
    <>
      <div className="search-overlay-bg" onClick={onClose} />
      <div className="search-overlay">
        <div className="search-overlay-input">
          <IcoSearch size={18} />
          <input
            ref={inputRef}
            value={query}
            onChange={e => { setQuery(e.target.value); setSelected(0); }}
            placeholder="Rechercher un cours, devoir ou note…"
          />
          {query && (
            <button onClick={() => setQuery('')} style={{ color: 'var(--mut)' }}>
              <IcoClose size={16} />
            </button>
          )}
        </div>

        <div className="search-results">
          {!query && (
            <div style={{ padding: '8px 12px 6px', fontSize: 11, fontWeight: 700, color: 'var(--mut)', textTransform: 'uppercase', letterSpacing: '0.06em' }}>
              Accès rapide
            </div>
          )}
          {filtered.length === 0 && (
            <div style={{ padding: '24px', textAlign: 'center', color: 'var(--mut)', fontSize: 13.5 }}>
              Aucun résultat pour « {query} »
            </div>
          )}
          {filtered.map((r, i) => (
            <div
              key={r.id}
              className={`search-result-item${i === selected ? ' selected' : ''}`}
              onClick={() => { onNavigate(r.action); onClose(); }}
              onMouseEnter={() => setSelected(i)}
            >
              <div className="search-result-ico">{r.icon}</div>
              <div className="search-result-main">
                <div className="search-result-name">{r.name}</div>
                <div className="search-result-sub">{r.sub}</div>
              </div>
            </div>
          ))}

          {!query && (
            <>
              <div style={{ padding: '12px 12px 4px', fontSize: 11, fontWeight: 700, color: 'var(--mut)', textTransform: 'uppercase', letterSpacing: '0.06em', borderTop: '1px solid var(--bd)', marginTop: 6 }}>
                Commandes rapides
              </div>
              {QUICK_CMDS.map(cmd => (
                <div key={cmd.prefix} className="search-result-item" style={{ opacity: 0.85, cursor: 'pointer' }} onClick={() => { onCommand?.(cmd.cmd); onClose(); }}>
                  <div className="search-result-ico" style={{ fontSize: 12, fontWeight: 800, fontFamily: 'var(--font-main)' }}>+</div>
                  <div className="search-result-main">
                    <div className="search-result-name" style={{ fontFamily: 'monospace', fontSize: 12.5 }}>{cmd.prefix}</div>
                    <div className="search-result-sub">{cmd.desc}</div>
                  </div>
                </div>
              ))}
            </>
          )}
        </div>

        <div className="search-hint">
          <span><kbd>↑↓</kbd> naviguer · <kbd>↵</kbd> ouvrir · <kbd>Esc</kbd> fermer</span>
          <span>{filtered.length} résultat{filtered.length !== 1 ? 's' : ''}</span>
        </div>
      </div>
    </>
  );
}
