import React from 'react';
import { getClass, useStore } from '../lib/store';
import { ViewId } from '../types';
import {
  IcoHome, IcoBook, IcoHW, IcoCal, IcoGrades, IcoTimer,
  IcoLightbulb, IcoTarget, IcoSettings, IcoHelp,
  IcoChevronLeft, IcoChevronRight, IcoClose,
} from './Icons';

interface NavItem {
  id: ViewId;
  label: string;
  icon: React.ReactNode;
}

/* Couleur propre à chaque section (icône colorée au repos, blanche sur fond de la couleur quand active). */
const NAV_COLORS: Record<string, string> = {"dashboard": "#3b5bdb", "library": "#2f9e6e", "homework": "#d9822b", "schedule": "#7048c9", "grades": "#c2255c", "reviews": "#0c8599", "errors": "#c98a00", "goals": "#d6336c", "settings": "#6b7280", "faq": "#5c7cfa"};

const SECTION_WORK: NavItem[] = [
  { id: 'dashboard',  label: 'Tableau de bord', icon: <IcoHome /> },
  { id: 'library',   label: 'Bibliothèque',    icon: <IcoBook /> },
  { id: 'homework',  label: 'Devoirs',          icon: <IcoHW /> },
  { id: 'schedule',  label: 'Emploi du temps',  icon: <IcoCal /> },
  { id: 'grades',    label: 'Notes',            icon: <IcoGrades /> },
];

const SECTION_STUDY: NavItem[] = [
  { id: 'reviews', label: 'Révisions',  icon: <IcoTimer /> },
  { id: 'errors',  label: 'Remarques', icon: <IcoLightbulb /> },
  { id: 'goals',   label: 'Objectifs',   icon: <IcoTarget /> },
];

const SECTION_BOTTOM: NavItem[] = [
  { id: 'settings', label: 'Réglages', icon: <IcoSettings /> },
  { id: 'faq',      label: 'Aide / FAQ', icon: <IcoHelp /> },
];

interface SidebarProps {
  view: ViewId;
  onView: (v: ViewId) => void;
  collapsed: boolean;
  onToggle: () => void;
  /** Drawer state on mobile (≤768px), where the sidebar is off-canvas by default. */
  mobileOpen?: boolean;
  onCloseMobile?: () => void;
}

function NavBtn({ item, active, collapsed, onClick }: {
  item: NavItem; active: boolean; collapsed: boolean; onClick: () => void;
}) {
  return (
    <button
      className={`nav-btn${active ? ' active' : ''}`}
      onClick={onClick}
      title={collapsed ? item.label : undefined}
    >
      <span className="nav-ico" style={{ ['--ic' as string]: NAV_COLORS[item.id] } as React.CSSProperties}>{item.icon}</span>
      <span className="nav-label-text">{item.label}</span>
    </button>
  );
}

export default function Sidebar({ view, onView, collapsed, onToggle, mobileOpen, onCloseMobile }: SidebarProps) {
  useStore();

  // Escape closes the mobile drawer.
  React.useEffect(() => {
    if (!mobileOpen) return;
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') onCloseMobile?.(); };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [mobileOpen, onCloseMobile]);

  return (
    <>
      {/* Backdrop for the mobile drawer */}
      {mobileOpen && <div className="sidebar-backdrop" onClick={onCloseMobile} />}
      <aside className={`sidebar${collapsed ? ' collapsed' : ''}${mobileOpen ? ' mobile-open' : ''}`}>
      {/* Brand */}
      <div className="sidebar-brand">
        <div className="brand-logo"><img src="./logo.svg" alt="" width={36} height={36} draggable={false} /></div>
        <div>
          <div className="brand-name">KENNY'S MOAS</div>
          <div className="brand-sub">{getClass()}</div>
        </div>
        <button className="icon-btn sidebar-close-mobile" onClick={onCloseMobile} aria-label="Fermer le menu">
          <IcoClose size={18} />
        </button>
      </div>

      {/* Nav items */}
      <div className="sidebar-scroll">
        {!collapsed && <div className="sidebar-label">Travail scolaire</div>}
        {SECTION_WORK.map(item => (
          <NavBtn key={item.id} item={item} active={view === item.id} collapsed={collapsed} onClick={() => onView(item.id)} />
        ))}

        {!collapsed && <div className="sidebar-label" style={{ marginTop: 6 }}>Suivi</div>}
        {SECTION_STUDY.map(item => (
          <NavBtn key={item.id} item={item} active={view === item.id} collapsed={collapsed} onClick={() => onView(item.id)} />
        ))}

        <div className="sidebar-spacer" />
      </div>

      {/* Footer nav */}
      <div className="sidebar-footer">
        {SECTION_BOTTOM.map(item => (
          <NavBtn key={item.id} item={item} active={view === item.id} collapsed={collapsed} onClick={() => onView(item.id)} />
        ))}

        {/* Collapse toggle */}
        <button
          className="nav-btn"
          onClick={onToggle}
          title={collapsed ? 'Développer' : 'Réduire la barre'}
          style={{ marginTop: 4 }}
        >
          <span className="nav-ico" style={{ color: 'var(--mut)' }}>
            {collapsed ? <IcoChevronRight /> : <IcoChevronLeft />}
          </span>
          <span className="nav-label-text" style={{ color: 'var(--mut)', fontSize: 12 }}>
            Réduire
          </span>
        </button>
      </div>
      </aside>
    </>
  );
}
