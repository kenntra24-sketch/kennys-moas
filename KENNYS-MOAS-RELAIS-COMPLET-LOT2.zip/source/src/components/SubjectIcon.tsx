import React from 'react';
import { subjColor } from '../lib/calc';

/* Icônes de matières (style trait 1,9 px sur grille 24, comme Icons.tsx). Clé stockée dans Subject.icon. */
const P = (d: string) => d;
export const SUBJECT_ICONS: Record<string, { label: string; svg: string }> = {
  book: { label: 'Livre', svg: P('<path d="M12 6.5C10.5 5 8 4.5 4 4.5v13c4 0 6.5.5 8 2 1.5-1.5 4-2 8-2v-13c-4 0-6.5.5-8 2z" fill="currentColor" fill-opacity=".18"/><path d="M12 6.5v13"/>') },
  calc: { label: 'Mathématiques', svg: P('<rect x="5" y="3" width="14" height="18" rx="2.5" fill="currentColor" fill-opacity=".18"/><path d="M8.5 7h7M9 12h.01M12 12h.01M15 12h.01M9 16h.01M12 16h.01M15 16h.01"/>') },
  globe: { label: 'Géographie', svg: P('<circle cx="12" cy="12" r="9" fill="currentColor" fill-opacity=".18"/><path d="M3 12h18M12 3c2.5 2.6 3.8 5.6 3.8 9S14.5 18.4 12 21c-2.5-2.6-3.8-5.6-3.8-9S9.5 5.6 12 3z"/>') },
  pen: { label: 'Français / Écriture', svg: P('<path d="M4 20l1-4L16.5 4.5a2.1 2.1 0 0 1 3 3L8 19z" fill="currentColor" fill-opacity=".18"/><path d="M14.5 6.5l3 3M4 20l4-1"/>') },
  lang: { label: 'Langues', svg: P('<path d="M4 5h16v11H11l-4 4v-4H4z" fill="currentColor" fill-opacity=".18"/><path d="M8 9h8M8 12h5"/>') },
  flask: { label: 'Sciences', svg: P('<path d="M9.5 3h5M10.5 3v6L5 19a1.5 1.5 0 0 0 1.3 2.2h11.4A1.5 1.5 0 0 0 19 19l-5.5-10V3" fill="currentColor" fill-opacity=".18"/><path d="M8 15h8"/>') },
  leaf: { label: 'SVT / Nature', svg: P('<path d="M5 19c0-8 5-14 15-14 0 10-6 15-14 15" fill="currentColor" fill-opacity=".18"/><path d="M5 19c3-5 6-8 10-10"/>') },
  run: { label: 'Sport', svg: P('<circle cx="14.5" cy="5" r="2" fill="currentColor" fill-opacity=".18"/><path d="M12 9l-3 3 3 3v5M9 12l-4 1M12 9l4 2 3-1M12 15l4 1"/>') },
  palette: { label: 'Arts plastiques', svg: P('<path d="M12 3a9 9 0 1 0 0 18c1.3 0 2-.8 2-1.7 0-1.3-1-1.6-1-2.8 0-1 .8-1.5 1.8-1.5H17a4 4 0 0 0 4-4C21 6.4 17 3 12 3z" fill="currentColor" fill-opacity=".18"/><circle cx="7.5" cy="11" r=".9" fill="currentColor"/><circle cx="10" cy="7.5" r=".9" fill="currentColor"/><circle cx="14.5" cy="7.5" r=".9" fill="currentColor"/>') },
  music: { label: 'Musique', svg: P('<path d="M9 18V5l10-2v13"/><circle cx="6.5" cy="18" r="2.5" fill="currentColor" fill-opacity=".18"/><circle cx="16.5" cy="16" r="2.5" fill="currentColor" fill-opacity=".18"/>') },
  scale: { label: 'Philosophie / Droit', svg: P('<path d="M12 4v16M7 20h10M5 7h14"/><path d="M5 7l-2.5 6a2.8 2.8 0 0 0 5 0zM19 7l-2.5 6a2.8 2.8 0 0 0 5 0z" fill="currentColor" fill-opacity=".18"/>') },
  bulb: { label: 'Autre', svg: P('<path d="M12 2.5a6.5 6.5 0 0 0-3.8 11.8c.5.4.8 1 .8 1.7v.5h6V16c0-.7.3-1.3.8-1.7A6.5 6.5 0 0 0 12 2.5z" fill="currentColor" fill-opacity=".18"/><path d="M9.5 19.5h5M10.5 22h3"/>') },
};

/* Icône par défaut devinée d'après le nom (l'utilisateur peut toujours la changer) */
export function guessIcon(name: string): string {
  const n = name.toLowerCase();
  if (/math/.test(n)) return 'calc';
  if (/hist|géo|geo/.test(n)) return 'globe';
  if (/fran|lettre|litt/.test(n)) return 'pen';
  if (/ang|esp|all|lang|latin|arabe/.test(n)) return 'lang';
  if (/phys|chim|techno|info/.test(n)) return 'flask';
  if (/svt|bio|nature/.test(n)) return 'leaf';
  if (/eps|sport/.test(n)) return 'run';
  if (/arts|\bap\b|dessin/.test(n)) return 'palette';
  if (/music/.test(n)) return 'music';
  if (/philo|edhc|droit|civique|entrepre/.test(n)) return 'scale';
  return 'book';
}

export function SubjectIcon({ name, icon, size = 16, colored = true }: { name: string; icon?: string; size?: number; colored?: boolean }) {
  const key = icon && SUBJECT_ICONS[icon] ? icon : guessIcon(name);
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round"
      aria-hidden="true" style={{ flex: '0 0 auto', color: colored ? subjColor(name) : undefined }}>
      <g dangerouslySetInnerHTML={{ __html: SUBJECT_ICONS[key].svg }} />
    </svg>
  );
}

/* Matières proposées en un clic (lycée ivoirien, d'après l'emploi du temps réel) */
export const SUGGESTED_SUBJECTS = ['Mathématiques', 'Français', 'Philosophie', 'Histoire-Géographie', 'Anglais', 'Espagnol', 'Allemand', 'SVT', 'Physique-Chimie', 'EPS', 'AP / Musique', 'EDHC', 'Entrepreneuriat'];
