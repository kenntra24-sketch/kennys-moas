import React from 'react';
import { ViewId, DriveStatus, Theme } from '../types';
import { IcoSearch, IcoMoon, IcoSun, IcoCloudUp, IcoMenu } from './Icons';
import { useLastDriveSave } from '../lib/drive';
import CreateMenu from './CreateMenu';

const IS_MAC = typeof navigator !== 'undefined' && /Mac|iPhone|iPad/i.test(navigator.platform || navigator.userAgent);
const SHORTCUT = IS_MAC ? '⌘K' : 'Ctrl K';

const VIEW_LABELS: Record<ViewId, string> = {
  dashboard: 'Tableau de bord',
  library: 'Bibliothèque',
  homework: 'Devoirs',
  schedule: 'Emploi du temps',
  grades: 'Notes & progression',
  reviews: 'Révisions',
  errors: 'Remarques',
  goals: 'Objectifs',
  settings: 'Réglages',
  faq: 'Aide & FAQ',
};

/* Sauvegarde Drive = les DONNÉES (devoirs, notes, réglages…), pas les fichiers de la bibliothèque : on ne dit jamais « synchronisé ». */
const DRIVE_LABEL: Record<DriveStatus, string> = {
  disconnected: 'Non connecté',
  connected: 'Connecté',
  syncing: 'Sauvegarde en cours…',
  offline: 'Hors ligne',
  error: 'Erreur',
};
const hhmm = (t: number) => new Date(t).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
function driveText(status: DriveStatus, last: number): string {
  if (status === 'connected' && last) {
    const d = new Date(last), today = new Date();
    const same = d.toDateString() === today.toDateString();
    return same ? `Dernière sauvegarde : ${hhmm(last)}` : `Dernière sauvegarde : ${d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short' })}, ${hhmm(last)}`;
  }
  return DRIVE_LABEL[status];
}

interface TopbarProps {
  view: ViewId;
  theme: Theme;
  onTheme: () => void;
  onSearch: () => void;
  driveStatus: DriveStatus;
  onDrive: () => void;
  timerActive: boolean;
  timerDisplay: string;
  breadcrumb?: string[];
  onMobileMenu?: () => void;
  onTimer?: () => void;
  createMenuOpen: boolean;
  onCreateMenu: (open: boolean) => void;
  onCommand: (command: string) => void;
  onNavigate: (view: string) => void;
}

export default function Topbar({
  view, theme, onTheme, onSearch, driveStatus, onDrive,
  timerActive, timerDisplay, breadcrumb, onMobileMenu, onTimer,
  createMenuOpen, onCreateMenu, onCommand, onNavigate,
}: TopbarProps) {
  const lastSave = useLastDriveSave();
  const driveLabel = driveText(driveStatus, lastSave);
  return (
    <header className="topbar">
      {/* Mobile hamburger */}
      <button className="icon-btn" onClick={onMobileMenu}
        aria-label="Menu" id="mobile-menu-btn">
        <IcoMenu size={18} />
      </button>

      {/* Search bar */}
      <div className="search-bar">
        <span className="search-ico"><IcoSearch size={15} /></span>
        <input
          readOnly
          placeholder={window.matchMedia?.('(hover: hover)').matches ? `Rechercher… (${SHORTCUT})` : 'Rechercher…'}
          onClick={onSearch}
          onKeyDown={e => { if (e.key === 'k' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); onSearch(); } }}
          style={{ cursor: 'pointer' }}
        />
        <span className="search-kbd">{SHORTCUT}</span>
      </div>

      <div className="topbar-actions">
        <CreateMenu open={createMenuOpen} onOpen={() => onCreateMenu(true)} onClose={() => onCreateMenu(false)} onCommand={onCommand} onNavigate={onNavigate} />
        {/* Timer chip (shown when active) */}
        {timerActive && (
          <div className="timer-chip" role="button" tabIndex={0} onClick={onTimer} onKeyDown={e => { if (e.key === 'Enter') onTimer?.(); }} style={{ cursor: 'pointer' }} title="Ouvrir les révisions">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 3"/>
            </svg>
            {timerDisplay}
          </div>
        )}

        {/* Sauvegarde Drive : nuage + flèche, libellé toujours lisible (info-bulle + lecteur d'écran) */}
        <button className="drive-status" onClick={onDrive}
          title={`Sauvegarde Drive — ${driveLabel}. Ouvre les Réglages.`}
          aria-label={`Sauvegarde Drive : ${driveLabel}. Ouvrir les réglages de sauvegarde.`}>
          <IcoCloudUp size={16} />
          <span className="drive-label-text">
            <span className="drive-label-title">Sauvegarde Drive</span>
            <span className="drive-label-state">{driveLabel}</span>
          </span>
          <span className={`drive-dot ${driveStatus === 'connected' ? 'ok' : driveStatus === 'syncing' ? 'syncing' : driveStatus === 'error' ? 'error' : 'offline'}`} aria-hidden="true" />
        </button>

        {/* Theme toggle */}
        <button className="icon-btn" onClick={onTheme} title={theme === 'dark' ? 'Passer au thème clair' : 'Passer au thème sombre'} aria-label={theme === 'dark' ? 'Passer au thème clair' : 'Passer au thème sombre'}>
          {theme === 'dark' ? <IcoSun size={16} /> : <IcoMoon size={16} />}
        </button>
      </div>
    </header>
  );
}
