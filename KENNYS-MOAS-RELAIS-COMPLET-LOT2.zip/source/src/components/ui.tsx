import React, { useEffect, useRef, useState } from 'react';
import { onToast, type ToastMsg } from '../lib/toast';
import { IcoClose } from './Icons';
import { importFiles, listFiles } from '../lib/files';
import type { LibFile } from '../lib/db';
import { onAsk, type AskRequest } from '../lib/ask';
import { onChoose, type ChooseRequest } from '../lib/choose';

/* ── Boîte de dialogue (Échap pour fermer, focus piégé dans la carte) ── */
export function Modal({ title, onClose, children, footer, wide, size }: {
  title: string; onClose: () => void; children: React.ReactNode; footer?: React.ReactNode; wide?: boolean; size?: 'md';
}) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    ref.current?.querySelector<HTMLElement>('input,select,textarea,button')?.focus();
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') { e.stopPropagation(); onClose(); } };
    window.addEventListener('keydown', h);
    return () => { window.removeEventListener('keydown', h); prev?.focus?.(); };
  }, [onClose]);
  return (
    <div className="modal-bg" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className={`modal${wide ? ' wide' : ''}${size ? ' ' + size : ''}`} role="dialog" aria-modal="true" aria-label={title} ref={ref}>
        <div className="modal-head"><h3>{title}</h3><button className="icon-btn" onClick={onClose} aria-label="Fermer"><IcoClose size={16} /></button></div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
    </div>
  );
}
export const Field = ({ label, children, hint }: { label: string; children: React.ReactNode; hint?: string }) => (
  <label className="field"><span className="field-lbl">{label}</span>{children}{hint && <span className="field-hint">{hint}</span>}</label>
);
export const Cols = ({ children }: { children: React.ReactNode }) => <div className="cols">{children}</div>;

export function Confirm({ message, okLabel = 'Confirmer', danger, onOk, onClose }: {
  message: string; okLabel?: string; danger?: boolean; onOk: () => void; onClose: () => void;
}) {
  return (
    <Modal title="Confirmation" onClose={onClose} footer={<>
      <button className="btn ghost" onClick={onClose}>Annuler</button>
      <button className={`btn${danger ? ' danger' : ''}`} onClick={() => { onOk(); onClose(); }}>{okLabel}</button>
    </>}><p style={{ lineHeight: 1.5 }}>{message}</p></Modal>
  );
}
export function AskText({ title, label, initial = '', type = 'text', onOk, onClose }: {
  title: string; label: string; initial?: string | number; type?: string; onOk: (v: string) => void; onClose: () => void;
}) {
  const [v, setV] = useState(String(initial));
  const go = () => { onOk(v.trim()); onClose(); };
  return (
    <Modal title={title} onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>Annuler</button><button className="btn" onClick={go}>OK</button></>}>
      <Field label={label}><input className="input" type={type} value={v} onChange={e => setV(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') go(); }} /></Field>
    </Modal>
  );
}

/* ── Champ « fichier associé » (preuve/pièce jointe) — réutilisé dans Notes, Devoirs, Événements.
   Portage de `fileFieldHTML()`/`fillFileSelect()`/`wireFileImport()` de l'app d'origine : une liste
   déroulante des fichiers déjà dans la Bibliothèque de la classe active + un bouton « Importer » qui
   ajoute directement un nouveau fichier (via `importFiles()`, donc les mêmes vérifications de
   quasi-doublon/nom peu clair s'appliquent) et le sélectionne aussitôt. ── */
export function FileField({ value, onChange, subject }: { value: string | null | undefined; onChange: (id: string | null) => void; subject?: string }) {
  const [files, setFiles] = useState<LibFile[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  const refresh = () => { listFiles().then(setFiles); };
  useEffect(refresh, []);
  const onPick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0]; e.target.value = '';
    if (!f) return;
    const ids = await importFiles([f], { skipType: true, subject: subject || '' });
    if (ids.length) { await refresh(); onChange(ids[ids.length - 1]); }
  };
  return (
    <div className="row" style={{ gap: 8 }}>
      <select className="input" style={{ flex: 1 }} value={value || ''} onChange={e => onChange(e.target.value || null)}>
        <option value="">— Aucun —</option>
        {files.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
      </select>
      <button type="button" className="btn ghost sm" onClick={() => inputRef.current?.click()}>Importer</button>
      <input ref={inputRef} type="file" hidden onChange={onPick} />
    </div>
  );
}

/* ── Hôte pour askText() (lib/ask.ts) : permet à du code non-composant (ex. le rappel de
   renommage à l'import dans lib/files.ts) de demander un texte via la même boîte de dialogue
   stylée que les <AskText> déjà câblés dans les vues, au lieu d'un window.prompt() natif. Une
   seule demande affichée à la fois. ── */
export function AskHost() {
  const [req, setReq] = useState<AskRequest | null>(null);
  useEffect(() => onAsk(r => setReq(r)), []);
  if (!req) return null;
  return <AskText title={req.title} label={req.label} initial={req.initial} onOk={req.onOk} onClose={() => { req.onCancel(); setReq(null); }} />;
}

export function ChooseHost() {
  const [req, setReq] = useState<ChooseRequest | null>(null);
  useEffect(() => onChoose(r => setReq(r)), []);
  if (!req) return null;
  const close = () => { req.onCancel(); setReq(null); };
  let last = '';
  return (
    <Modal title={req.title} onClose={close} footer={<button className="btn ghost" onClick={close}>Annuler</button>}>
      <div className="col" style={{ gap: 6 }}>
        {req.options.map(o => {
          const head = o.group && o.group !== last ? <div key={'g' + o.group} className="muted" style={{ fontSize: 12, fontWeight: 600, marginTop: 8 }}>{o.group}</div> : null; last = o.group || last;
          return <React.Fragment key={o.key}>{head}
            <button type="button" className="btn ghost" style={{ justifyContent: 'flex-start', textAlign: 'left', height: 'auto', padding: '10px 12px', flexDirection: 'column', alignItems: 'flex-start', gap: 2 }} onClick={() => { req.onPick(o.key); setReq(null); }}>
              <b>{o.label}</b><span className="muted" style={{ fontSize: 12, fontWeight: 400 }}>{o.desc}</span>
            </button></React.Fragment>;
        })}
      </div>
    </Modal>
  );
}

export function ToastHost() {
  const [list, setList] = useState<ToastMsg[]>([]);
  useEffect(() => onToast(t => {
    setList(l => [...l, t]);
    setTimeout(() => setList(l => l.filter(x => x.id !== t.id)), t.action ? 4200 : 2600);
  }), []);
  return (
    <div className="toast-area" role="status" aria-live="polite">
      {list.map(t => (
        <div key={t.id} className={`toast ${t.type === 'warn' ? '' : t.type}`} style={{ pointerEvents: 'auto' }}>
          <span>{t.msg}</span>
          {t.action && <button className="toast-act" onClick={() => { t.action!.cb(); setList(l => l.filter(x => x.id !== t.id)); }}>{t.action.label}</button>}
        </div>
      ))}
    </div>
  );
}
