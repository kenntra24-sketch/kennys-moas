/* Portage de la boîte de dialogue `askText()` de l'app d'origine, mais utilisable depuis du
   code non-composant (ex. le rappel de renommage à l'import dans lib/files.ts) — sur le même
   principe pub/sub que toast.ts : on publie une demande, un composant hôte (AskHost, monté une
   fois dans App.tsx) l'affiche avec le composant React <AskText> déjà existant. */
export interface AskRequest { id: number; title: string; label: string; initial: string; onOk: (v: string) => void; onCancel: () => void }
let n = 0;
const subs = new Set<(r: AskRequest) => void>();
export const onAsk = (fn: (r: AskRequest) => void) => { subs.add(fn); return () => { subs.delete(fn); }; };
export function askText(title: string, label: string, initial = ''): Promise<string | null> {
  return new Promise(resolve => {
    let done = false;
    const finish = (v: string | null) => { if (done) return; done = true; resolve(v); };
    const r: AskRequest = { id: ++n, title, label, initial, onOk: v => finish(v.trim() || null), onCancel: () => finish(null) };
    subs.forEach(s => s(r));
  });
}
