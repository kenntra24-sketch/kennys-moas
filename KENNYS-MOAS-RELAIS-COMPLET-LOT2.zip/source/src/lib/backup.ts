import { dbAll, dbDel, dbGet, dbPut, dbReset, type LibFile } from './db';
import { LS, notifyStore } from './store';
import { download, todayISO } from './util';
import { toast } from './toast';

/** Toutes les clés localStorage de l'app (`me:*`). */
export const collectLS = () => { const o: Record<string, string> = {}; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i)!; if (k.startsWith('me:')) o[k] = localStorage.getItem(k)!; } return o; };
const blobToDataURL = (b: Blob) => new Promise<string>((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result as string); r.onerror = () => rej(r.error); r.readAsDataURL(b); });
const meta = (f: LibFile) => ({ id: f.id, name: f.name, type: f.type, size: f.size, date: f.date, subject: f.subject, chapter: f.chapter, classId: f.classId, fav: f.fav, lastOpened: f.lastOpened, progress: f.progress, libraryType: f.libraryType, homeworkType: f.homeworkType, category: f.category, tags: f.tags });

/** Données + métadonnées des fichiers (sans leur contenu) — sert à l'export léger et à la sauvegarde Google Drive. */
export async function lightPayload() {
  return { version: 2, exportedAt: new Date().toISOString(), localStorage: collectLS(), files: (await dbAll<LibFile>('files')).map(meta) };
}
export async function exportLight() {
  download(`kennys-moas-${todayISO()}.json`, new Blob([JSON.stringify(await lightPayload())], { type: 'application/json' }));
  LS.s('me:lastExport', Date.now()); toast('Export téléchargé (sans le contenu des fichiers)');
}
export async function exportFull() {
  toast('Préparation de l’export complet…');
  const files: unknown[] = [];
  for (const f of await dbAll<LibFile>('files')) {
    let dataUrl: string | null = null;
    try { dataUrl = await blobToDataURL(f.blob); } catch (e) { console.error('Échec encodage', f.name, e); }
    files.push({ ...meta(f), dataUrl });
  }
  download(`kennys-moas-complet-${todayISO()}.json`, new Blob([JSON.stringify({ version: 3, exportedAt: new Date().toISOString(), localStorage: collectLS(), files })], { type: 'application/json' }));
  LS.s('me:lastExport', Date.now()); toast('Export complet téléchargé');
}
export async function importJSON(file: File) {
  try {
    const d = JSON.parse(await file.text());
    const payload = d.localStorage || d;
    Object.entries(payload).forEach(([k, v]) => { if (k.startsWith('me:')) localStorage.setItem(k, typeof v === 'string' ? v : JSON.stringify(v)); });
    let restored = 0;
    if (Array.isArray(d.files)) for (const m of d.files) {
      const old = await dbGet<LibFile>('files', m.id);
      if (m.dataUrl) { try { const blob = await (await fetch(m.dataUrl)).blob(); const { dataUrl: _u, ...rest } = m; await dbPut('files', { ...(old || {}), ...rest, blob }); restored++; } catch (e) { console.error(e); } }
      else if (old) await dbPut('files', { ...old, ...m });
    }
    notifyStore();
    toast(restored ? `Données importées · ${restored} fichier(s) restauré(s)` : 'Données importées');
  } catch (e) { console.error(e); toast('Fichier invalide', 'err'); }
}
export async function resetAll() {
  Object.keys(localStorage).filter(k => k.startsWith('me:')).forEach(k => localStorage.removeItem(k));
  await dbReset(); location.reload();
}

/* Sauvegarde automatique : instantané léger (localStorage seul) toutes les 6 h, 5 conservés. */
const AUTOBK_MS = 6 * 3600 * 1000, AUTOBK_KEEP = 5;
export async function autoBackup(force = false) {
  const last = +LS.g('me:lastAutoBackup', 0);
  if (!force && Date.now() - last < AUTOBK_MS) return;
  try {
    const id = Date.now();
    await dbPut('backups', { id, at: new Date().toISOString(), localStorage: collectLS() });
    const all = (await dbAll<{ id: number }>('backups')).sort((a, b) => b.id - a.id);
    for (const old of all.slice(AUTOBK_KEEP)) await dbDel('backups', old.id);
    LS.s('me:lastAutoBackup', id);
  } catch (e) { console.error('Échec de la sauvegarde automatique', e); }
}
export const listAutoBackups = async () => (await dbAll<{ id: number }>('backups')).sort((a, b) => b.id - a.id);
export async function restoreAutoBackup(id: number) {
  const b = await dbGet<{ localStorage: Record<string, string> }>('backups', id);
  if (!b) return;
  Object.entries(b.localStorage).forEach(([k, v]) => localStorage.setItem(k, v));
  notifyStore(); toast('Sauvegarde restaurée');
}
