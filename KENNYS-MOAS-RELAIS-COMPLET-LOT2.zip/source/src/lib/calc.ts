import type { Grade, Subj } from './model';
import { isoOf, pad, todayISO } from './util';
import { getData } from './store';

/** Portage exact de gradeDisplayScore / subjAvg / overallAvg / gradeDateISO de l'original. */
export const gradeDisplayScore = (g: Grade) => {
  const max = Number(g.maxScore || 20), raw = Number(g.rawScore ?? g.value);
  return { raw, max, value: max > 0 ? (raw / max) * 20 : Number(g.value || 0) };
};
export const gradeDateISO = (g: Grade): string => {
  if (typeof g.date === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(g.date)) return g.date;
  const n = Number(g.date);
  if (!Number.isFinite(n)) return todayISO();
  return isoOf(new Date(n));
};
export function subjAvg(grades: Grade[], name: string): number | null {
  const g = grades.filter(x => x.subject === name);
  if (!g.length) return null;
  const c = g.reduce((a, x) => a + (+x.coef || 1), 0);
  return g.reduce((a, x) => a + gradeDisplayScore(x).value * (+x.coef || 1), 0) / c;
}
export function overallAvg(subjects: Subj[], grades: Grade[]): number | null {
  let s = 0, c = 0;
  for (const sub of subjects) { const a = subjAvg(grades, sub.name); if (a != null) { s += a * sub.coef; c += sub.coef; } }
  return c ? s / c : null;
}
/* Une seule teinte par famille de couleur (pas deux verts, pas deux violets…) pour que les matières se distinguent
   vraiment d'un coup d'œil, même sur un fond très clair (surface Papier / Lin) — cf. retour du 20/09/2026. */
export const PALETTE = ['#1d4ed8', '#b91c1c', '#15803d', '#c2410c', '#7e22ce', '#0f766e', '#a16207', '#be185d', '#4338ca', '#0369a1', '#65a30d', '#9d174d', '#334155', '#c026d3'];
export const subjColor = (name: string) => {
  /* couleur choisie par l'utilisateur (Réglages → Matières), sinon couleur automatique stable */
  try { const c = getData('subjects').find(x => x.name === name)?.color; if (c && /^#[0-9a-f]{6}$/i.test(c)) return c; } catch { /* stockage indisponible : couleur automatique */ }
  let h = 0; for (const ch of name) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  return PALETTE[h % PALETTE.length];
};
export const hourMin = (h: string) => { const m = h.match(/^(\d{1,2})h(\d{2})?$/); return m ? +m[1] * 60 + +(m[2] || 0) : 0; };
/** Normalise « 8h », « 8h5 »… en « 08h »/« 08h05 » : deux créneaux qui représentent la même heure ne doivent
    jamais devenir deux lignes distinctes (c'est ce qui produisait des créneaux « superposés »). */
export const normHour = (h: string): string | null => {
  const m = h.trim().match(/^(\d{1,2})h(\d{2})?$/); if (!m) return null;
  const hh = +m[1], mm = +(m[2] || 0); if (hh > 23 || mm > 59) return null;
  return String(hh).padStart(2, '0') + 'h' + (m[2] ? String(mm).padStart(2, '0') : '');
};
export const fmtHM = (min: number) => `${pad(Math.floor(min / 60))}:${pad(min % 60)}`;
