/* Dialogue de choix (liste de cartes) utilisable hors composant — même principe pub/sub que ask.ts. */
export interface ChooseOption { key: string; label: string; desc: string; group?: string }
export interface ChooseRequest { id: number; title: string; options: ChooseOption[]; onPick: (k: string) => void; onCancel: () => void }
let n = 0;
const subs = new Set<(r: ChooseRequest) => void>();
export const onChoose = (fn: (r: ChooseRequest) => void) => { subs.add(fn); return () => { subs.delete(fn); }; };
export function chooseOption(title: string, options: ChooseOption[]): Promise<string | null> {
  return new Promise(resolve => {
    let done = false; const finish = (v: string | null) => { if (done) return; done = true; resolve(v); };
    const r: ChooseRequest = { id: ++n, title, options, onPick: finish, onCancel: () => finish(null) };
    subs.forEach(s => s(r));
  });
}
