/* IndexedDB `monEcoleV2` (v2) — mêmes magasins que l'app d'origine : files, annot, read, backups. */
let _db: IDBDatabase | null = null;
export const db = (): Promise<IDBDatabase> =>
  _db ? Promise.resolve(_db) : new Promise((res, rej) => {
    const r = indexedDB.open('monEcoleV2', 2);
    r.onupgradeneeded = () => {
      const d = r.result;
      if (!d.objectStoreNames.contains('files')) d.createObjectStore('files', { keyPath: 'id' });
      if (!d.objectStoreNames.contains('annot')) d.createObjectStore('annot', { keyPath: 'key' });
      if (!d.objectStoreNames.contains('read')) d.createObjectStore('read', { keyPath: 'id' });
      if (!d.objectStoreNames.contains('backups')) d.createObjectStore('backups', { keyPath: 'id' });
    };
    r.onsuccess = () => res((_db = r.result));
    r.onerror = () => rej(r.error);
  });
const dbP = <T>(st: string, mode: IDBTransactionMode, fn: (o: IDBObjectStore) => IDBRequest | void): Promise<T> =>
  db().then(d => new Promise<T>((res, rej) => {
    const tx = d.transaction(st, mode);
    const rq = fn(tx.objectStore(st));
    tx.oncomplete = () => res((rq ? rq.result : undefined) as T);
    tx.onerror = () => rej(tx.error);
  }));
export const dbPut = (st: string, v: unknown) => dbP<unknown>(st, 'readwrite', o => o.put(v));
export const dbGet = <T = any>(st: string, k: IDBValidKey) => dbP<T | undefined>(st, 'readonly', o => o.get(k));
export const dbDel = (st: string, k: IDBValidKey) => dbP<unknown>(st, 'readwrite', o => o.delete(k));
export const dbAll = <T = any>(st: string) => dbP<T[]>(st, 'readonly', o => o.getAll());
export function dbReset(): Promise<void> {
  return new Promise(res => { if (_db) { _db.close(); _db = null; } const q = indexedDB.deleteDatabase('monEcoleV2'); q.onsuccess = () => res(); q.onerror = () => res(); q.onblocked = () => res(); });
}

/** Fichier de la Bibliothèque (enregistrement IndexedDB `files`). */
export interface LibFile {
  id: string; name: string; type: string; size: number; date: number; subject: string; chapter?: string;
  classId: string; fav: boolean; lastOpened: number; progress: number; blob: Blob;
  libraryType?: string | null; homeworkType?: string | null; tags: string[];
  /** Catégorie unique (P1) : cours | fiche | exercice | notes. `libraryType`/`homeworkType` d'origine sont conservés. */
  category?: 'cours' | 'fiche' | 'exercice' | 'notes' | null;
}

/** Magasin `read` (identique à l'app d'origine / Ronde 11) : clé `id` = id du fichier. Les champs inconnus sont toujours conservés. */
export interface ReadState { id: string; page?: number; zoom?: number; mode?: string; bookmarks?: { p: number; label?: string }[]; [k: string]: unknown }
