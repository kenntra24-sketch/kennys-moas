/* deletion.ts — suppression « propre » d'un objet du store (devoir, remarque, note, événement) :
   1) si l'objet est relié à autre chose, on demande confirmation EN DISANT ce qui est lié ;
   2) les références vers lui sont nettoyées (relations.removeAllReferencesTo) ;
   3) « Annuler » remet l'objet ET les liens. Les fichiers ont leur propre flux : files.removeFile. */
import { chooseOption } from './choose';
import { describeRelated, removeAllReferencesTo, type Ref } from './relations';
import { toast } from './toast';

export async function removeObject(ref: Ref, label: string, io: { remove: () => void; restore: () => void; done: string }): Promise<boolean> {
  const used = describeRelated(ref);
  if (used) {
    const k = await chooseOption(`Supprimer ${label} ?`, [{ key: 'ok', label: 'Supprimer', desc: `Encore relié à : ${used}. Les liens seront retirés, ces éléments restent.` }]);
    if (!k) return false;
  }
  const refs = removeAllReferencesTo(ref);
  io.remove();
  toast(io.done, 'ok', { label: 'Annuler', cb: () => { io.restore(); refs.undo(); } });
  return true;
}

/** Suppression EN MASSE (ex. « Vider les terminés ») : même garantie que removeObject, pour plusieurs objets d'un coup.
 *  Les liens de chacun sont nettoyés avant le retrait ; UN seul « Annuler » remet la collection ET tous les liens
 *  (dans l'ordre inverse du nettoyage). `remove` doit relire la collection au moment de l'appel (après le nettoyage des liens). */
export function removeObjects(refs: Ref[], io: { remove: () => void; restore: () => void; done: string }): number {
  const undos = refs.map(r => removeAllReferencesTo(r).undo);
  io.remove();
  toast(io.done, 'ok', { label: 'Annuler', cb: () => { io.restore(); [...undos].reverse().forEach(u => u()); } });
  return refs.length;
}
