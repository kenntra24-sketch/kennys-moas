/* Synchronisation Google Drive — usage personnel.
   Sauvegarde / restauration dans un dossier VISIBLE « KENNY'S MOAS » de ton « Mon Drive » (scope « drive.file » :
   l'appli ne voit et ne touche qu'aux fichiers et dossiers qu'elle a elle-même créés, jamais à tes autres fichiers).
   (Avant, le scope « drive.appdata » rangeait la sauvegarde dans un espace caché qui n'apparaît pas dans Mon Drive.)
   Connexion via Google Identity Services (jeton d'accès en mémoire uniquement, jamais écrit sur le disque).
   Prérequis côté Google Cloud : API Google Drive activée, origines JS autorisées http://127.0.0.1:8765 et http://localhost:8765,
   et ton adresse Google ajoutée comme « utilisateur test » si l'écran de consentement est en mode Test. */
import { useSyncExternalStore } from 'react';
import type { DriveStatus } from '../types';
import { importJSON, lightPayload } from './backup';
import { toast } from './toast';

/* Identifiants Google : lus dans « config.local.js » (window.KM_GOOGLE), fichier PERSONNEL (ici inclus volontairement dans le dépôt, usage personnel).
   Modèle : public/config.local.example.js. Les identifiants ne sont jamais en dur dans le code : seulement dans ce fichier. */
const cfg = () => ((window as any).KM_GOOGLE || {}) as { clientId?: string; apiKey?: string };  // eslint-disable-line @typescript-eslint/no-explicit-any
const clean = (v?: string) => (v && !/^REMPLACE_/.test(v) ? v : '');
export const GOOGLE_CLIENT_ID = () => clean(cfg().clientId);
export const GOOGLE_API_KEY = () => clean(cfg().apiKey);
export const driveConfigured = () => !!(GOOGLE_CLIENT_ID() && GOOGLE_API_KEY());
const SCOPE = 'https://www.googleapis.com/auth/drive.file';
const FOLDER_NAME = "KENNY'S MOAS";
const FOLDER_KEY = 'km:driveFolder';   // lien du dossier (hors sauvegardes)
export const driveFolderLink = (): string => { try { return localStorage.getItem(FOLDER_KEY) || ''; } catch { return ''; } };
const FILE_NAME = 'kennys-moas-sauvegarde.json';
const OK_KEY = 'km:driveOk2';            // hors préfixe « me: » : ne fait pas partie des sauvegardes/exports
const LAST_KEY = 'km:driveLastSave';    // heure (ms) de la dernière sauvegarde réussie faite depuis cet appareil ; même règle : hors sauvegardes

/* ── état observable (pastille « Drive » de la barre du haut + carte de Réglages) ── */
let status: DriveStatus = 'disconnected';
const listeners = new Set<() => void>();
const setStatus = (s: DriveStatus) => { if (s !== status) { status = s; listeners.forEach(l => l()); } };
const subscribe = (l: () => void) => { listeners.add(l); return () => { listeners.delete(l); }; };
export const useDriveStatus = () => useSyncExternalStore(subscribe, () => status);
/** Heure de la dernière sauvegarde réussie depuis cet appareil (0 = jamais). */
export const lastDriveSave = (): number => { try { return Number(localStorage.getItem(LAST_KEY)) || 0; } catch { return 0; } };
export const useLastDriveSave = () => useSyncExternalStore(subscribe, lastDriveSave);

/* ── jeton d'accès (mémoire seulement) ── */
/* eslint-disable @typescript-eslint/no-explicit-any */
let token: string | null = null, tokenExp = 0, gis: Promise<void> | null = null;

function loadGIS(): Promise<void> {
  if ((window as any).google?.accounts?.oauth2) return Promise.resolve();
  if (!gis) gis = new Promise<void>((res, rej) => {
    const s = document.createElement('script');
    s.src = 'https://accounts.google.com/gsi/client'; s.async = true; s.defer = true;
    s.onload = () => res(); s.onerror = () => { gis = null; s.remove(); rej(new Error('gis')); };
    document.head.appendChild(s);
  });
  return gis;
}
function requestToken(prompt: '' | 'consent'): Promise<string> {
  return new Promise((resolve, reject) => {
    const client = (window as any).google.accounts.oauth2.initTokenClient({
      client_id: GOOGLE_CLIENT_ID(), scope: SCOPE,
      callback: (r: any) => {
        if (r.error || !r.access_token) return reject(new Error(r.error || 'no_token'));
        token = r.access_token as string; tokenExp = Date.now() + ((+r.expires_in || 3600) - 60) * 1000; resolve(token);
      },
      error_callback: (e: any) => reject(new Error(e?.type || 'popup')),
    });
    client.requestAccessToken({ prompt });
  });
}
async function ensureToken(): Promise<string> {
  if (!driveConfigured()) throw new Error('not_configured');
  if (token && Date.now() < tokenExp) return token;
  await loadGIS();
  const t = await requestToken(localStorage.getItem(OK_KEY) ? '' : 'consent');
  localStorage.setItem(OK_KEY, '1'); setStatus('connected');
  return t;
}

/* ── appels REST Drive ── */
class DriveHttpError extends Error { constructor(public code: number, m: string) { super(m); } }
async function api(url: string, init: RequestInit = {}): Promise<Response> {
  const t = await ensureToken();
  const u = url + (url.includes('?') ? '&' : '?') + 'key=' + encodeURIComponent(GOOGLE_API_KEY());
  let r: Response;
  try { r = await fetch(u, { ...init, headers: { ...(init.headers || {}), Authorization: `Bearer ${t}` } }); }
  catch { setStatus('offline'); throw new Error('offline'); }
  if (r.status === 401) { token = null; tokenExp = 0; setStatus('disconnected'); }
  if (!r.ok) throw new DriveHttpError(r.status, (await r.text().catch(() => '')).slice(0, 300));
  return r;
}
export type RemoteInfo = { id: string; modifiedTime: string; size?: string } | null;
const enc = encodeURIComponent;
/* Dossier « KENNY'S MOAS » dans Mon Drive : on le retrouve (parmi ceux créés par l'appli) ou on le crée. */
async function ensureFolder(): Promise<string> {
  const q = enc(`name='${FOLDER_NAME.replace(/'/g, "\\'")}' and mimeType='application/vnd.google-apps.folder' and trashed=false`);
  const r = await api(`https://www.googleapis.com/drive/v3/files?q=${q}&fields=files(id,webViewLink)&pageSize=1`);
  const f = (await r.json()).files?.[0];
  if (f) { try { localStorage.setItem(FOLDER_KEY, f.webViewLink || `https://drive.google.com/drive/folders/${f.id}`); } catch { /* facultatif */ } return f.id as string; }
  const c = await api('https://www.googleapis.com/drive/v3/files?fields=id,webViewLink', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: FOLDER_NAME, mimeType: 'application/vnd.google-apps.folder' }) });
  const j = await c.json();
  try { localStorage.setItem(FOLDER_KEY, j.webViewLink || `https://drive.google.com/drive/folders/${j.id}`); } catch { /* facultatif */ }
  return j.id as string;
}
async function findIn(folder: string, name: string): Promise<RemoteInfo> {
  const q = enc(`name='${name}' and '${folder}' in parents and trashed=false`);
  const r = await api(`https://www.googleapis.com/drive/v3/files?q=${q}&fields=files(id,modifiedTime,size)&orderBy=modifiedTime%20desc&pageSize=1`);
  const j = await r.json(); return j.files?.[0] || null;
}
async function findRemote(): Promise<RemoteInfo> { return findIn(await ensureFolder(), FILE_NAME); }
/* Crée ou met à jour un fichier JSON dans le dossier. */
async function upsert(folder: string, name: string, body: string): Promise<{ id: string; modifiedTime: string }> {
  const ex = await findIn(folder, name);
  const b = 'kmoas' + Date.now();
  const meta = ex ? { name } : { name, parents: [folder] };
  const multipart = `--${b}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${JSON.stringify(meta)}\r\n--${b}\r\nContent-Type: application/json\r\n\r\n${body}\r\n--${b}--`;
  const url = ex ? `https://www.googleapis.com/upload/drive/v3/files/${ex.id}?uploadType=multipart&fields=id,modifiedTime` : 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,modifiedTime';
  const r = await api(url, { method: ex ? 'PATCH' : 'POST', headers: { 'Content-Type': `multipart/related; boundary=${b}` }, body: multipart });
  return r.json();
}

/* ── erreurs lisibles ── */
function explain(e: unknown): string {
  const m = e instanceof Error ? e.message : String(e);
  if (m === 'not_configured') return 'Google Drive n’est pas configuré : crée le fichier config.local.js (voir le README)';
  if (m === 'gis') return 'Impossible de joindre Google (connexion internet ?)';
  if (m === 'offline') return 'Hors ligne — impossible de joindre Google Drive';
  if (/popup_closed|access_denied/.test(m)) return 'Connexion annulée';
  if (/popup_failed_to_open/.test(m)) return 'Fenêtre de connexion bloquée par le navigateur — autorise les pop-ups pour cette page';
  if (/redirect_uri|origin_mismatch|invalid_client/.test(m)) return 'Google refuse cette adresse : ajoute http://127.0.0.1:8765 aux origines autorisées de l’ID client';
  if (e instanceof DriveHttpError) {
    if (e.code === 403 && /accessNotConfigured|has not been used|disabled/i.test(e.message)) return 'L’API Google Drive n’est pas activée dans ton projet Google Cloud';
    if (e.code === 403) return 'Accès refusé par Google (clé API restreinte, ou compte non ajouté comme utilisateur test ?)';
    if (e.code === 401) return 'Session Google expirée — reconnecte-toi';
    return `Erreur Google Drive (${e.code})`;
  }
  return 'Erreur Google Drive';
}
async function run<T>(fn: () => Promise<T>): Promise<T | undefined> {
  try { return await fn(); }
  catch (e) {
    console.error('[Drive]', e);
    const msg = explain(e);
    if (status !== 'offline' && status !== 'disconnected' && msg !== 'Connexion annulée') setStatus('error');
    toast(msg, msg === 'Connexion annulée' ? 'warn' : 'err');
  }
}

/* ── actions ── */
export const connectDrive = () => run(async () => { await ensureToken(); toast('Google Drive connecté'); return remoteInfo(); });
export function disconnectDrive() {
  try { if (token) (window as any).google?.accounts?.oauth2?.revoke(token, () => {}); } catch { /* ignore */ }
  token = null; tokenExp = 0; localStorage.removeItem(OK_KEY); setStatus('disconnected'); toast('Google Drive déconnecté');
}
export const remoteInfo = () => run(async () => (await findRemote()) as RemoteInfo);

export const pushToDrive = () => run(async () => {
  await ensureToken();            // d'abord : la fenêtre Google doit s'ouvrir dans le geste du clic (sinon bloquée)
  setStatus('syncing');
  const body = JSON.stringify(await lightPayload());
  const folder = await ensureFolder();
  const j = await upsert(folder, FILE_NAME, body);                                  // sauvegarde la plus récente
  const day = new Date().toISOString().slice(0, 10);
  try { await upsert(folder, `kennys-moas-${day}.json`, body); } catch (e) { console.warn('[Drive] copie datée non créée', e); }   // une copie par jour (historique)
  try { localStorage.setItem(LAST_KEY, String(Date.now())); } catch { /* stockage plein : l'heure n'est juste pas retenue */ }
  setStatus('connected'); toast(`Sauvegardé dans le dossier « ${FOLDER_NAME} » de ton Drive`);
  return { id: j.id as string, modifiedTime: j.modifiedTime as string } as RemoteInfo;
});

export const pullFromDrive = () => run(async () => {
  await ensureToken(); setStatus('syncing');
  const ex = await findRemote();
  if (!ex) { setStatus('connected'); toast(`Aucune sauvegarde dans le dossier « ${FOLDER_NAME} » — fais d’abord « Sauvegarder maintenant »`, 'warn'); return; }
  const r = await api(`https://www.googleapis.com/drive/v3/files/${ex.id}?alt=media`);
  const text = await r.text();
  setStatus('connected');
  await importJSON(new File([text], FILE_NAME, { type: 'application/json' }));
});
