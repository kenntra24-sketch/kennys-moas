import { askText } from './ask';
import { chooseOption } from './choose';
import { dbAll, dbDel, dbGet, dbPut, type LibFile, type ReadState } from './db';
import { CATEGORY_LABEL, LIB_CATEGORIES, type Homework, type LibCategory } from './model';
import { categoryFor } from './migrate';
import { describeRelated, relatedCount, removeAllReferencesTo, repointReferences } from './relations';
import { getClass, getData, notifyStore, update } from './store';
import { toast } from './toast';
import { uid } from './util';

export type Kind = 'pdf' | 'image' | 'doc' | 'other';
export const kindOf = (f: { name: string; type: string }): Kind => {
  if (/pdf/i.test(f.type) || /\.pdf$/i.test(f.name)) return 'pdf';
  if (/^image\//.test(f.type) || /\.(png|jpe?g|gif|webp|svg)$/i.test(f.name)) return 'image';
  if (/word|excel|powerpoint|officedocument|\.(docx?|xlsx?|pptx?|odt|txt)$/i.test(f.type + f.name)) return 'doc';
  return 'other';
};
/** Fichiers de la classe courante uniquement (comme l'original : `classId`). */
export const listFiles = async (): Promise<LibFile[]> => (await dbAll<LibFile>('files')).filter(f => f.classId === getClass()).sort((a, b) => b.date - a.date);

/* Nom « nettoyé » d'un fichier pour la détection de quasi-doublon (voir importFiles) : retire
   les suffixes de copie/version les plus courants qu'un système ajoute automatiquement (photo
   reprise, export PDF régénéré, "(1)", "copie"...). Portage fidèle de `coreFileName()` de
   l'app d'origine (public/legacy/index.html) — ne pas diverger de cette logique sans porter le
   changement des deux côtés. */
export function coreFileName(name: string): string {
  let s = name.replace(/\.[^./\\]+$/, '').toLowerCase().trim();
  for (let i = 0; i < 3; i++) {
    s = s
      .replace(/\s*\(\d+\)\s*$/, '')
      .replace(/[-_ ]?(copie|copy)\s*\d*$/i, '')
      .replace(/[-_ ]?v(?:ersion)?\s*\d+$/i, '')
      .replace(/[-_ ]?final\s*\d*$/i, '')
      .replace(/[-_ ]?nouvelle?\s*\d*$/i, '')
      .trim();
  }
  return s;
}

/* Repère les noms de fichier peu explicites (photo/scan tels quels : IMG_20260917_142033,
   Scan_0001, que des chiffres...). Portage fidèle de `looksLikeUnclearFileName()` de l'app
   d'origine. Simple heuristique sur le nom — jamais un renommage automatique, seulement un
   rappel proposé dans un toast. */
export function looksLikeUnclearFileName(name: string): boolean {
  const base = name.replace(/\.[^./\\]+$/, '').trim();
  return /^(img|image|photo|pic|scan|dscn?|document|doc|screenshot|capture|whatsapp[\s_-]?image|pi[eè]ce[\s_-]?jointe)[\s_-]*\d*$/i.test(base) || /^\d{4,}$/.test(base);
}

/* Catégories proposées à l'import (P1) : 4 catégories + « Devoir » qui crée aussi un devoir relié. Libellés courts, jamais « Fiche de révision ». */
export const LIB_IMPORT_TYPES: [LibCategory, string, string][] = [
  ['cours', 'Cours', 'Leçon ou contenu de cours à apprendre.'],
  ['fiche', 'Fiche', 'Résumé, méthode ou schéma à relire pour réviser.'],
  ['exercice', 'Exercice', 'Exercices ou sujets pour t’entraîner.'],
  ['notes', 'Notes', 'Ce que tu as noté ou photographié en cours.'],
];
export const HW_IMPORT_TYPES: [string, string, string][] = [
  ['devoir', 'Devoir', 'Crée aussi un devoir relié dans l’onglet Devoirs.'],
  ['exercice', 'Exercice à rendre', 'Crée aussi un exercice relié dans l’onglet Devoirs.'],
];
/** Ancien libellé de type → libellé de catégorie. Les anciens fichiers gardent leur `libraryType`, on affiche la catégorie. */
export const libTypeLabel = (k?: string | null) => { const c = categoryFor({ libraryType: k }); return c ? CATEGORY_LABEL[c] : ''; };
export const fileCategory = (f: Pick<LibFile, 'category' | 'libraryType' | 'homeworkType'>): LibCategory | null => categoryFor(f);
export const fileCategoryLabel = (f: Pick<LibFile, 'category' | 'libraryType' | 'homeworkType'>) => { const c = categoryFor(f); return c ? CATEGORY_LABEL[c] : ''; };
void LIB_CATEGORIES;

export async function importFiles(files: File[], meta: { subject?: string; libraryType?: string | null; homeworkType?: string | null; skipType?: boolean } = {}): Promise<string[]> {
  if (!meta.skipType && meta.libraryType === undefined && meta.homeworkType === undefined) {
    const k = await chooseOption(files.length > 1 ? 'Que sont ces fichiers ?' : 'Qu’est-ce que ce fichier ?', [
      ...LIB_IMPORT_TYPES.map(([key, label, desc]) => ({ key: 'lib:' + key, label, desc, group: 'Bibliothèque' })),
      ...HW_IMPORT_TYPES.map(([key, label, desc]) => ({ key: 'hw:' + key, label, desc, group: 'Devoirs' })),
    ]);
    if (!k) return [];
    meta = { ...meta, libraryType: k.startsWith('lib:') ? k.slice(4) : null, homeworkType: k.startsWith('hw:') ? k.slice(3) : null };
  }
  const existing = await listFiles(); const ids: string[] = []; let dup = 0; const dupIds: string[] = [];
  const seen = new Set(existing.map(e => e.name + '|' + e.size));
  const byCore = new Map<string, LibFile>();
  existing.forEach(e => { const c = coreFileName(e.name); if (!byCore.has(c)) byCore.set(c, e); });
  /* id du fichier déjà présent -> nom du nouveau fichier qui lui ressemble (quasi-doublon). */
  const nearDup = new Map<string, { name: string; newId: string }>();
  const unclearIds: string[] = [];
  for (const f of files) {
    const key = f.name + '|' + f.size;
    if (seen.has(key)) { dup++; const m = existing.find(e => e.name + '|' + e.size === key); if (m) dupIds.push(m.id); continue; }
    seen.add(key);
    const match = byCore.get(coreFileName(f.name));
    const id = uid();
    const rec: LibFile = { id, name: f.name, type: f.type, size: f.size, date: Date.now(), subject: meta.subject || '', chapter: '', classId: getClass(), fav: false, lastOpened: 0, progress: 0, blob: f, libraryType: meta.libraryType || null, homeworkType: meta.homeworkType || null, category: categoryFor({ libraryType: meta.libraryType, homeworkType: meta.homeworkType }), tags: [] };
    try {
      await dbPut('files', rec); ids.push(id);
      if (match) nearDup.set(match.id, { name: f.name, newId: id });
      if (looksLikeUnclearFileName(f.name)) unclearIds.push(id);
    } catch (e) { console.error(e); toast(`Échec de l’import de « ${f.name} » (stockage plein ?)`, 'err'); }
  }
  if (meta.homeworkType && ids.length) {
    const hw: Homework[] = [];
    for (const id of ids) {
      const r = await dbGet<LibFile>('files', id);
      hw.push({ id: uid(), title: r ? r.name.replace(/\.[^.]+$/, '') : 'Travail importé', subject: meta.subject || '', due: '', priority: 'normale', type: meta.homeworkType, desc: 'Importé depuis un fichier', fileId: id, reminder: null, done: false, links: [] });
    }
    update('homework', cur => [...cur, ...hw]);
  }
  notifyStore();
  if (ids.length) toast(`${ids.length} fichier${ids.length > 1 ? 's' : ''} importé${ids.length > 1 ? 's' : ''}${dup ? ` · ${dup} déjà présent${dup > 1 ? 's' : ''} sous le même nom` : ''}`);
  /* Un seul quasi-doublon détecté dans le lot → on propose un remplacement explicite ; s'il y
     en a plusieurs, on préfère ne rien dire plutôt que de risquer une suggestion ambiguë (même
     règle que la suggestion de matière). Jamais de remplacement automatique. */
  /* Fichier déjà présent, rien de nouveau : on le dit (avant, l'import restait muet) et, depuis un
     champ « Fichier associé » (skipType), on renvoie l'id de l'existant pour qu'il soit sélectionné. */
  if (!ids.length && dup) {
    toast(meta.skipType && dupIds.length ? 'Fichier déjà présent — utilisation de l’existant' : `${dup > 1 ? dup + ' fichiers déjà présents' : 'Fichier déjà présent'} dans la Bibliothèque — rien d’importé`);
    if (meta.skipType && dupIds.length) return dupIds;
  }
  if (nearDup.size === 1) {
    const [oldId, nd] = [...nearDup.entries()][0];
    const oldFile = existing.find(e => e.id === oldId);
    if (oldFile) {
      toast(`« ${nd.name} » ressemble à « ${oldFile.name} » déjà présent — nouvelle version ?`, 'ok', {
        label: "Remplacer l'ancien",
        cb: async () => { if (await replaceFile(oldId, nd.newId)) toast('Ancien fichier remplacé — associations conservées'); },
      });
    }
  }
  if (unclearIds.length === 1) {
    const fid = unclearIds[0];
    toast('Nom de fichier peu clair — le renommer ?', 'ok', {
      label: 'Renommer',
      cb: async () => {
        const f = await dbGet<LibFile>('files', fid); if (!f) return;
        const ext = (f.name.match(/\.[^./\\]+$/) || [''])[0];
        const base = f.name.replace(/\.[^./\\]+$/, '');
        const n = await askText('Renommer le fichier', 'Nouveau nom', base);
        if (n) { await patchFile(fid, { name: n + ext }); toast('Fichier renommé'); }
      },
    });
  } else if (unclearIds.length > 1) {
    toast(`${unclearIds.length} fichiers importés ont un nom peu clair (photo/scan) — tu peux les renommer depuis la Bibliothèque (✎)`, 'ok');
  }
  return ids;
}
export async function patchFile(id: string, patch: Partial<LibFile>) { const f = await dbGet<LibFile>('files', id); if (f) { await dbPut('files', { ...f, ...patch }); notifyStore(); } }
/** Enregistrement remplaçant : blob, taille, type MIME et date viennent du nouveau fichier ; id, nom, matière, catégorie, favori, tags,
    chapitre, dernière ouverture (et tout champ inconnu) restent ceux de l'ancien. La progression de lecture est remise à zéro (le contenu a changé). */
export function mergeReplacement(old: LibFile, incoming: LibFile): LibFile {
  return { ...old, blob: incoming.blob, size: incoming.size, type: incoming.type, date: incoming.date, progress: 0 };
}
/** « Remplacer l'ancien » : l'ancien enregistrement est ÉCRASÉ en gardant son id → toutes les associations (devoirs, notes, remarques…) restent valides.
    Le fichier tout juste importé (`newId`) est supprimé et ses références (ex. devoir créé à l'import) sont réaffectées à l'id d'origine.
    Marque-pages et page de reprise (magasin `read`) sont effacés : le contenu a changé, les anciennes pages ne veulent plus rien dire. */
export async function replaceFile(oldId: string, newId: string): Promise<boolean> {
  if (oldId === newId) return false;
  const [old, inc] = [await dbGet<LibFile>('files', oldId), await dbGet<LibFile>('files', newId)];
  if (!old || !inc) { toast('Remplacement impossible : un des deux fichiers a disparu', 'err'); return false; }
  await dbPut('files', mergeReplacement(old, inc));           // 1) l'ancien id reçoit le nouveau contenu
  repointReferences({ type: 'file', id: newId }, { type: 'file', id: oldId }); // 2) ce qui pointait vers le doublon pointe vers l'id d'origine
  await dbDel('files', newId);                                 // 3) le doublon disparaît
  await dbDel('read', oldId).catch(() => {});                  // 4) reprise/marque-pages remis à zéro
  notifyStore(); return true;
}

/** Suppression propre : confirmation qui dit ce qui est lié, nettoyage des références, « Annuler » complet (fichier + liens). */
export async function removeFile(id: string) {
  const f = await dbGet<LibFile>('files', id); if (!f) return;
  const ref = { type: 'file' as const, id }, used = describeRelated(ref);
  const importedHw = getData('homework').filter(h => h.fileId === id && h.desc === 'Importé depuis un fichier' && !h.done);
  const opts = [{ key: 'keep', label: 'Supprimer le fichier', desc: (used ? `${used} ${relatedCount(ref) > 1 ? 'utilisent' : 'utilise'} ce fichier. ${relatedCount(ref) > 1 ? 'Ils sont conservés' : 'Il est conservé'}, sans ce fichier.` : 'Ce fichier n’est lié à rien.') }];
  if (importedHw.length) opts.push({ key: 'both', label: 'Supprimer le fichier et le devoir créé à l’import', desc: `${importedHw.length > 1 ? importedHw.length + ' devoirs' : '1 devoir'} créé${importedHw.length > 1 ? 's' : ''} automatiquement à l’import ${importedHw.length > 1 ? 'seront supprimés' : 'sera supprimé'}.` });
  const k = await chooseOption(`Supprimer « ${f.name} » ?`, opts);
  if (!k) return;
  if (k === 'both') update('homework', cur => cur.filter(h => !importedHw.some(x => x.id === h.id)));
  const refs = removeAllReferencesTo(ref);
  await dbDel('files', id); notifyStore();
  toast('Fichier supprimé', 'ok', { label: 'Annuler', cb: async () => { await dbPut('files', f); if (k === 'both') update('homework', cur => [...cur, ...importedHw.filter(h => !cur.some(c => c.id === h.id))]); refs.undo(); notifyStore(); } });
}
/* RÈGLE `progress` (v1.4.1, Phase 0) : `files.progress` = POURCENTAGE 0-100 lu (sens de l'app d'origine).
   La page de reprise vit dans le magasin `read` (`{id, page, zoom, mode, bookmarks}`). Les anciennes valeurs écrites par la
   v1.3.x (numéro de page) ne sont ni migrées ni utilisées pour la reprise ; elles sont corrigées à la prochaine ouverture. */
export const progressPct = (page: number, pages: number) => (pages > 0 ? Math.max(0, Math.min(100, Math.round(page / pages * 100))) : 0);
export const getRead = (id: string) => dbGet<ReadState>('read', id);
export async function saveRead(id: string, patch: Partial<ReadState>) { const cur = await dbGet<ReadState>('read', id); await dbPut('read', { ...cur, ...patch, id }); }
export async function openTracked(id: string) { await patchFile(id, { lastOpened: Date.now() }); }

/* DIAGNOSTIC PHASE 1 (confirmé par test réel dans un navigateur) : le build officiel Mozilla local
   de pdf.min.mjs appelle `Map.prototype.getOrInsertComputed` (proposition TC39 « Map upsert » très
   récente) dans WorkerTransport.getOptionalContentConfig(), appelée à CHAQUE rendu de page. Sur tout
   moteur JS qui ne l'implémente pas encore, page.render() lève une TypeError — le rendu échoue à
   100 %, silencieusement, car l'ancien code avalait l'erreur (`.catch(() => {})`), donnant l'illusion
   d'un lecteur qui marche alors que le canvas restait vide. On corrige ici par un polyfill minimal
   plutôt qu'en remplaçant le PDF.js vendored (aucun accès réseau requis, aucune régression possible
   si la méthode native existe déjà). Objectif : que ce polyfill devienne inutile dès que les
   navigateurs ciblés supportent nativement la méthode ; il ne fait rien dans ce cas (garde `if`). */
function polyfillMapUpsert(target: any) {
  const proto = target?.prototype; if (!proto) return;
  if (typeof proto.getOrInsertComputed !== 'function') {
    Object.defineProperty(proto, 'getOrInsertComputed', {
      value(this: Map<any, any>, key: any, fn: (key: any) => any) {
        if (this.has(key)) return this.get(key);
        const v = fn(key); this.set(key, v); return v;
      },
      writable: true, configurable: true,
    });
  }
  if (typeof proto.getOrInsert !== 'function') {
    Object.defineProperty(proto, 'getOrInsert', {
      value(this: Map<any, any>, key: any, value: any) {
        if (this.has(key)) return this.get(key);
        this.set(key, value); return value;
      },
      writable: true, configurable: true,
    });
  }
}

/* PDF.js local (build officiel Mozilla, /pdf.min.mjs) — chargé à la demande, jamais depuis un CDN. */
let pdfjs: any;
export async function loadPdfJs() {
  if (!pdfjs) {
    polyfillMapUpsert(Map); polyfillMapUpsert(WeakMap);
    const base = document.baseURI;
    pdfjs = await import(/* @vite-ignore */ new URL('pdf.min.mjs', base).href);
    pdfjs.GlobalWorkerOptions.workerSrc = new URL('pdf.worker.min.mjs', base).href;
  }
  return pdfjs;
}
