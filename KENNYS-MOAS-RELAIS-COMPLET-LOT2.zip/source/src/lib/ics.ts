import type { CalEvent, Homework } from './model';
import { EVENT_TYPES, TASK_TYPES } from './model';
import { download, isoAddDays, pad, todayISO } from './util';

/* Export calendrier natif (.ics) : événements + échéances de devoirs, avec rappels (VALARM).
   Compatible Apple Calendar / Google Agenda / Outlook. Le format « tout-le-jour » est utilisé sans heure. */
export const esc = (s: string) => String(s ?? '').replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\r?\n/g, '\\n');
export const fold = (l: string) => { const out: string[] = []; let s = l; while (s.length > 74) { out.push(s.slice(0, 74)); s = ' ' + s.slice(74); } out.push(s); return out.join('\r\n'); };
export const d8 = (iso: string) => iso.replace(/-/g, '');
export const stamp = () => { const n = new Date(); return `${n.getUTCFullYear()}${pad(n.getUTCMonth() + 1)}${pad(n.getUTCDate())}T${pad(n.getUTCHours())}${pad(n.getUTCMinutes())}${pad(n.getUTCSeconds())}Z`; };
const label = (list: [string, string][], t: string) => list.find(x => x[0] === t)?.[1] || t;

export function buildICS(events: CalEvent[], homework: Homework[], cls: string): string {
  const L = ['BEGIN:VCALENDAR', 'VERSION:2.0', "PRODID:-//KENNY'S MOAS//FR", 'CALSCALE:GREGORIAN', `X-WR-CALNAME:${esc("KENNY'S MOAS — " + cls)}`];
  const alarm = (min: number, title: string) => ['BEGIN:VALARM', 'ACTION:DISPLAY', `DESCRIPTION:${esc(title)}`, `TRIGGER:-PT${min}M`, 'END:VALARM'];
  for (const e of events) {
    const timed = /^\d{2}:\d{2}$/.test(e.time || '');
    L.push('BEGIN:VEVENT', `UID:${e.id}@kennys-moas`, `DTSTAMP:${stamp()}`);
    if (timed) { const t = e.time.replace(':', ''); L.push(`DTSTART:${d8(e.date)}T${t}00`, `DTEND:${d8(e.date)}T${pad(Math.min(23, +e.time.slice(0, 2) + 1))}${e.time.slice(3)}00`); }
    else L.push(`DTSTART;VALUE=DATE:${d8(e.date)}`, `DTEND;VALUE=DATE:${d8(isoAddDays(e.date, 1))}`);
    L.push(`SUMMARY:${esc(`${label(EVENT_TYPES, e.type)} — ${e.title}${e.subject ? ' (' + e.subject + ')' : ''}`)}`);
    if (e.desc) L.push(`DESCRIPTION:${esc(e.desc)}`);
    if (e.reminder && timed) L.push(...alarm(+e.reminder, e.title));
    L.push('END:VEVENT');
  }
  for (const h of homework) {
    if (!h.due || h.done) continue;
    L.push('BEGIN:VEVENT', `UID:hw-${h.id}@kennys-moas`, `DTSTAMP:${stamp()}`, `DTSTART;VALUE=DATE:${d8(h.due)}`, `DTEND;VALUE=DATE:${d8(isoAddDays(h.due, 1))}`,
      `SUMMARY:${esc(`${label(TASK_TYPES, h.type)} — ${h.title}${h.subject ? ' (' + h.subject + ')' : ''}`)}`);
    if (h.desc) L.push(`DESCRIPTION:${esc(h.desc)}`);
    L.push('END:VEVENT');
  }
  L.push('END:VCALENDAR');
  return L.map(fold).join('\r\n');
}
export const exportICS = (events: CalEvent[], homework: Homework[], cls: string) =>
  download(`kennys-moas-agenda-${todayISO()}.ics`, new Blob([buildICS(events, homework, cls)], { type: 'text/calendar;charset=utf-8' }));
