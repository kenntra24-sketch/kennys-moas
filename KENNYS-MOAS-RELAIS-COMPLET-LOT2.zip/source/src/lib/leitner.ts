import type { ErrorItem } from './model';
import { PALIERS } from './model';
import { isoOf, todayISO } from './util';

/** Répétition espacée (Leitner) — portage exact de planifierRevision / erreursDues / migration. */
export function planifier(e: ErrorItem, reussie: boolean): ErrorItem {
  const boite = reussie ? Math.min((e.boite ?? 0) + 1, PALIERS.length - 1) : 0;
  const d = new Date(); d.setDate(d.getDate() + PALIERS[boite]);
  return { ...e, boite, prochaineRevision: isoOf(d) };
}
export const erreursDues = (es: ErrorItem[], subject?: string | null) => {
  const auj = todayISO();
  return es.filter(e => (e.prochaineRevision ?? auj) <= auj && (!subject || e.subject === subject));
};
export const migrateErrors = (es: ErrorItem[]): { list: ErrorItem[]; changed: boolean } => {
  let changed = false;
  const list = es.map(e => { if (e.boite == null || e.prochaineRevision == null) { changed = true; return { ...e, boite: 0, prochaineRevision: todayISO(), links: e.links || [] }; } return e; });
  return { list, changed };
};
