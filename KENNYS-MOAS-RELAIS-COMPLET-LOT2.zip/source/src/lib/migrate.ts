/* migrate.ts — migration idempotente vers le schéma 2 (pièce 1). RÈGLES : on AJOUTE, on ne supprime ni ne renomme jamais
   (l'app d'origine, public/legacy, lit les mêmes clés) ; les valeurs par défaut n'écrasent jamais une valeur existante ;
   relancer la migration N fois donne le même résultat. La version de schéma est stockée par classe : `me:<classe>:schemaVersion`. */
import { dbAll, dbPut, type LibFile } from './db';
import { LIB_CATEGORIES, SCHEMA_VERSION, type Link, type LibCategory } from './model';
import { LS, notifyStore } from './store';
import { slug } from './util';

type Obj = Record<string, any>;
const COLLS = ['subjects', 'grades', 'homework', 'errors', 'events', 'sessions'] as const;

/** Classes ayant des données dans le localStorage (`me:<classe>:<clé>`). */
export function classesWithData(): string[] {
  const out = new Set<string>();
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const m = /^me:(.+):(subjects|grades|homework|errors|events|sessions)$/.exec(localStorage.key(i) || '');
      if (m) out.add(m[1]);
    }
  } catch { /* stockage indisponible */ }
  return [...out];
}

/** Ancienne valeur `libraryType`/`homeworkType` → catégorie. Décisions : « Autre support » → cours ; devoir / exercice / « Autre travail » → exercice ;
    rien de reconnu → null (le fichier reste « non classé », on n'invente rien). */
export function categoryFor(f: { libraryType?: string | null; homeworkType?: string | null; category?: string | null }): LibCategory | null {
  if (f.category && (LIB_CATEGORIES as readonly string[]).includes(f.category)) return f.category as LibCategory;
  const t = String(f.libraryType || '').toLowerCase();
  if (t === 'cours' || t === 'autre-support') return 'cours';
  if (t.startsWith('fiche') || t === 'schema' || /^fiche/.test(t)) return 'fiche';
  if (t === 'note-classe' || t === 'notes' || t === 'note') return 'notes';
  if (t === 'exercice') return 'exercice';
  if (f.homeworkType) return 'exercice';
  // libellés affichés (anciennes sauvegardes)
  if (/^fiche/.test(t) || /fiche/.test(t)) return 'fiche';
  if (/note de classe/.test(t)) return 'notes';
  if (/autre travail/.test(t)) return 'exercice';
  return null;
}

const linkKey = (l: Link) => l.type + '|' + l.id;
function addUnique(links: unknown, add: Link[]): unknown[] {
  const base: unknown[] = Array.isArray(links) ? links.slice() : [];
  const have = new Set(base.filter((l): l is Link => !!l && typeof l === 'object' && typeof (l as Link).id === 'string').map(linkKey));
  for (const l of add) if (!have.has(linkKey(l))) { base.push(l); have.add(linkKey(l)); }
  return base;
}
const remarkLinkType = (t: unknown): Link['type'] | null => (({ homework: 'homework', devoir: 'homework', grade: 'result', note: 'result', result: 'result', event: 'event', file: 'file', remark: 'remark' } as Record<string, Link['type']>)[String(t)] ?? null);

/** Convertit fileId / homeworkId / linkType+linkId en `links` (sans supprimer les anciens champs). */
function legacyToLinks(kind: 'homework' | 'result' | 'event' | 'remark', o: Obj): Link[] {
  const out: Link[] = [];
  if (typeof o.fileId === 'string' && o.fileId) out.push({ type: 'file', id: o.fileId });
  if (kind === 'result' && typeof o.homeworkId === 'string' && o.homeworkId) out.push({ type: 'homework', id: o.homeworkId });
  if (kind === 'remark' && o.linkId) { const t = remarkLinkType(o.linkType); if (t) out.push({ type: t, id: String(o.linkId) }); }
  return out;
}
const sameJson = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);

/** Migre UNE classe ; retourne true si quelque chose a été écrit. */
export function migrateClass(cl: string): boolean {
  const K = (k: string) => `me:${cl}:${k}`;
  let wrote = false;
  const put = (k: string, v: unknown) => { if (LS.s(K(k), v)) wrote = true; };
  const has = (k: string) => localStorage.getItem(K(k)) != null;

  // Remarques (= anciennes erreurs) : genre 'erreur', source, links, boîte Leitner conservée
  if (has('errors')) {
    const cur = LS.g<Obj[]>(K('errors'), []);
    const next = cur.map(e => {
      const n: Obj = { ...e };
      if (!n.genre) n.genre = 'erreur';
      if (n.source === undefined) { const first = legacyToLinks('remark', e)[0]; n.source = first ?? null; }
      n.links = addUnique(e.links, legacyToLinks('remark', e));
      return n;
    });
    if (!sameJson(cur, next)) put('errors', next);
  }
  for (const [key, kind] of [['homework', 'homework'], ['grades', 'result'], ['events', 'event']] as const) {
    if (!has(key)) continue;
    const cur = LS.g<Obj[]>(K(key), []);
    const next = cur.map(o => { const add = legacyToLinks(kind, o); const links = addUnique(o.links, add); return sameJson(links, o.links) ? o : { ...o, links }; });
    if (!sameJson(cur, next)) put(key, next);
  }
  if (has('sessions')) {
    const cur = LS.g<Obj[]>(K('sessions'), []);
    const next = cur.map(s => (Array.isArray(s.links) ? s : { ...s, links: [] }));
    if (!sameJson(cur, next)) put('sessions', next);
  }
  // Matières : ajoute `id` (slug unique) sans toucher à `name` ni `coef` ; `color`/`icon` viendront en pièce 2
  if (has('subjects')) {
    const cur = LS.g<Obj[]>(K('subjects'), []);
    const used = new Set(cur.map(s => s.id).filter(Boolean));
    const next = cur.map(s => {
      if (s.id) return s;
      let id = slug(String(s.name)), i = 2; while (used.has(id)) id = slug(String(s.name)) + '-' + i++;
      used.add(id); return { ...s, id };
    });
    if (!sameJson(cur, next)) put('subjects', next);
  }
  if (LS.g<number>(K('schemaVersion'), 0) < SCHEMA_VERSION) put('schemaVersion', SCHEMA_VERSION);
  return wrote;
}

/** À appeler UNE fois au démarrage, avant le premier rendu. Aucune exception ne doit empêcher l'app de démarrer. */
export function migrateAllClasses(): boolean {
  let any = false;
  try { for (const cl of classesWithData()) if (migrateClass(cl)) any = true; } catch (e) { console.error('[MOAS] migration des données :', e); }
  if (any) notifyStore();
  return any;
}

/** Fichiers IndexedDB : ajoute `category` (l'ancien `libraryType` est conservé). Idempotent. */
export async function migrateFiles(): Promise<number> {
  let n = 0;
  try {
    for (const f of await dbAll<LibFile>('files')) {
      if (f.category) continue;
      const c = categoryFor(f);
      if (c) { await dbPut('files', { ...f, category: c }); n++; }
    }
  } catch (e) { console.error('[MOAS] migration des fichiers :', e); }
  if (n) notifyStore();
  return n;
}
