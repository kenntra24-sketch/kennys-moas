import type { ClassTimetable } from './timetable';
/* Modèle de données — IDENTIQUE à l'app d'origine (KENNY'S MOAS, refonte 2026-09-19-F) afin que les données
   déjà saisies (localStorage `me:<classe>:<clé>`, IndexedDB `monEcoleV2`) restent lisibles des deux côtés.
   Tous les champs optionnels sont conservés tels quels à l'écriture (ne jamais réduire un objet à un sous-ensemble). */
/* Matière : `id`/`color`/`icon` sont OPTIONNELS et ajoutés par la migration P1 (la personnalisation visuelle complète vient en pièce 2).
   `name` reste la clé utilisée partout dans les données existantes (grades.subject, homework.subject…). */
export interface Subj { name: string; coef: number; id?: string; color?: string; icon?: string }

/* ── Liens entre objets (pièce 1) — la seule logique de lien vit dans lib/relations.ts ── */
export const LINK_TYPES = ['file', 'homework', 'remark', 'session', 'result', 'event', 'note'] as const;
export type LinkType = (typeof LINK_TYPES)[number];
/** `page` est optionnel : il servira à « remarque faite à la page 17 » — on n'affiche jamais de page tant qu'elle n'est pas stockée. */
export interface Link { type: LinkType; id: string; page?: number }
/* Remarque = ancienne « erreur » (même magasin `errors`, même schéma, champs ajoutés — l'app d'origine reste compatible). */
export const REMARK_GENRES = ['erreur', 'à retenir', 'question', 'idée'] as const;
export type RemarkGenre = (typeof REMARK_GENRES)[number];
export const GENRE_LABEL: Record<RemarkGenre, string> = { erreur: 'Erreur', 'à retenir': 'À retenir', question: 'Question', idée: 'Idée' };
/* Catégories de document (pièce 1) : champ unique `category` ; l'ancien `libraryType` est conservé tel quel. */
export const LIB_CATEGORIES = ['cours', 'fiche', 'exercice', 'notes'] as const;
export type LibCategory = (typeof LIB_CATEGORIES)[number];
export const CATEGORY_LABEL: Record<LibCategory, string> = { cours: 'Cours', fiche: 'Fiche', exercice: 'Exercice', notes: 'Notes' };
export const SCHEMA_VERSION = 2;
export interface Grade {
  id: string; subject: string; rawScore: number; maxScore: number; value: number; coef: number;
  type?: string; date: string | number; homeworkId?: string | null; desc?: string; fileId?: string | null; links?: Link[];
  [k: string]: unknown;
}
export interface Homework {
  id: string; title: string; subject: string; due: string; priority: 'basse' | 'normale' | 'haute' | string;
  type: string; desc: string; fileId: string | null; reminder: string | null; done: boolean; links: Link[];
  [k: string]: unknown;
}
export interface ErrorItem {
  id: string; subject: string; chapter: string; question: string; mistake: string; method: string;
  fileId: string | null; linkType: string | null; linkId: string | null; date: string;
  boite?: number; prochaineRevision?: string; links?: Link[];
  /* champs « Remarque » (P1) : `genre` ('erreur' par défaut), `texte` (remarque libre hors erreur), `source` (d'où vient la remarque), `date` = créée le */
  genre?: RemarkGenre; texte?: string; source?: Link | null;
  [k: string]: unknown;
}
export interface CalEvent {
  id: string; title: string; type: string; subject: string; date: string; time: string; desc: string;
  fileId: string | null; reminder: string | null; links: Link[];
  [k: string]: unknown;
}
export interface Session { date: number; min: number; done: boolean; subject: string | null; links?: Link[] }
export interface Cell { subject: string; room?: string }
export interface AppSettings {
  mode: 'auto' | 'light' | 'dark'; primary: string; secondary: string; font: string; headingFont?: string; density: string; layout: string; textSize?: string;
  primaryCustom?: boolean; secondaryCustom?: boolean; surface?: string; radius?: string;
}
export interface Data {
  subjects: Subj[]; grades: Grade[]; homework: Homework[]; errors: ErrorItem[]; events: CalEvent[];
  sessions: Session[]; schedule: Record<string, Cell>; extraHours: string[]; hiddenHours: string[]; hiddenDays: string[]; goal: number | null;
  timetable: ClassTimetable | null;
  /** emplois du temps rangés (non actifs), pièce 5b */
  timetables: ClassTimetable[];
}
export type DataKey = keyof Data;
export const GRADE_TYPES: [string, string][] = [['devoir', 'Devoir'], ['devoir-maison', 'Devoir maison'], ['interrogation', 'Interrogation'], ['controle', 'Contrôle'], ['examen', 'Examen'], ['oral', 'Oral'], ['autre', 'Autre']];
export const GRADE_SCALES = [20, 10, 5, 100];
export const TASK_TYPES: [string, string][] = [['devoir', 'Devoir'], ['devoir-maison', 'Devoir maison'], ['exercice', 'Exercice'], ['interrogation', 'Interrogation'], ['controle', 'Contrôle'], ['examen', 'Examen'], ['echeance', 'Échéance'], ['sujet-entrainement', 'Sujet d’entraînement'], ['annales', 'Annales'], ['autre', 'Autre']];
export const SELECTABLE_TASK_TYPES = ['devoir', 'exercice', 'autre'];
export const EVENT_TYPES: [string, string][] = [['devoir', 'Devoir'], ['interrogation', 'Interrogation'], ['controle', 'Contrôle'], ['examen', 'Examen'], ['echeance', 'Échéance'], ['revision', 'Révision'], ['cours', 'Cours'], ['personnel', 'Personnel'], ['conges', 'Congés']];
export const EVCOLORS: Record<string, string> = { devoir: '#f59e0b', 'devoir-maison': '#d97706', exercice: '#0ea5e9', interrogation: '#f97316', controle: '#e74c3c', examen: '#8e44ad', echeance: '#64748b', autre: '#64748b', revision: '#2563eb', cours: '#0f766e', lecon: '#0f766e', expose: '#0891b2', personnel: '#64748b', conges: '#22c55e' };
export const CLASSES: Record<string, string[]> = { '6e': ['6e'], '5e': ['5e'], '4e': ['4e'], '3e': ['3e'], Seconde: ['Seconde A', 'Seconde C', 'Seconde D'], Première: ['Première A', 'Première A1', 'Première A2', 'Première C', 'Première D'], Terminale: ['Terminale A', 'Terminale A1', 'Terminale A2', 'Terminale C', 'Terminale D'] };
export const DAYS = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
export const HOURS = ['08h', '09h', '10h', '11h', '12h', '14h', '15h', '16h', '17h'];
export const PALIERS = [1, 3, 7, 15, 30];
