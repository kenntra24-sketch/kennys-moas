/* relations.ts — SEUL endroit où vivent les liens entre objets (aucune logique de lien dans les vues).

   Modèle : chaque objet « du store » (devoir, remarque, événement, séance, note) porte `links: Link[]`.
   Un fichier de la Bibliothèque vit dans IndexedDB : on n'y écrit PAS de liens (l'écriture serait asynchrone) ;
   ses relations sont DÉRIVÉES en relisant les objets du store (index inverse) → getRelated() est toujours à jour.

   Anciens champs, toujours lus et jamais supprimés par la migration :
     · `fileId` (devoir, note, événement, remarque)   · `linkType`/`linkId` (remarque)   · `homeworkId` (note)
   Toute écriture passe par `setData` (donc `notifyStore`). */
import { LINK_TYPES, type Data, type DataKey, type Link, type LinkType } from './model';
import { getData, setData } from './store';

export type Ref = { type: LinkType; id: string };
type Obj = Record<string, any>;

/** Types dont les objets vivent dans le store (les autres : `file` = IndexedDB, `note` = réservé, sans collection). */
const COLL: Partial<Record<LinkType, DataKey>> = { homework: 'homework', remark: 'errors', event: 'events', session: 'sessions', result: 'grades' };
const COLL_TYPE = (Object.entries(COLL) as [LinkType, DataKey][]).map(([type, key]) => ({ type, key }));

const idOf = (type: LinkType, o: Obj): string => (type === 'session' ? String(o.date) : String(o.id));
const isRef = (x: unknown): x is Link => !!x && typeof x === 'object' && LINK_TYPES.includes((x as Link).type) && typeof (x as Link).id === 'string';
const same = (a: Ref, b: Ref) => a.type === b.type && a.id === b.id;
const list = (key: DataKey): Obj[] => getData(key) as unknown as Obj[];

/** Liens implicites portés par les anciens champs (lecture seule). */
function legacyEdges(type: LinkType, o: Obj): Link[] {
  const out: Link[] = [];
  if (typeof o.fileId === 'string' && o.fileId) out.push({ type: 'file', id: o.fileId });
  if (type === 'result' && typeof o.homeworkId === 'string' && o.homeworkId) out.push({ type: 'homework', id: o.homeworkId });
  if (type === 'remark' && o.linkId) {
    const t = ({ homework: 'homework', devoir: 'homework', grade: 'result', note: 'result', result: 'result', event: 'event', file: 'file', remark: 'remark' } as Record<string, LinkType>)[String(o.linkType)];
    if (t) out.push({ type: t, id: String(o.linkId) });
  }
  return out;
}
const explicitEdges = (o: Obj): Link[] => (Array.isArray(o.links) ? o.links.filter(isRef) : []);
const edgesOf = (type: LinkType, o: Obj): Link[] => [...explicitEdges(o), ...legacyEdges(type, o)];

/** L'objet référencé existe-t-il ? (`file`/`note` : non vérifiable ici → null = inconnu) */
export function existsInStore(ref: Ref): boolean | null {
  const key = COLL[ref.type];
  if (!key) return null;
  return list(key).some(o => idOf(ref.type, o) === ref.id);
}

/** Applique `fn` à tous les objets du store ; n'écrit que les collections réellement modifiées. Retourne les anciennes versions (pour annuler). */
function rewrite(fn: (type: LinkType, o: Obj) => Obj | null): { changed: number; undo: () => void } {
  const undoOps: (() => void)[] = []; let changed = 0;
  for (const { type, key } of COLL_TYPE) {
    const before = list(key); let touched = false;
    const after = before.map(o => { const n = fn(type, o); if (n && n !== o) { touched = true; changed++; return n; } return o; });
    if (touched) {
      setData(key, after as unknown as Data[typeof key]);
      const olds = new Map(before.map(o => [idOf(type, o), o]));
      undoOps.push(() => setData(key, list(key).map(o => olds.get(idOf(type, o)) ?? o) as unknown as Data[typeof key]));
    }
  }
  return { changed, undo: () => undoOps.forEach(f => f()) };
}

/** Ajoute (idempotent) le lien `to` sur l'objet `from`. `page` seulement pour un lien vers un fichier. */
function withLink(o: Obj, to: Link): Obj | null {
  const cur = explicitEdges(o);
  const i = cur.findIndex(l => same(l, to));
  if (i >= 0) {
    if (to.page == null || cur[i].page === to.page) return null;
    const links = (o.links as unknown[]).map(l => (isRef(l) && same(l, to) ? { ...l, page: to.page } : l));
    return { ...o, links };
  }
  return { ...o, links: [...(Array.isArray(o.links) ? o.links : []), to] };
}

/** Relie a et b (bidirectionnel, idempotent). Retourne false si rien n'a changé ou si un des objets du store n'existe pas. */
export function linkObjects(a: Ref, b: Ref, opts: { page?: number } = {}): boolean {
  if (same(a, b) || existsInStore(a) === false || existsInStore(b) === false) return false;
  const page = opts.page != null && (a.type === 'file' || b.type === 'file') && Number.isFinite(opts.page) ? opts.page : undefined;
  const mk = (t: Ref): Link => (page != null && t.type === 'file' ? { type: t.type, id: t.id, page } : { type: t.type, id: t.id });
  const res = rewrite((type, o) => {
    const id = idOf(type, o);
    if (type === a.type && id === a.id) return withLink(o, mk(b));
    if (type === b.type && id === b.id) return withLink(o, mk(a));
    return null;
  });
  return res.changed > 0;
}

const dropLink = (o: Obj, target: Ref): Obj | null => {
  if (!Array.isArray(o.links)) return null;
  const links = o.links.filter((l: unknown) => !(isRef(l) && same(l, target)));
  return links.length === o.links.length ? null : { ...o, links };
};
/** Neutralise les anciens champs qui pointent vers `target` (sans toucher aux autres données de l'objet). */
function clearLegacy(type: LinkType, o: Obj, target: Ref): Obj | null {
  let n: Obj | null = null; const set = (k: string, v: unknown) => { n = { ...(n || o), [k]: v }; };
  if (target.type === 'file' && o.fileId === target.id) set('fileId', null);
  if (type === 'result' && target.type === 'homework' && o.homeworkId === target.id) set('homeworkId', null);
  if (type === 'remark' && o.linkId != null && legacyEdges(type, { linkType: o.linkType, linkId: o.linkId }).some(l => same(l, target))) { set('linkType', null); set('linkId', null); }
  return n;
}
const chain = (...steps: ((o: Obj) => Obj | null)[]) => (o: Obj): Obj | null => { let cur = o, ch = false; for (const s of steps) { const n = s(cur); if (n) { cur = n; ch = true; } } return ch ? cur : null; };

/** Retire le lien entre a et b des deux côtés (y compris les anciens champs). */
export function unlinkObjects(a: Ref, b: Ref): boolean {
  return rewrite((type, o) => {
    const id = idOf(type, o);
    const other = type === a.type && id === a.id ? b : type === b.type && id === b.id ? a : null;
    return other ? chain(x => dropLink(x, other), x => clearLegacy(type, x, other))(o) : null;
  }).changed > 0;
}

/** Tout ce qui est relié à `ref`, groupé par type (liens explicites + anciens champs + index inverse). Dédoublonné. */
export function getRelated(ref: Ref): Partial<Record<LinkType, Link[]>> {
  const seen = new Map<string, Link>();
  const add = (l: Link) => { const k = l.type + '|' + l.id; const p = seen.get(k); if (!p) seen.set(k, l); else if (p.page == null && l.page != null) seen.set(k, { ...p, page: l.page }); };
  const key = COLL[ref.type];
  if (key) { const me = list(key).find(o => idOf(ref.type, o) === ref.id); if (me) edgesOf(ref.type, me).forEach(add); }
  for (const { type, key: k } of COLL_TYPE) for (const o of list(k)) {
    const id = idOf(type, o);
    if (type === ref.type && id === ref.id) continue;
    const back = edgesOf(type, o).find(l => same(l, ref));
    if (back) add(back.page != null && type !== 'file' && ref.type === 'file' ? { type, id, page: back.page } : { type, id });
  }
  const out: Partial<Record<LinkType, Link[]>> = {};
  seen.forEach(l => { (out[l.type] ||= []).push(l); });
  return out;
}

const NOUN: Record<LinkType, [string, string]> = { file: ['fichier', 'fichiers'], homework: ['devoir', 'devoirs'], remark: ['remarque', 'remarques'], session: ['séance de révision', 'séances de révision'], result: ['note', 'notes'], event: ['événement', 'événements'], note: ['note', 'notes'] };
/** « 2 devoirs et 3 remarques » ('' s'il n'y a rien). */
export function describeRelated(ref: Ref): string {
  const rel = getRelated(ref); // ordre fixe (et non l'ordre de découverte) pour une phrase stable
  const parts = (['file', 'homework', 'result', 'event', 'remark', 'session', 'note'] as LinkType[]).filter(t => rel[t]?.length).map(t => `${rel[t]!.length} ${NOUN[t][rel[t]!.length > 1 ? 1 : 0]}`);
  return parts.length <= 1 ? parts.join('') : parts.slice(0, -1).join(', ') + ' et ' + parts[parts.length - 1];
}

/** Nombre total d'objets reliés à `ref`. */
export const relatedCount = (ref: Ref): number => Object.values(getRelated(ref)).reduce((n, l) => n + (l?.length ?? 0), 0);

/** Supprime toute référence à `ref` (liens + anciens champs). À appeler quand l'objet est supprimé. `undo()` remet les objets touchés dans leur état d'avant. */
export function removeAllReferencesTo(ref: Ref): { count: number; undo: () => void } {
  const r = rewrite((type, o) => (type === ref.type && idOf(type, o) === ref.id ? null : chain(x => dropLink(x, ref), x => clearLegacy(type, x, ref))(o)));
  return { count: r.changed, undo: r.undo };
}

/** Réaffecte toutes les références de `oldRef` vers `newRef` (même type) — ex. fichier remplacé : l'id d'origine survit. */
export function repointReferences(oldRef: Ref, newRef: Ref): number {
  if (oldRef.type !== newRef.type || same(oldRef, newRef)) return 0;
  return rewrite((type, o) => {
    let n: Obj | null = null; const cur = () => n || o;
    if (Array.isArray(o.links) && o.links.some((l: unknown) => isRef(l) && same(l, oldRef))) {
      const links: unknown[] = []; const has = (l: Ref) => links.some(x => isRef(x) && same(x, l));
      for (const l of o.links as unknown[]) {
        if (isRef(l) && same(l, oldRef)) { if (!has(newRef)) links.push({ ...l, id: newRef.id }); } else if (!(isRef(l) && same(l, newRef) && has(l))) links.push(l);
      }
      n = { ...cur(), links };
    }
    if (oldRef.type === 'file' && o.fileId === oldRef.id) n = { ...cur(), fileId: newRef.id };
    if (oldRef.type === 'homework' && type === 'result' && o.homeworkId === oldRef.id) n = { ...cur(), homeworkId: newRef.id };
    if (type === 'remark' && o.linkId === oldRef.id && legacyEdges(type, o).some(l => same(l, oldRef))) n = { ...cur(), linkId: newRef.id };
    return n;
  }).changed;
}

export interface IntegrityReport { removed: number; added: number; log: string[] }
/** Répare les orphelins : liens vers un objet disparu (ou un fichier absent, si `fileIds` est fourni), anciens champs pendants, doublons, réciprocité manquante. Idempotent. */
export function checkIntegrity(fileIds?: Set<string> | null): IntegrityReport {
  const rep: IntegrityReport = { removed: 0, added: 0, log: [] };
  const gone = (l: Ref): boolean => (l.type === 'file' ? (fileIds ? !fileIds.has(l.id) : false) : existsInStore(l) === false);
  // 1) orphelins + doublons
  rewrite((type, o) => {
    let n: Obj | null = null; const id = idOf(type, o);
    if (Array.isArray(o.links)) {
      const keep: unknown[] = []; let ch = false;
      for (const l of o.links as unknown[]) {
        if (!isRef(l)) { keep.push(l); continue; } // entrée inconnue : jamais supprimée
        if (gone(l)) { rep.removed++; ch = true; rep.log.push(`${type}:${id} → ${l.type}:${l.id} introuvable, lien retiré`); continue; }
        if (keep.some(x => isRef(x) && same(x, l))) { ch = true; continue; }
        keep.push(l);
      }
      if (ch) n = { ...o, links: keep };
    }
    for (const l of legacyEdges(type, o)) if (gone(l)) {
      const c = clearLegacy(type, n || o, l); if (c) { n = c; rep.removed++; rep.log.push(`${type}:${id} → ${l.type}:${l.id} introuvable, ancien champ vidé`); }
    }
    return n;
  });
  // 2) réciprocité : a→b explicite entre deux objets du store ⇒ b→a
  const missing: [Ref, Ref][] = [];
  for (const { type, key } of COLL_TYPE) for (const o of list(key)) for (const l of explicitEdges(o)) {
    const k2 = COLL[l.type]; if (!k2) continue;
    const t = list(k2).find(x => idOf(l.type, x) === l.id);
    if (t && !explicitEdges(t).some(b => b.type === type && b.id === idOf(type, o))) missing.push([{ type, id: idOf(type, o) }, { type: l.type, id: l.id }]);
  }
  for (const [a, b] of missing) if (linkObjects(a, b)) { rep.added++; rep.log.push(`${b.type}:${b.id} → ${a.type}:${a.id} ajouté (réciprocité)`); }
  if (rep.log.length) console.info('[MOAS] checkIntegrity :', rep.removed, 'retiré(s),', rep.added, 'ajouté(s)', rep.log);
  return rep;
}
