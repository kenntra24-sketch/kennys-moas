import { getData, LS } from './store';
import { todaysBlocks, minutes } from './timetable';
import { todayISO } from './util';

/** Rappel avant chaque cours de l'emploi du temps de classe (minutes ; 0 = désactivé). Clé hors sauvegarde de données : simple préférence. */
export const getTtRemind = (): number => LS.g<number>('me:ttRemind', 0);
export const setTtRemind = (m: number) => LS.s('me:ttRemind', m);

/* Rappels par notification (uniquement pendant que l'app est ouverte, comme l'original) :
   événements avec heure + rappel, devoirs avec échéance + rappel (comptés depuis 08:00 le jour J). */
export function checkReminders() {
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  const fired = new Set<string>(LS.g<string[]>('me:firedReminders', [])); const now = Date.now(); let changed = false;
  const fire = (key: string, title: string, body: string) => { if (fired.has(key)) return; fired.add(key); changed = true; try { new Notification(title, { body }); } catch { /* ignore */ } };
  for (const e of getData('events')) {
    if (!e.reminder || !e.time) continue;
    const at = new Date(`${e.date}T${e.time}`).getTime() - +e.reminder * 60000;
    if (now >= at && now < at + 6 * 3600000) fire('e' + e.id + e.date, e.title, `${e.subject ? e.subject + ' · ' : ''}à ${e.time}`);
  }
  for (const h of getData('homework')) {
    if (h.done || !h.reminder || !h.due) continue;
    const at = new Date(`${h.due}T08:00`).getTime() - +h.reminder * 60000;
    if (now >= at && h.due >= todayISO()) fire('h' + h.id + h.due, 'Devoir à rendre', `${h.title}${h.subject ? ' · ' + h.subject : ''}`);
  }
  const rm = getTtRemind(), tt = getData('timetable');
  if (rm > 0 && tt) {
    const d = new Date(), iso = todayISO(), nowMin = d.getHours() * 60 + d.getMinutes();
    for (const x of todaysBlocks(tt, d)) {
      const st = minutes(x.start); if (nowMin >= st - rm && nowMin < st) fire('t' + x.block.id + iso, x.block.kind === 'etude' ? 'Étude / Devoir' : x.block.subject, `à ${x.start}${x.block.room || tt.room ? ' · salle ' + (x.block.room || tt.room) : ''}`);
    }
  }
  if (changed) LS.s('me:firedReminders', [...fired].slice(-300));
}
