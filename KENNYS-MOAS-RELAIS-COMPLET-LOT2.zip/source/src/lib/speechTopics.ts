/* Banque de sujets pour l'entraînement à la prise de parole (Révisions).
   Tout est écrit à la main, sans générateur automatique (les phrases combinées au hasard n'avaient pas de sens).
   Forme des questions « à débattre » : inspirée des règles officielles du Grand oral (Éducation nationale) — la question finit par « ? »,
   évite la réponse par oui/non et commence par « En quoi… », « Comment… », « Dans quelle mesure… », « Pourquoi… ».
   Les sujets sont originaux (aucun texte copié d'une source). */

export type TopicCat = 'debat' | 'dilemme' | 'raconte' | 'pitch';
export const TOPIC_CATS: [TopicCat | 'tout', string][] = [
  ['tout', 'Tout'], ['debat', 'À débattre'], ['dilemme', 'Dilemmes'], ['raconte', 'Raconte-moi…'], ['pitch', 'Convaincre (1 min)'],
];
export interface Topic { text: string; cat: TopicCat | 'explique'; reveal?: string; key?: string }

const DEBAT = [
  'En quoi le téléphone portable aide-t-il ou freine-t-il les élèves dans leurs études ?',
  'Comment les réseaux sociaux changent-ils notre façon de communiquer avec nos amis ?',
  'Dans quelle mesure faut-il se méfier des informations que l’on lit sur internet ?',
  'Pourquoi est-il important de lire des livres à l’heure des écrans ?',
  'En quoi le sport est-il utile en dehors de la santé ?',
  'Comment l’école peut-elle préparer à des métiers qui n’existent pas encore ?',
  'Dans quelle mesure l’intelligence artificielle peut-elle aider un élève sans le faire tricher ?',
  'En quoi les langues locales font-elles partie de la richesse d’un pays ?',
  'Comment réduire les déchets plastiques dans une grande ville comme Abidjan ?',
  'Pourquoi les examens sont-ils source de stress, et comment le gérer ?',
  'En quoi le travail en groupe peut-il être plus efficace que le travail seul ?',
  'Comment lutter efficacement contre le harcèlement à l’école ?',
  'Dans quelle mesure la jeunesse peut-elle changer son pays ?',
  'Pourquoi faut-il apprendre l’histoire de son pays ?',
  'En quoi la musique influence-t-elle notre humeur et notre façon de travailler ?',
  'Comment mieux organiser son temps entre cours, loisirs et famille ?',
  'Dans quelle mesure l’argent est-il nécessaire au bonheur ?',
  'En quoi l’égalité entre filles et garçons profite-t-elle à toute la société ?',
  'Comment économiser l’eau et l’électricité à la maison ?',
  'Pourquoi les mathématiques sont-elles utiles même quand on ne devient pas scientifique ?',
  'En quoi le bénévolat enrichit-il celui qui le pratique ?',
  'Comment bien choisir son orientation après le bac ?',
  'Dans quelle mesure les jeux vidéo peuvent-ils être utiles ?',
  'Pourquoi l’amitié compte-t-elle autant à l’adolescence ?',
  'En quoi les séries et la télévision influencent-elles nos idées ?',
  'Comment développer l’esprit critique d’un jeune ?',
  'Dans quelle mesure la mondialisation menace-t-elle les cultures locales ?',
  'En quoi voyager forme-t-il la jeunesse ?',
  'Comment rendre les transports en commun plus agréables et plus sûrs ?',
  'Pourquoi respecter le code de la route sauve-t-il des vies ?',
  'En quoi les énergies renouvelables sont-elles une chance pour l’Afrique ?',
  'Comment apprendre de ses échecs ?',
  'Pourquoi est-il difficile de prendre la parole en public, et comment s’y entraîner ?',
  'En quoi la lecture développe-t-elle l’imagination et le vocabulaire ?',
  'Comment rester concentré quand le téléphone sonne en permanence ?',
];
const DILEMMES = [
  'Tu préfères vivre un an sans téléphone ou un an sans internet ? Choisis et justifie.',
  'Tu préfères un très bon salaire dans un métier que tu n’aimes pas, ou un salaire moyen dans un métier passion ? Justifie.',
  'Tu préfères voir un grand événement du passé ou ton pays dans 100 ans ? Justifie ton choix.',
  'Tu préfères travailler seul ou en équipe ? Défends ton choix.',
  'Tu préfères être très célèbre ou très respecté pour ton travail ? Justifie.',
  'Tu préfères vivre dans une grande ville animée ou dans un village calme ? Argumente.',
  'Tu préfères connaître ton avenir ou garder la surprise ? Justifie.',
  'Tu préfères un seul très bon ami ou beaucoup de bons camarades ? Argumente.',
  'Tu préfères que l’école commence plus tard ou qu’elle finisse plus tôt ? Défends ton choix.',
  'Tu préfères parler parfaitement trois langues ou jouer parfaitement d’un instrument ? Justifie.',
  'Tu préfères réussir par le travail ou par le talent naturel ? Argumente.',
  'Tu préfères dire toujours la vérité, même si elle blesse, ou parfois mentir pour protéger quelqu’un ? Justifie.',
  'Tu préfères être le meilleur de ta classe ou le plus apprécié ? Défends ton choix.',
  'Tu préfères apprendre par la pratique ou par les livres ? Argumente.',
  'Tu préfères inventer quelque chose d’utile à tous ou écrire un livre lu par des millions de gens ? Justifie.',
  'Tu préfères être très bon dans une seule matière ou correct partout ? Argumente.',
  'Tu préfères un monde sans voitures ou un monde sans avions ? Justifie.',
  'Tu préfères un jour de plus par semaine pour réviser ou pour te reposer ? Défends ton choix.',
];
const RACONTE = [
  'Raconte un souvenir d’enfance dont tu te souviens très précisément.',
  'Raconte une journée où tout ne s’est pas passé comme prévu.',
  'Raconte la personne qui t’a le plus appris et ce qu’elle t’a transmis.',
  'Raconte une fois où tu as eu peur de parler devant les autres.',
  'Décris ton quartier à quelqu’un qui n’y est jamais venu.',
  'Raconte ton plus beau voyage, ou celui dont tu rêves.',
  'Raconte ta plus grande fierté à l’école.',
  'Raconte un conte ou une légende que l’on t’a racontée.',
  'Décris ta journée idéale, de l’aube au coucher.',
  'Raconte une erreur dont tu as beaucoup appris.',
  'Explique comment on prépare un plat que tu aimes, comme si tu parlais à un ami.',
  'Raconte un moment où tu as aidé quelqu’un.',
  'Raconte ton premier jour dans une nouvelle classe.',
  'Raconte un match, un spectacle ou une fête dont tu te souviens.',
  'Raconte comment tu imagines ta vie dans dix ans.',
];
const PITCH = [
  'Convaincs-moi de lire un livre que tu as aimé.',
  'Convaincs-moi de visiter un lieu de ton pays.',
  'Présente l’application idéale pour réviser.',
  'Convaincs-moi d’adopter une bonne habitude : dormir tôt, marcher, lire…',
  'Présente ta matière préférée à quelqu’un qui la déteste.',
  'Convaincs-moi de voter pour toi comme délégué de classe.',
  'Vends-moi un objet de ton sac comme si c’était un produit génial.',
  'Convaincs-moi de faire du bénévolat.',
  'Présente un métier que tu admires.',
  'Convaincs-moi d’essayer ton sport ou ton loisir préféré.',
  'Présente un projet que tu voudrais lancer dans ton quartier.',
  'Convaincs-moi de goûter un plat de chez toi.',
  'Présente-toi en une minute, de façon originale.',
  'Convaincs-moi de planter un arbre.',
  'Recommande un film ou une série sans en révéler la fin.',
];
/* Deux camps : une affirmation, une minute POUR puis une minute CONTRE. */
export const AFFIRMATIONS = [
  'Les devoirs à la maison devraient être supprimés.', 'Le téléphone portable devrait être interdit en classe.',
  'Les réseaux sociaux font plus de bien que de mal aux jeunes.', 'L’uniforme à l’école est une bonne idée.',
  'Le sport devrait être obligatoire tous les jours à l’école.', 'L’intelligence artificielle remplacera bientôt les enseignants.',
  'Il vaut mieux faire ses études à l’étranger que dans son pays.', 'Les jeux vidéo devraient être reconnus comme un vrai sport.',
  'On devrait pouvoir voter dès 16 ans.', 'Les notes devraient être remplacées par des appréciations.',
  'Les animaux ne devraient pas être gardés dans les zoos.', 'Le télétravail est meilleur que le travail au bureau.',
  'Les sacs en plastique devraient être interdits partout.', 'On apprend mieux seul qu’en groupe.',
  'Les cours devraient commencer plus tard le matin.', 'Il faut limiter le temps passé sur les écrans chaque jour.',
];
/* Explique-moi : notions de cours courantes, à expliquer simplement. */
export const NOTIONS = [
  'la photosynthèse', 'le cycle de l’eau', 'la fonction exponentielle', 'la notion de limite en mathématiques', 'la dérivée d’une fonction',
  'les probabilités', 'la démocratie', 'la loi de l’offre et de la demande', 'l’inflation', 'la gravité', 'le courant électrique',
  'la mondialisation', 'le réchauffement climatique', 'la révolution industrielle', 'la décolonisation', 'la séparation des pouvoirs',
  'la métaphore', 'la structure d’une dissertation', 'la cellule', 'l’ADN', 'le rôle d’un vaccin', 'l’atome', 'une réaction chimique',
  'une suite géométrique', 'un pourcentage', 'le développement durable', 'la liberté en philosophie', 'le rôle d’un budget',
];

const HAND: Topic[] = [
  ...DEBAT.map(text => ({ text, cat: 'debat' as const })), ...DILEMMES.map(text => ({ text, cat: 'dilemme' as const })),
  ...RACONTE.map(text => ({ text, cat: 'raconte' as const })), ...PITCH.map(text => ({ text, cat: 'pitch' as const })),
];
export const HAND_TOPICS = HAND;
export const TOTAL_TOPICS = HAND.length + AFFIRMATIONS.length + NOTIONS.length;

/** Tire un élément d'une liste en évitant ceux déjà vus récemment. */
export function pickFromList(list: string[], seen: string[], rnd: () => number = Math.random): string {
  const pool = list.filter(x => !seen.includes(x)); const src = pool.length ? pool : list;
  return src[Math.floor(rnd() * src.length)];
}
/** Tire un sujet (catégorie facultative) en évitant les sujets récents. */
export function pickTopic(cat: TopicCat | 'tout', seen: string[], rnd: () => number = Math.random): Topic {
  const all = HAND.filter(t => cat === 'tout' || t.cat === cat); const pool = all.filter(t => !seen.includes(t.text));
  const src = pool.length ? pool : all; return src[Math.floor(rnd() * src.length)];
}

/* Mots à placer dans le discours (mode défi). */
export const WORDS = ['horizon', 'courage', 'patience', 'lumière', 'carrefour', 'marathon', 'secret', 'boussole', 'étincelle', 'pont', 'racine', 'orage',
  'tambour', 'balance', 'équipe', 'défi', 'mémoire', 'miroir', 'curiosité', 'silence', 'clé', 'sablier', 'feu', 'montagne', 'rivière', 'tempête',
  'trésor', 'voyage', 'énigme', 'lanterne', 'graine', 'écho', 'vitesse', 'équilibre', 'frontière', 'souffle', 'aventure', 'partage', 'sagesse', 'rêve'];
export const pickWords = (n = 3, rnd: () => number = Math.random): string[] => {
  const w = WORDS.slice(); const out: string[] = [];
  while (out.length < n && w.length) out.push(w.splice(Math.floor(rnd() * w.length), 1)[0]);
  return out;
};
export const CONSTRAINTS = [
  'Commence par une question surprenante.', 'Ne dis pas « euh » une seule fois.', 'Place une anecdote personnelle.',
  'Parle comme un présentateur de journal télévisé.', 'Utilise au moins une comparaison (« c’est comme… »).', 'Termine par une phrase qui reste en tête.',
  'Parle comme si tu t’adressais à 500 personnes dans une grande salle.', 'Fais trois points clairs : « premièrement, deuxièmement, troisièmement ».',
  'Donne un chiffre ou un fait précis.', 'Fais sourire ton public au moins une fois.', 'Interdiction de dire « en fait » et « du coup ».',
  'Raconte-le comme une histoire avec un début, un problème, une fin.', 'Parle lentement et fais de vraies pauses de deux secondes.',
  'Regarde un point lointain, pas ton écran.', 'Termine en proposant une action concrète à faire dès demain.',
];
export const TIPS = [
  'Parle plus fort que d’habitude : ta voix doit atteindre le fond de la salle.', 'Articule : ouvre bien la bouche sur chaque syllabe.',
  'Ralentis. Un discours trop rapide est difficile à suivre.', 'Respire entre les phrases : une pause vaut mieux qu’un « euh ».',
  'Structure : une accroche, deux ou trois idées, une conclusion.', 'Une idée = un exemple. L’exemple rend l’idée concrète.',
  'Regarde ton public (ici : un point devant toi), pas tes pieds.', 'Garde les épaules basses et le dos droit : la voix sort mieux.',
  'Si tu perds le fil, répète ta dernière phrase calmement : personne ne le remarquera.', 'Termine par une réponse claire à la question posée.',
];
/* Plan PREP : une trame simple quand on n’a pas le temps de préparer. */
export const PREP = [['P', 'Point', 'Ton idée principale en une phrase'], ['R', 'Raison', 'Pourquoi tu penses cela'], ['E', 'Exemple', 'Un fait, une histoire, un chiffre'], ['P', 'Point', 'Tu répètes ton idée, en conclusion']] as const;
