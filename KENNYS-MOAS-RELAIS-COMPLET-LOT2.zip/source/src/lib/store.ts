import { useSyncExternalStore } from 'react';
import type { AppSettings, Data, DataKey, Subj } from './model';
import { CLASSES } from './model';

/* ── localStorage (même API que l'original : LS.g / LS.s) ── */
export const LS = {
  g<T>(k: string, d: T): T {
    try { const v = JSON.parse(localStorage.getItem(k) as string); return v == null ? d : (v as T); } catch { return d; }
  },
  s(k: string, v: unknown): boolean {
    try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { console.error('Échec écriture localStorage', k, e); import('./toast').then(m => m.toast('Stockage plein — libère de la place ou exporte tes données (Réglages → Sauvegarde)', 'err')); return false; }
  },
};

/* ── abonnement (re-render à chaque écriture, y compris depuis un autre onglet) ── */
let version = 0;
const listeners = new Set<() => void>();
const emit = () => { version++; listeners.forEach(l => l()); };
const subscribe = (l: () => void) => { listeners.add(l); return () => { listeners.delete(l); }; };
/** À appeler en haut de chaque composant qui lit des données : il se re-rend à chaque modification. */
export const useStore = () => useSyncExternalStore(subscribe, () => version);
if (typeof window !== 'undefined') window.addEventListener('storage', e => { if (!e.key || e.key.startsWith('me:')) emit(); });
export const notifyStore = emit;

/* ── classe courante ── */
export const getClass = (): string => LS.g('me:class', 'Première A');
export const setClass = (c: string) => { LS.s('me:class', c); emit(); };
export const getCustomClasses = (): string[] => LS.g('me:customClasses', []);
export const setCustomClasses = (a: string[]) => { LS.s('me:customClasses', a); emit(); };
export const allClassNames = (): string[] => [...Object.values(CLASSES).flat(), ...getCustomClasses()];
const K = (s: string) => `me:${getClass()}:${s}`;

/* ── matières par défaut (portage exact de defaultSubjectsForClass) ── */
const DEF_SUBJ: Subj[] = ([['Français', 3], ['Anglais', 2], ['Allemand', 2], ['Histoire', 2], ['Géographie', 2], ['Mathématiques', 4], ['Physique-Chimie', 3], ['SVT', 2], ['Philosophie', 2], ['EPS', 1], ['Conduite comportementale', 1]] as [string, number][]).map(([name, coef]) => ({ name, coef }));
export function defaultSubjectsForClass(cl: string): Subj[] {
  const serie = (cl.match(/([ACD])\d?$/) || ['', ''])[1];
  const lycee = /Seconde|Première|Terminale/.test(cl);
  const defs = DEF_SUBJ.filter(s => s.name !== 'Philosophie' || /Première|Terminale/.test(cl));
  const coefC: Record<string, number> = { Mathématiques: 5, Français: 3, 'Physique-Chimie': 4, EPS: 1, 'Conduite comportementale': 1, Allemand: 1 };
  const coefD: Record<string, number> = { Mathématiques: 4, SVT: 4, 'Physique-Chimie': 4, Français: 3, EPS: 1, 'Conduite comportementale': 1, Allemand: 1 };
  const coefA: Record<string, number> = { Français: 5, Philosophie: 4, Anglais: 3, Allemand: 3, EPS: 1, 'Conduite comportementale': 1 };
  const coefSeconde: Record<string, number> = { Mathématiques: 4, 'Physique-Chimie': 3, SVT: 3, Français: 3, Anglais: 2, Histoire: 2, Géographie: 2, EPS: 1 };
  if (!lycee) return defs.map(s => ({ ...s, coef: s.name === 'Français' ? 3 : s.name === 'Mathématiques' ? 4 : s.coef }));
  const table = serie === 'C' ? coefC : serie === 'D' ? coefD : serie === 'A' ? coefA : coefSeconde;
  return defs.map(s => ({ ...s, coef: table[s.name] ?? s.coef }));
}
const DEFS: Omit<Data, 'subjects'> = { grades: [], homework: [], errors: [], events: [], sessions: [], schedule: {}, extraHours: [], hiddenHours: [], hiddenDays: ['Sam'], goal: null, timetable: null, timetables: [] };

export function getData<K extends DataKey>(key: K): Data[K] {
  const d = key === 'subjects' ? defaultSubjectsForClass(getClass()) : structuredClone((DEFS as Data)[key]);
  return LS.g(K(key), d as Data[K]);
}
export function setData<K extends DataKey>(key: K, value: Data[K]) { LS.s(K(key), value); emit(); }
export function update<K extends DataKey>(key: K, fn: (cur: Data[K]) => Data[K]) { setData(key, fn(getData(key))); }

/* ── réglages ── */
const DEF_SET: AppSettings = { mode: 'auto', primary: '#5f6f5b', secondary: '#b86a49', font: 'inter', headingFont: 'fraunces', density: 'comfortable', layout: 'normal', surface: 'paper', radius: 'soft' };
export const getSettings = (): AppSettings => ({ ...DEF_SET, ...LS.g<Partial<AppSettings>>('me:settings', {}) });
export const saveSettings = (s: AppSettings) => { LS.s('me:settings', s); emit(); };
