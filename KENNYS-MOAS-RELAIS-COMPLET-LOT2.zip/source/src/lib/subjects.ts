/* Regroupement d'une matière dans une autre : toutes les données rattachées par le NOM de la matière
   (notes, devoirs, remarques, événements, séances, emploi du temps, fichiers) passent sur la matière cible.
   Retourne une fonction « annuler » qui remet exactement l'état d'avant. Rien n'est supprimé sauf la matière d'origine. */
import { getData, setData } from './store';
import { dbAll, dbPut, type LibFile } from './db';

export async function mergeSubject(from: string, to: string): Promise<() => Promise<void>> {
  const before = {
    subjects: getData('subjects'), grades: getData('grades'), homework: getData('homework'), errors: getData('errors'),
    events: getData('events'), sessions: getData('sessions'), schedule: getData('schedule'),
  };
  const re = <T extends { subject?: string | null }>(a: T[]) => a.map(x => (x.subject === from ? { ...x, subject: to } : x));
  setData('grades', re(before.grades)); setData('homework', re(before.homework)); setData('errors', re(before.errors));
  setData('events', re(before.events)); setData('sessions', re(before.sessions));
  setData('schedule', Object.fromEntries(Object.entries(before.schedule).map(([k, c]) => [k, c && c.subject === from ? { ...c, subject: to } : c])));
  setData('subjects', before.subjects.filter(s => s.name !== from));
  let moved: LibFile[] = [];
  try { moved = (await dbAll<LibFile>('files')).filter(f => f.subject === from); for (const f of moved) await dbPut('files', { ...f, subject: to }); } catch { /* bibliothèque indisponible : données locales déjà regroupées */ }
  return async () => {
    (Object.keys(before) as (keyof typeof before)[]).forEach(k => setData(k as any, before[k] as any));
    try { for (const f of moved) await dbPut('files', f); } catch { /* ignoré */ }
  };
}
