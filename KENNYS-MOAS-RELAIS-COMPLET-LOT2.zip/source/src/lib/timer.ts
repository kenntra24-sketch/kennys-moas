import { useSyncExternalStore } from 'react';
import { LS, getData, setData } from './store';
import { toast } from './toast';
import { pad } from './util';

/* Chrono global persistant — même clés que l'original (`me:timer`, `me:pendingTag`) : il survit au rechargement. */
export interface TimerState { dur: number; rem: number; running: boolean; startAt: number; doneToast: boolean }
export interface PendingTag { subject: string; eventId?: string }
let T: TimerState = LS.g<TimerState>('me:timer', { dur: 1500, rem: 1500, running: false, startAt: 0, doneToast: false });
let tag: PendingTag | null = LS.g<PendingTag | null>('me:pendingTag', null);
let tick = 0;
const subs = new Set<() => void>();
const emit = () => { tick++; subs.forEach(s => s()); };
const save = () => { LS.s('me:timer', T); emit(); };

export const remaining = () => (T.running ? Math.max(0, T.rem - Math.floor((Date.now() - T.startAt) / 1000)) : T.rem);
export const mmss = (s: number) => `${pad(Math.floor(s / 60))}:${pad(s % 60)}`;
export const timerState = () => T;
export const pendingTag = () => tag;
export const isActive = () => T.running || T.rem !== T.dur;

export function useTimer() {
  useSyncExternalStore(l => { subs.add(l); return () => { subs.delete(l); }; }, () => tick);
  return { ...T, rem: remaining(), tag };
}
export function setDuration(s: number) { if (T.running) return toast('Arrête d’abord la session', 'warn'); T = { ...T, dur: s, rem: s }; save(); }
export function setTag(subject: string) { tag = subject ? { subject } : null; LS.s('me:pendingTag', tag); emit(); }
export function start(t?: PendingTag) {
  if (t) { tag = t; LS.s('me:pendingTag', tag); }
  if (T.running) return;
  if (remaining() <= 0) T.rem = T.dur;
  T = { ...T, startAt: Date.now(), running: true, doneToast: false }; save();
  toast(tag ? 'Session démarrée · ' + tag.subject : 'Session démarrée');
}
export function pause() {
  if (T.running) { T = { ...T, rem: remaining(), running: false }; save(); }
  else if (T.rem < T.dur && T.rem > 0) { T = { ...T, startAt: Date.now(), running: true }; save(); }
}
const logSession = (min: number, done: boolean) => {
  const links = tag && tag.eventId ? [{ type: 'event', id: tag.eventId }] : [];
  setData('sessions', [...getData('sessions'), { date: Date.now(), min, done, subject: tag ? tag.subject : null, links }]);
};
export function stop() {
  const done = T.dur - remaining();
  if (done > 60) { logSession(Math.round(done / 60), remaining() === 0); toast('Session enregistrée · ' + Math.round(done / 60) + ' min'); }
  T = { ...T, rem: T.dur, running: false, doneToast: false }; save();
}
/* tick 2×/s : fin de session automatique (même comportement que l'original) */
if (typeof window !== 'undefined') setInterval(() => {
  if (T.running && remaining() === 0 && !T.doneToast) {
    T = { ...T, doneToast: true, running: false, rem: 0 };
    logSession(Math.round(T.dur / 60), true);
    save(); toast('Session de révision terminée !');
    if ('Notification' in window && Notification.permission === 'granted') new Notification("KENNY'S MOAS", { body: 'Session de révision terminée !' });
  } else if (T.running) emit();
}, 250);
