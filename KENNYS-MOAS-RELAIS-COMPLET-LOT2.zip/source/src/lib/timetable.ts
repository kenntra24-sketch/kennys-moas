/* Emploi du temps « de classe » (pièce 5a) : créneaux libres (pas forcément des heures rondes) + blocs qui peuvent
   couvrir plusieurs créneaux. Clé de stockage `me:<classe>:timetable` (NOUVELLE clé : l'ancienne « Semaine type »
   `schedule` n'est jamais modifiée ni supprimée). Sauvegardé automatiquement avec les autres clés `me:*`. */
export type SlotKind = 'cours' | 'pause';
export interface Slot { id: string; label: string; start: string; end: string; kind: SlotKind }
export interface Block {
  id: string; day: string; slot: string; span: number; subject: string;
  kind?: 'cours' | 'etude'; room?: string; teacher?: string;
  /** lecture incertaine de la photo d'origine : à faire confirmer par l'utilisateur */
  uncertain?: boolean;
}
export interface ClassTimetable {
  id: string; name: string; school?: string; room?: string; days: string[];
  slots: Slot[]; blocks: Block[]; teachers: Record<string, string>;
}

export const minutes = (t: string) => { const m = /^(\d{1,2})[h:](\d{2})?$/.exec(t.trim()); return m ? +m[1] * 60 + (m[2] ? +m[2] : 0) : NaN; };
export const fmtTime = (t: string) => { const v = minutes(t); return isNaN(v) ? t : `${String(Math.floor(v / 60)).padStart(2, '0')}h${String(v % 60).padStart(2, '0')}`; };
export const slotRange = (s: Slot) => `${fmtTime(s.start)}–${fmtTime(s.end)}`;

/** Durée en minutes d'un bloc (somme des créneaux de cours couverts). */
export function blockMinutes(tt: ClassTimetable, b: Block): number {
  const i = tt.slots.findIndex(s => s.id === b.slot); if (i < 0) return 0;
  return tt.slots.slice(i, i + b.span).reduce((n, s) => n + (minutes(s.end) - minutes(s.start)), 0);
}
/** Volume horaire hebdomadaire par matière, en minutes (hors étude). */
export function weeklyMinutes(tt: ClassTimetable): Record<string, number> {
  const out: Record<string, number> = {};
  tt.blocks.filter(b => b.kind !== 'etude').forEach(b => { out[b.subject] = (out[b.subject] || 0) + blockMinutes(tt, b); });
  return out;
}
export const fmtDuration = (min: number) => { const h = Math.floor(min / 60), m = min % 60; return m ? `${h} h ${String(m).padStart(2, '0')}` : `${h} h`; };

/** Nombre maximal de créneaux qu'un bloc peut couvrir à partir de `slotId` : s'arrête à une pause, à la fin de la grille ou à un autre bloc. */
export function maxSpan(tt: ClassTimetable, day: string, slotId: string, ignoreBlock?: string): number {
  const i = tt.slots.findIndex(s => s.id === slotId); if (i < 0) return 1;
  let n = 0;
  for (let j = i; j < tt.slots.length; j++) {
    const s = tt.slots[j]; if (s.kind === 'pause') break;
    if (tt.blocks.some(b => b.id !== ignoreBlock && b.day === day && coveredSlots(tt, b).includes(s.id))) break;
    n++;
  }
  return Math.max(1, n);
}
export function coveredSlots(tt: ClassTimetable, b: Block): string[] {
  const i = tt.slots.findIndex(s => s.id === b.slot); if (i < 0) return [];
  const out: string[] = [];
  for (let j = i; j < tt.slots.length && out.length < b.span; j++) { if (tt.slots[j].kind === 'pause') break; out.push(tt.slots[j].id); }
  return out;
}
/** Bloc qui commence sur (jour, créneau) ou qui le recouvre. */
export function blockAt(tt: ClassTimetable, day: string, slotId: string): Block | undefined {
  return tt.blocks.find(b => b.day === day && coveredSlots(tt, b).includes(slotId));
}

/* ── Modèle de départ : TA1, Lycée Moderne Goffry Kouassi Raymond (Sassandra), transcrit depuis la photo du 30/09/2026.
   Les blocs marqués `uncertain` sont des lectures probables, à confirmer. ── */
const S = (id: string, label: string, start: string, end: string, kind: SlotKind = 'cours'): Slot => ({ id, label, start, end, kind });
const SLOTS_TA1: Slot[] = [
  S('M1', 'M1', '07h15', '08h10'), S('M2', 'M2', '08h10', '09h05'), S('M3', 'M3', '09h05', '10h00'),
  S('P1', 'Récréation', '10h00', '10h15', 'pause'),
  S('M4', 'M4', '10h15', '11h10'), S('M5', 'M5', '11h10', '12h05'), S('M6', 'M6', '12h05', '13h00'),
  S('P2', 'Pause déjeuner', '13h00', '14h00', 'pause'),
  S('S1', 'S1', '14h00', '15h00'), S('S2', 'S2', '15h00', '16h00'), S('S3', 'S3', '16h00', '17h00'), S('S4', 'S4', '17h00', '18h00'),
];
const HG = 'Histoire-Géographie', FR = 'Français', MA = 'Mathématiques', PH = 'Philosophie', EN = 'Anglais', ES = 'Espagnol', SV = 'SVT', EP = 'EPS', AP = 'AP / Musique';
/** [jour, créneau de début, durée en créneaux, matière, incertain?] */
const GRID_TA1: [string, string, number, string, boolean?][] = [
  ['Lun', 'M1', 1, HG], ['Lun', 'M2', 2, PH], ['Lun', 'M4', 2, MA], ['Lun', 'M6', 1, EN], ['Lun', 'S3', 2, EP, true],
  ['Mar', 'M1', 1, HG], ['Mar', 'M2', 2, PH], ['Mar', 'M4', 2, FR], ['Mar', 'M6', 1, EN], ['Mar', 'S1', 4, 'DEVOIR', true],
  ['Mer', 'M1', 2, MA], ['Mer', 'M3', 1, ES], ['Mer', 'M4', 1, SV], ['Mer', 'M5', 2, PH],
  ['Jeu', 'M1', 1, FR], ['Jeu', 'M2', 1, SV], ['Jeu', 'M3', 1, ES], ['Jeu', 'M4', 1, FR], ['Jeu', 'M5', 1, MA], ['Jeu', 'M6', 1, EN],
  ['Ven', 'M1', 2, PH, true], ['Ven', 'M3', 1, ES], ['Ven', 'M4', 2, HG], ['Ven', 'M6', 1, AP],
];
export const TEACHERS_TA1: Record<string, string> = {
  [EN]: 'COULIBALY Al.', [AP]: 'KASSE', [ES]: 'KOUAKOU R.', [FR]: 'BOLA BI', [HG]: 'GNABA', [MA]: 'SIDIBE', [EP]: 'DJIRO FAE A. Gabriel', [SV]: 'KONAN KONAN',
};
export function templateTA1(): ClassTimetable {
  return {
    id: 'ta1', name: 'Mon emploi du temps (TA1)', school: 'Lycée Moderne Goffry Kouassi Raymond — Sassandra', room: "D'2",
    days: ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven'], slots: SLOTS_TA1.map(s => ({ ...s })), teachers: { ...TEACHERS_TA1 },
    blocks: GRID_TA1.map(([day, slot, span, subject, unc], i) => ({
      id: `b${i + 1}`, day, slot, span, subject, kind: subject === 'DEVOIR' ? 'etude' as const : 'cours' as const,
      teacher: TEACHERS_TA1[subject], uncertain: unc || undefined,
    })),
  };
}
/** Modèle vide : mêmes créneaux que TA1, aucun cours (à remplir). */
export function templateEmpty(): ClassTimetable {
  return { id: 'vide', name: 'Mon emploi du temps', days: ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven'], slots: SLOTS_TA1.map(s => ({ ...s })), teachers: {}, blocks: [] };
}
/** Matières du modèle qui n'existent pas encore dans l'appli (à ajouter, jamais à remplacer). */
export function missingSubjects(tt: ClassTimetable, existing: string[]): string[] {
  const have = new Set(existing.map(s => s.toLowerCase()));
  return [...new Set(tt.blocks.filter(b => b.kind !== 'etude').map(b => b.subject))].filter(n => !have.has(n.toLowerCase()));
}

/* ══ Pièce 5b : horaires modifiables, plusieurs emplois du temps, cours du jour ══ */
export const DAY_LABELS = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
export const dayLabelOf = (d: Date) => DAY_LABELS[d.getDay()];
/** Heure « HH:MM » (champ <input type="time">) → « HHhMM » (format stocké) et inversement. */
export const toStored = (hhmm: string) => fmtTime(hhmm.replace(':', 'h'));
export const toInput = (t: string) => { const v = minutes(t); return isNaN(v) ? '' : `${String(Math.floor(v / 60)).padStart(2, '0')}:${String(v % 60).padStart(2, '0')}`; };

/** Vérifie la liste des créneaux : heures lisibles, début < fin, ordre croissant, pas de chevauchement. Renvoie un message ou null. */
export function validateSlots(slots: Slot[]): string | null {
  let prevEnd = -1, prevLabel = '';
  for (const s of slots) {
    const a = minutes(s.start), b = minutes(s.end);
    if (isNaN(a) || isNaN(b)) return `« ${s.label} » : l'heure n'est pas lisible.`;
    if (a >= b) return `« ${s.label} » : la fin doit être après le début.`;
    if (a < prevEnd) return `« ${s.label} » commence avant la fin de « ${prevLabel} ».`;
    prevEnd = b; prevLabel = s.label;
  }
  return null;
}
/** Un créneau peut être supprimé s'il n'est couvert par aucun bloc. */
export const slotInUse = (tt: ClassTimetable, slotId: string) => tt.blocks.some(b => coveredSlots(tt, b).includes(slotId));

/** Début et fin réels d'un bloc (premier et dernier créneau couverts). */
export function blockTimes(tt: ClassTimetable, b: Block): { start: string; end: string } | null {
  const ids = coveredSlots(tt, b); if (!ids.length) return null;
  const first = tt.slots.find(s => s.id === ids[0])!, last = tt.slots.find(s => s.id === ids[ids.length - 1])!;
  return { start: first.start, end: last.end };
}
/** Cours (et études) d'un jour donné, triés par heure de début. */
export function blocksOfDay(tt: ClassTimetable, day: string): { block: Block; start: string; end: string }[] {
  return tt.blocks.filter(b => b.day === day).map(block => ({ block, ...blockTimes(tt, block)! })).filter(x => x.start).sort((a, b) => minutes(a.start) - minutes(b.start));
}
export const todaysBlocks = (tt: ClassTimetable, d: Date) => blocksOfDay(tt, dayLabelOf(d));

/** Copie indépendante (nouvel id, nouveau nom) : aucun objet partagé avec l'original. */
export function duplicateTimetable(tt: ClassTimetable, id: string, name: string): ClassTimetable {
  const c = structuredClone(tt); c.id = id; c.name = name; return c;
}
/** Change l'emploi du temps actif : l'ancien actif est rangé dans `saved`. Renvoie le nouvel état ou null si `id` est inconnu. */
export function switchTimetable(active: ClassTimetable | null, saved: ClassTimetable[], id: string): { active: ClassTimetable; saved: ClassTimetable[] } | null {
  const target = saved.find(t => t.id === id); if (!target) return null;
  const rest = saved.filter(t => t.id !== id);
  return { active: target, saved: active ? [...rest, active] : rest };
}
/** Ajoute un emploi du temps et le rend actif ; l'ancien actif est conservé dans `saved` (rien n'est jamais écrasé). */
export function addTimetable(active: ClassTimetable | null, saved: ClassTimetable[], next: ClassTimetable): { active: ClassTimetable; saved: ClassTimetable[] } {
  return { active: next, saved: active ? [...saved, active] : saved };
}
/** Supprime l'emploi du temps actif ; le premier rangé (s'il existe) devient actif. */
export function removeActive(saved: ClassTimetable[]): { active: ClassTimetable | null; saved: ClassTimetable[] } {
  return { active: saved[0] ?? null, saved: saved.slice(1) };
}
