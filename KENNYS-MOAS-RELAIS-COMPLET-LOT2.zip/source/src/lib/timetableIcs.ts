import { d8, esc, fold, stamp } from './ics';
import { blockTimes, minutes, type ClassTimetable } from './timetable';
import { download, isoAddDays, isoOf, slug } from './util';

/* Export de l'emploi du temps de classe en .ics (pièce 5b) : UN événement récurrent par bloc (RRULE hebdomadaire),
   heures dans le fuseau Africa/Abidjan (GMT, pas d'heure d'été) avec son VTIMEZONE, rappel optionnel (VALARM).
   Les UID sont stables (`tt-<emploi>-<bloc>@kennys-moas`) : réimporter le même fichier met à jour les cours dans la plupart
   des agendas au lieu de les dupliquer (non garanti partout). */
export interface IcsOptions { from: string; until: string; alarmMin: number | null }

const BYDAY: Record<string, { code: string; dow: number }> = {
  Dim: { code: 'SU', dow: 0 }, Lun: { code: 'MO', dow: 1 }, Mar: { code: 'TU', dow: 2 }, Mer: { code: 'WE', dow: 3 },
  Jeu: { code: 'TH', dow: 4 }, Ven: { code: 'FR', dow: 5 }, Sam: { code: 'SA', dow: 6 },
};
const hhmmss = (t: string) => { const v = minutes(t); return `${String(Math.floor(v / 60)).padStart(2, '0')}${String(v % 60).padStart(2, '0')}00`; };
/** Première date ≥ `from` (AAAA-MM-JJ) qui tombe le jour `dow` (0 = dimanche). */
export function firstOnOrAfter(from: string, dow: number): string {
  const d = new Date(from + 'T00:00:00'); const add = (dow - d.getDay() + 7) % 7; return isoAddDays(isoOf(d), add);
}
export const TZ = 'Africa/Abidjan';
const VTIMEZONE = ['BEGIN:VTIMEZONE', `TZID:${TZ}`, 'BEGIN:STANDARD', 'DTSTART:19700101T000000', 'TZOFFSETFROM:+0000', 'TZOFFSETTO:+0000', 'TZNAME:GMT', 'END:STANDARD', 'END:VTIMEZONE'];

export function buildTimetableICS(tt: ClassTimetable, o: IcsOptions): string {
  const L = ['BEGIN:VCALENDAR', 'VERSION:2.0', "PRODID:-//KENNY'S MOAS//Emploi du temps//FR", 'CALSCALE:GREGORIAN', `X-WR-CALNAME:${esc(tt.name)}`, `X-WR-TIMEZONE:${TZ}`, ...VTIMEZONE];
  for (const b of tt.blocks) {
    const t = blockTimes(tt, b), day = BYDAY[b.day]; if (!t || !day) continue;
    const date = firstOnOrAfter(o.from, day.dow); if (date > o.until) continue; // aucun cours dans la période
    const etude = b.kind === 'etude';
    const where = b.room || tt.room, desc = [b.teacher && `Professeur : ${b.teacher}`, tt.school].filter(Boolean).join(' — ');
    L.push('BEGIN:VEVENT', `UID:tt-${tt.id}-${b.id}@kennys-moas`, `DTSTAMP:${stamp()}`,
      `DTSTART;TZID=${TZ}:${d8(date)}T${hhmmss(t.start)}`, `DTEND;TZID=${TZ}:${d8(date)}T${hhmmss(t.end)}`,
      `RRULE:FREQ=WEEKLY;BYDAY=${day.code};UNTIL=${d8(o.until)}T235959Z`,
      `SUMMARY:${esc(etude ? 'Étude / Devoir' : b.subject)}`);
    if (where) L.push(`LOCATION:${esc(where)}`);
    if (desc) L.push(`DESCRIPTION:${esc(desc)}`);
    if (o.alarmMin && o.alarmMin > 0) L.push('BEGIN:VALARM', 'ACTION:DISPLAY', `DESCRIPTION:${esc((etude ? 'Étude / Devoir' : b.subject) + ' — dans ' + o.alarmMin + ' min')}`, `TRIGGER:-PT${o.alarmMin}M`, 'END:VALARM');
    L.push('END:VEVENT');
  }
  L.push('END:VCALENDAR');
  return L.map(fold).join('\r\n') + '\r\n';
}
export const countIcsEvents = (ics: string) => (ics.match(/BEGIN:VEVENT/g) || []).length;
export const exportTimetableICS = (tt: ClassTimetable, o: IcsOptions) =>
  download(`emploi-du-temps-${slug(tt.name)}.ics`, new Blob([buildTimetableICS(tt, o)], { type: 'text/calendar;charset=utf-8' }));
/** Fin d'année scolaire par défaut : 30 juin à venir. */
export function defaultUntil(today: string): string { const y = +today.slice(0, 4), m = +today.slice(5, 7); return `${m >= 7 ? y + 1 : y}-06-30`; }
