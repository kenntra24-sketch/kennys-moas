export type ToastType = 'ok' | 'err' | 'warn';
export interface ToastMsg { id: number; msg: string; type: ToastType; action?: { label: string; cb: () => void } }
let n = 0;
const subs = new Set<(t: ToastMsg) => void>();
export const onToast = (fn: (t: ToastMsg) => void) => { subs.add(fn); return () => { subs.delete(fn); }; };
export function toast(msg: string, type: ToastType = 'ok', action?: ToastMsg['action']) {
  const t = { id: ++n, msg, type, action };
  subs.forEach(s => s(t));
}
