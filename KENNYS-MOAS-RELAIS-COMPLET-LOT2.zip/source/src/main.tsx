import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'
import { migrateAllClasses } from './lib/migrate'

/* Schéma 2 (pièce 1) : migration idempotente AVANT le premier rendu — l'app ne voit jamais l'ancienne forme. */
migrateAllClasses()

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)

/* PWA hors-ligne : uniquement en production (build) et jamais dans l'aperçu de développement. */
if ('serviceWorker' in navigator && location.protocol.startsWith('http') && import.meta.env.PROD) {
  const hadController = !!navigator.serviceWorker.controller
  navigator.serviceWorker.register('./sw.js').then(reg => {
    const check = () => { reg.update().catch(() => {}) }
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') check() })
    setInterval(check, 60 * 60 * 1000)                 // appli laissée ouverte : une vérification par heure
  }).catch(() => {})
  /* Un nouveau Service Worker a pris le contrôle = nouvelle version prête. On ne recharge JAMAIS d'office (risque de perdre un texte en cours
     de saisie) : un bandeau propose de recharger ; sinon la nouvelle version s'applique d'elle-même à la prochaine ouverture. */
  let shown = false
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (!hadController || shown) return
    shown = true
    const bar = document.createElement('div')
    bar.setAttribute('role', 'status')
    bar.style.cssText = 'position:fixed;left:50%;bottom:calc(16px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);z-index:99999;display:flex;gap:10px;align-items:center;padding:10px 14px;border-radius:999px;background:#2b2b2b;color:#fff;font:600 13.5px system-ui,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.3)'
    const txt = document.createElement('span'); txt.textContent = 'Nouvelle version prête.'
    const go = document.createElement('button'); go.textContent = 'Recharger'; go.style.cssText = 'padding:6px 12px;border-radius:999px;border:0;background:#fff;color:#222;font:inherit;cursor:pointer'
    go.onclick = () => location.reload()
    const x = document.createElement('button'); x.textContent = '×'; x.setAttribute('aria-label', 'Plus tard'); x.style.cssText = 'border:0;background:none;color:#fff;font-size:18px;cursor:pointer'
    x.onclick = () => bar.remove()
    bar.append(txt, go, x); document.body.appendChild(bar)
  })
}
