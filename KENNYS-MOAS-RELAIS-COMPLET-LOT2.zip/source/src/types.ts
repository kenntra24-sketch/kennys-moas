export type ViewId =
  | 'dashboard'
  | 'library'
  | 'homework'
  | 'schedule'
  | 'grades'
  | 'reviews'
  | 'errors'
  | 'goals'
  | 'settings'
  | 'faq';

export type DriveStatus = 'disconnected' | 'connected' | 'syncing' | 'offline' | 'error';
export type Theme = 'light' | 'dark' | 'auto';
export type FileView = 'grid' | 'list';

export interface SubjectFile {
  id: string;
  name: string;
  subject: string;
  type: 'pdf' | 'image' | 'doc' | 'other';
  size: number;
  addedAt: string;
  tags: string[];
}

export interface HomeworkItem {
  id: string;
  title: string;
  subject: string;
  dueDate: string;
  done: boolean;
  urgent: boolean;
}

export interface Subject {
  id: string;
  name: string;
  coef: number;
  color: string;
  icon: string;
  fileCount?: number;
  avg?: number | null;
}
