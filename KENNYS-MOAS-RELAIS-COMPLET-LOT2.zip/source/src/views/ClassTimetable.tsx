import { useState } from 'react';
import { IcoPlus, IcoTrash } from '../components/Icons';
import { SubjectIcon } from '../components/SubjectIcon';
import { AskText, Confirm, Field, Modal } from '../components/ui';
import { subjColor } from '../lib/calc';
import { getData, setData, useStore } from '../lib/store';
import { toast } from '../lib/toast';
import { todayISO, uid } from '../lib/util';
import { getTtRemind, setTtRemind } from '../lib/reminders';
import { buildTimetableICS, countIcsEvents, defaultUntil, exportTimetableICS } from '../lib/timetableIcs';
import {
  addTimetable, blockAt, coveredSlots, duplicateTimetable, fmtDuration, maxSpan, minutes, missingSubjects, removeActive, slotInUse, slotRange,
  switchTimetable, templateEmpty, templateTA1, toInput, toStored, validateSlots, weeklyMinutes,
  type Block, type ClassTimetable, type Slot,
} from '../lib/timetable';

const ETUDE = '__etude__';

/** Ajoute un emploi du temps et le rend actif. L'ancien actif est rangé (jamais écrasé) : on écrit d'abord la liste rangée, puis l'actif. */
function install(tt: ClassTimetable) {
  const subs = getData('subjects');
  const add = missingSubjects(tt, subs.map(s => s.name));
  if (add.length) setData('subjects', [...subs, ...add.map(name => ({ name, coef: 1 }))]);
  const st = addTimetable(getData('timetable'), getData('timetables'), { ...tt, id: uid() });
  setData('timetables', st.saved); setData('timetable', st.active);
  toast(add.length ? `Emploi du temps créé — matières ajoutées : ${add.join(', ')}` : 'Emploi du temps créé');
}

function StartCard({ onDone }: { onDone?: () => void }) {
  const go = (tt: ClassTimetable) => { install(tt); onDone?.(); };
  return (
    <div className={onDone ? undefined : 'card'}>
      {!onDone && <h3 style={{ marginTop: 0 }}>Mon emploi du temps</h3>}
      <p className="muted" style={{ marginTop: 0 }}>Choisis un point de départ. Tu pourras tout modifier ensuite : cases, salles, professeurs, durée des cours, horaires. Ton ancienne « Semaine type » n'est pas touchée{onDone ? ', ni ton emploi du temps actuel (il reste dans la liste)' : ''}.</p>
      <div className="row" style={{ gap: 10, flexWrap: 'wrap' }}>
        <button className="btn" onClick={() => go(templateTA1())}>Modèle TA1 — Lycée Goffry Kouassi Raymond</button>
        <button className="btn ghost" onClick={() => go(templateEmpty())}>Grille vide avec les mêmes horaires</button>
      </div>
      <p className="muted" style={{ fontSize: 12, marginBottom: 0 }}>Le modèle TA1 reprend ta feuille (07h15–13h00, récréation, pause déjeuner, 14h00–18h00). Quelques cases sont marquées « ? » : à confirmer.</p>
    </div>
  );
}

export function ClassTimetableView() {
  useStore();
  const tt = getData('timetable');
  const subjects = getData('subjects');
  const [edit, setEdit] = useState<{ day: string; slot: string } | null>(null);
  const [clear, setClear] = useState(false);
  const [dlg, setDlg] = useState<null | 'slots' | 'export' | 'remind' | 'manage' | 'new' | 'rename'>(null);
  const saved = getData('timetables');
  if (!tt) return <StartCard />;

  const save = (next: ClassTimetable) => setData('timetable', next);
  const vol = weeklyMinutes(tt);
  const uncertain = tt.blocks.filter(b => b.uncertain);
  const cur = edit ? blockAt(tt, edit.day, edit.slot) : undefined;
  /** Change d'emploi du temps sans jamais perdre l'actif : la liste rangée contient d'abord les deux, puis on retire l'élu. */
  const switchTo = (id: string) => {
    const r = switchTimetable(tt, saved, id); if (!r) return;
    setData('timetables', [...saved, tt]); setData('timetable', r.active); setData('timetables', r.saved);
  };
  const removeCurrent = () => {
    const before = { tt, saved }; const r = removeActive(saved);
    setData('timetable', r.active); setData('timetables', r.saved);
    toast('Emploi du temps supprimé', 'ok', { label: 'Annuler', cb: () => { setData('timetables', before.saved); setData('timetable', before.tt); } });
  };

  return (
    <div className="card" style={{ overflowX: 'auto' }}>
      <div className="row spread" style={{ marginBottom: 10, flexWrap: 'wrap', gap: 8 }}>
        <div>
          <h3 style={{ margin: 0 }}>{tt.name}</h3>
          {(tt.school || tt.room) && <div className="muted" style={{ fontSize: 12 }}>{[tt.school, tt.room && `Salle ${tt.room}`].filter(Boolean).join(' · ')}</div>}
        </div>
        <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
          {saved.length > 0 && <select className="input" style={{ width: 'auto', minHeight: 44 }} aria-label="Emploi du temps actif" value={tt.id} onChange={e => switchTo(e.target.value)}>
            <option value={tt.id}>{tt.name}</option>{saved.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}</select>}
          <button className="btn ghost sm" onClick={() => setDlg('slots')}>Horaires</button>
          <button className="btn ghost sm" onClick={() => setDlg('export')}>Exporter (.ics)</button>
          <button className="btn ghost sm" onClick={() => setDlg('remind')}>Rappels</button>
          <button className="btn ghost sm" onClick={() => setDlg('manage')}>Gérer</button>
        </div>
      </div>

      {uncertain.length > 0 && <div className="ctt-warn" role="note">
        <b>{uncertain.length} case{uncertain.length > 1 ? 's' : ''} à confirmer</b> (marquée{uncertain.length > 1 ? 's' : ''} « ? ») : ma lecture de la photo n'était pas sûre. Touche la case pour corriger ou confirmer.
      </div>}

      <table className="ctt">
        <thead><tr><th scope="col"><span className="sr-only">Horaires</span></th>{tt.days.map(d => <th key={d} scope="col">{d}</th>)}</tr></thead>
        <tbody>
          {tt.slots.map(s => {
            if (s.kind === 'pause') return (
              <tr key={s.id} className="ctt-pause"><th scope="row"><span className="ctt-time">{slotRange(s)}</span></th><td colSpan={tt.days.length}>{s.label}</td></tr>);
            return (
              <tr key={s.id}>
                <th scope="row"><b>{s.label}</b><span className="ctt-time">{slotRange(s)}</span></th>
                {tt.days.map(d => {
                  const b = blockAt(tt, d, s.id);
                  if (b && b.slot !== s.id && coveredSlots(tt, b)[0] !== s.id) return null; // case fusionnée : déjà dessinée plus haut
                  if (!b) return <td key={d} className="ctt-empty"><button className="ctt-add" aria-label={`Ajouter un cours ${d} ${s.label}`} onClick={() => setEdit({ day: d, slot: s.id })}><IcoPlus size={13} /></button></td>;
                  const etude = b.kind === 'etude'; const color = etude ? 'var(--mut)' : subjColor(b.subject);
                  return (
                    <td key={d} rowSpan={coveredSlots(tt, b).length} className={'ctt-cell' + (etude ? ' etude' : '')}
                      style={{ background: `color-mix(in srgb, ${color} 14%, var(--card))`, borderLeft: `3px solid ${color}`, color: etude ? 'var(--txt)' : color }}>
                      <button className="ctt-btn" onClick={() => setEdit({ day: d, slot: s.id })} aria-label={`${etude ? 'Étude' : b.subject}, ${d} ${s.label}${b.uncertain ? ', à confirmer' : ''}`}>
                        <span className="row" style={{ gap: 5, flexWrap: 'nowrap' }}>{!etude && <SubjectIcon name={b.subject} icon={subjects.find(x => x.name === b.subject)?.icon} size={14} />}<b>{etude ? 'Étude / Devoir' : b.subject}</b>{b.uncertain && <span className="ctt-q" title="À confirmer">?</span>}</span>
                        {(b.teacher || b.room) && <span className="ctt-sub">{[b.room, b.teacher].filter(Boolean).join(' · ')}</span>}
                      </button>
                    </td>);
                })}
              </tr>);
          })}
        </tbody>
      </table>

      {Object.keys(vol).length > 0 && <div className="ctt-vol">
        <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>Volume horaire par semaine (calculé d'après la grille)</div>
        <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
          {Object.entries(vol).sort((a, b) => b[1] - a[1]).map(([n, m]) => (
            <span key={n} className="chip" style={{ display: 'inline-flex', gap: 6, alignItems: 'center' }}>
              <SubjectIcon name={n} icon={subjects.find(x => x.name === n)?.icon} size={13} />{n} · {fmtDuration(m)}{tt.teachers[n] ? ` · ${tt.teachers[n]}` : ''}
            </span>))}
        </div>
      </div>}

      {edit && <BlockModal tt={tt} day={edit.day} slot={edit.slot} cur={cur} subjects={subjects.map(s => s.name)} onClose={() => setEdit(null)} onSave={save} />}
      {clear && <Confirm danger okLabel="Supprimer" message={`Supprimer « ${tt.name} » ? Ton ancienne « Semaine type » et tes matières ne sont pas touchées.${saved.length ? ' Un autre emploi du temps de ta liste deviendra l\'actif.' : ''}`} onClose={() => setClear(false)} onOk={removeCurrent} />}
      {dlg === 'slots' && <SlotsModal tt={tt} onClose={() => setDlg(null)} onSave={save} />}
      {dlg === 'export' && <ExportModal tt={tt} onClose={() => setDlg(null)} />}
      {dlg === 'remind' && <RemindModal onClose={() => setDlg(null)} />}
      {dlg === 'new' && <Modal title="Nouvel emploi du temps" onClose={() => setDlg(null)}><StartCard onDone={() => setDlg(null)} /></Modal>}
      {dlg === 'rename' && <AskText title="Renommer l'emploi du temps" label="Nom" initial={tt.name} onClose={() => setDlg(null)} onOk={v => { const n = v.trim(); if (n) { save({ ...tt, name: n }); toast('Emploi du temps renommé'); } setDlg(null); }} />}
      {dlg === 'manage' && <Modal title="Gérer mes emplois du temps" onClose={() => setDlg(null)}>
        <p className="muted" style={{ marginTop: 0 }}>Tu as {saved.length + 1} emploi{saved.length ? 's' : ''} du temps. Celui qui est affiché est l'actif ; change-le avec la liste en haut de l'écran.</p>
        <div className="row" style={{ gap: 8, flexWrap: 'wrap' }}>
          <button className="btn" onClick={() => setDlg('new')}><IcoPlus size={13} /> Nouveau</button>
          <button className="btn ghost" onClick={() => { const c = duplicateTimetable(tt, uid(), `${tt.name} (copie)`); const st = addTimetable(tt, saved, c); setData('timetables', st.saved); setData('timetable', st.active); setDlg(null); toast('Copie créée — c\'est elle qui est affichée'); }}>Dupliquer</button>
          <button className="btn ghost" onClick={() => setDlg('rename')}>Renommer</button>
          <button className="btn ghost danger" onClick={() => { setDlg(null); setClear(true); }}><IcoTrash size={13} /> Supprimer celui-ci</button>
        </div>
      </Modal>}
    </div>
  );
}

function BlockModal({ tt, day, slot, cur, subjects, onClose, onSave }: { tt: ClassTimetable; day: string; slot: string; cur?: Block; subjects: string[]; onClose: () => void; onSave: (t: ClassTimetable) => void }) {
  const start = cur ? cur.slot : slot;
  const [subj, setSubj] = useState(cur ? (cur.kind === 'etude' ? ETUDE : cur.subject) : '');
  const [span, setSpan] = useState(cur ? cur.span : 1);
  const [room, setRoom] = useState(cur?.room || '');
  const [teacher, setTeacher] = useState(cur?.teacher || '');
  const limit = maxSpan(tt, day, start, cur?.id);
  const slotLabel = tt.slots.find(s => s.id === start);
  const pick = (v: string) => { setSubj(v); if (!cur && v !== ETUDE) setTeacher(tt.teachers[v] || ''); };
  const others = tt.blocks.filter(b => b.id !== cur?.id);
  const ok = () => {
    if (!subj) return toast('Choisis une matière', 'warn');
    const etude = subj === ETUDE;
    const b: Block = { id: cur?.id || uid(), day, slot: start, span: Math.min(span, limit), subject: etude ? 'Étude / Devoir' : subj, kind: etude ? 'etude' : 'cours', room: room.trim() || undefined, teacher: etude ? undefined : (teacher.trim() || undefined) };
    const teachers = { ...tt.teachers }; if (!etude && teacher.trim()) teachers[subj] = teacher.trim();
    onSave({ ...tt, blocks: [...others, b], teachers }); toast('Emploi du temps mis à jour'); onClose();
  };
  const del = () => { const before = tt; onSave({ ...tt, blocks: others }); onClose(); toast('Cours retiré', 'ok', { label: 'Annuler', cb: () => onSave(before) }); };
  return (
    <Modal title={`${day} · ${slotLabel?.label} (${slotLabel ? slotRange(slotLabel) : ''})`} onClose={onClose}
      footer={<>{cur && <button className="btn ghost danger" onClick={del}>Retirer</button>}<button className="btn ghost" onClick={onClose}>Annuler</button><button className="btn" onClick={ok}>Enregistrer</button></>}>
      {cur?.uncertain && <div className="ctt-warn" style={{ marginBottom: 10 }}>Cette case est marquée « ? ». <button className="btn ghost sm" onClick={() => { onSave({ ...tt, blocks: tt.blocks.map(b => b.id === cur.id ? { ...b, uncertain: undefined } : b) }); toast('Case confirmée'); onClose(); }}>C'est correct, confirmer</button></div>}
      <Field label="Matière"><select className="input" value={subj} onChange={e => pick(e.target.value)}><option value="">—</option>{subjects.map(n => <option key={n} value={n}>{n}</option>)}<option value={ETUDE}>Étude / Devoir surveillé</option></select></Field>
      <Field label="Durée"><select className="input" value={Math.min(span, limit)} onChange={e => setSpan(+e.target.value)}>{Array.from({ length: limit }, (_, i) => i + 1).map(n => <option key={n} value={n}>{n} créneau{n > 1 ? 'x' : ''}</option>)}</select></Field>
      <Field label="Salle (optionnel)"><input className="input" value={room} onChange={e => setRoom(e.target.value)} placeholder={tt.room ? `Par défaut : ${tt.room}` : ''} /></Field>
      {subj !== ETUDE && <Field label="Professeur (optionnel)"><input className="input" value={teacher} onChange={e => setTeacher(e.target.value)} /></Field>}
    </Modal>
  );
}

function SlotsModal({ tt, onClose, onSave }: { tt: ClassTimetable; onClose: () => void; onSave: (t: ClassTimetable) => void }) {
  const [slots, setSlots] = useState<Slot[]>(() => tt.slots.map(s => ({ ...s })));
  const set = (i: number, p: Partial<Slot>) => setSlots(slots.map((s, j) => j === i ? { ...s, ...p } : s));
  const err = validateSlots(slots);
  const add = (kind: 'cours' | 'pause') => {
    const last = slots[slots.length - 1], st = last ? minutes(last.end) : 480, len = kind === 'pause' ? 15 : 55, f = (v: number) => toStored(`${Math.floor(v / 60)}:${String(v % 60).padStart(2, '0')}`);
    const n = slots.filter(s => s.kind === kind).length + 1;
    setSlots([...slots, { id: uid(), label: kind === 'pause' ? `Pause ${n}` : `C${n}`, start: f(st), end: f(st + len), kind }]);
  };
  const ok = () => { if (err) return toast(err, 'warn'); onSave({ ...tt, slots }); toast('Horaires mis à jour'); onClose(); };
  return (
    <Modal title="Horaires des créneaux" wide onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>Annuler</button><button className="btn" onClick={ok} disabled={!!err}>Enregistrer</button></>}>
      <p className="muted" style={{ marginTop: 0 }}>Change l'heure de début et de fin de chaque créneau. Les cours déjà placés suivent automatiquement. Les créneaux gardent cet ordre ; un créneau utilisé par un cours ne peut pas être supprimé.</p>
      {err && <div className="ctt-warn" role="alert">{err}</div>}
      <div className="slot-rows">
        {slots.map((s, i) => {
          const used = slotInUse(tt, s.id);
          return (
            <div key={s.id} className="slot-row">
              <input className="input" aria-label={`Nom du créneau ${i + 1}`} value={s.label} onChange={e => set(i, { label: e.target.value })} />
              <span className="chip" style={{ flex: 'none' }}>{s.kind === 'pause' ? 'Pause' : 'Cours'}</span>
              <div className="slot-times">
                <input className="input" type="time" aria-label={`Début de ${s.label}`} value={toInput(s.start)} onChange={e => e.target.value && set(i, { start: toStored(e.target.value) })} />
                <span aria-hidden="true">→</span>
                <input className="input" type="time" aria-label={`Fin de ${s.label}`} value={toInput(s.end)} onChange={e => e.target.value && set(i, { end: toStored(e.target.value) })} />
              </div>
              <button className="icon-btn" aria-label={used ? `${s.label} est utilisé par un cours` : `Supprimer ${s.label}`} title={used ? 'Utilisé par un cours' : 'Supprimer'} disabled={used} onClick={() => setSlots(slots.filter((_, j) => j !== i))}><IcoTrash size={14} /></button>
            </div>);
        })}
      </div>
      <div className="row" style={{ gap: 8, marginTop: 10, flexWrap: 'wrap' }}>
        <button className="btn ghost sm" onClick={() => add('cours')}><IcoPlus size={13} /> Ajouter un créneau de cours</button>
        <button className="btn ghost sm" onClick={() => add('pause')}><IcoPlus size={13} /> Ajouter une pause</button>
      </div>
    </Modal>
  );
}

function ExportModal({ tt, onClose }: { tt: ClassTimetable; onClose: () => void }) {
  const today = todayISO();
  const [from, setFrom] = useState(today), [until, setUntil] = useState(defaultUntil(today)), [alarm, setAlarm] = useState('10');
  const bad = !from || !until || until < from;
  const opts = { from, until, alarmMin: +alarm || null };
  const n = bad ? 0 : countIcsEvents(buildTimetableICS(tt, opts));
  return (
    <Modal title="Exporter vers mon agenda (.ics)" onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>Fermer</button><button className="btn" disabled={bad || !n} onClick={() => { exportTimetableICS(tt, opts); toast('Fichier .ics téléchargé'); onClose(); }}>Télécharger le fichier</button></>}>
      <p className="muted" style={{ marginTop: 0 }}>Le fichier contient tes cours, répétés chaque semaine. Ouvre-le sur ton téléphone ou ton ordinateur : l'agenda (Google Agenda, Apple, Outlook) te propose de les ajouter. Cette application ne peut pas écrire directement dans ton agenda : le fichier est le chemin fiable.</p>
      <Field label="Du"><input className="input" type="date" value={from} onChange={e => setFrom(e.target.value)} /></Field>
      <Field label="Jusqu'au (inclus)"><input className="input" type="date" value={until} min={from} onChange={e => setUntil(e.target.value)} /></Field>
      <Field label="Rappel avant chaque cours"><select className="input" value={alarm} onChange={e => setAlarm(e.target.value)}><option value="0">Aucun</option><option value="5">5 minutes</option><option value="10">10 minutes</option><option value="15">15 minutes</option><option value="30">30 minutes</option></select></Field>
      {bad ? <div className="ctt-warn" role="alert">La date de fin doit être après la date de début.</div> : <p className="muted" style={{ fontSize: 12, marginBottom: 0 }}>{n} cours seront ajoutés (heure de Côte d'Ivoire, GMT). Si tu importes deux fois, certains agendas créent des doublons : supprime l'ancien import avant de recommencer.</p>}
    </Modal>
  );
}

function RemindModal({ onClose }: { onClose: () => void }) {
  const [min, setMin] = useState(String(getTtRemind()));
  const [perm, setPerm] = useState<string>('Notification' in window ? Notification.permission : 'unsupported');
  const ask = async () => { try { setPerm(await Notification.requestPermission()); } catch { /* ignore */ } };
  const ok = () => { setTtRemind(+min); if (+min > 0 && perm === 'default') void ask(); toast(+min > 0 ? `Rappel ${min} min avant chaque cours` : 'Rappels désactivés'); onClose(); };
  return (
    <Modal title="Rappels avant les cours" onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>Annuler</button><button className="btn" onClick={ok}>Enregistrer</button></>}>
      <Field label="Me prévenir avant chaque cours"><select className="input" value={min} onChange={e => setMin(e.target.value)}><option value="0">Jamais</option><option value="5">5 minutes avant</option><option value="10">10 minutes avant</option><option value="15">15 minutes avant</option><option value="30">30 minutes avant</option></select></Field>
      <p className="muted" style={{ fontSize: 12.5 }}>Honnêtement : ces rappels n'apparaissent que si KENNY'S MOAS est ouverte (même en arrière-plan). Application fermée, rien ne sonne. Pour que ton téléphone sonne tout seul, utilise « Exporter (.ics) » avec un rappel : c'est l'agenda du téléphone qui s'en charge.</p>
      {perm === 'unsupported' && <div className="ctt-warn">Ce navigateur ne gère pas les notifications.</div>}
      {perm === 'denied' && <div className="ctt-warn">Les notifications sont bloquées pour ce site : autorise-les dans les réglages du navigateur.</div>}
      {perm === 'default' && <button className="btn ghost sm" onClick={ask}>Autoriser les notifications</button>}
      {perm === 'granted' && <div className="muted" style={{ fontSize: 12 }}>Notifications autorisées.</div>}
    </Modal>
  );
}
