import { useEffect, useState } from 'react';
import { ViewId } from '../types';
import { IcoHW, IcoBook, IcoGrades, IcoTimer, IcoPlus, IcoArrowRight, IcoStar, IcoLightbulb, IcoCal } from '../components/Icons';
import { getClass, getData, useStore } from '../lib/store';
import { overallAvg, subjAvg, subjColor } from '../lib/calc';
import { erreursDues } from '../lib/leitner';
import { listFiles, kindOf } from '../lib/files';
import type { LibFile } from '../lib/db';
import { EVCOLORS } from '../lib/model';
import { fmtD, isoAddDays, isoOf, todayISO } from '../lib/util';
import { isLate, isUrgent } from './Homework';
import { fmtTime, minutes, todaysBlocks } from '../lib/timetable';

interface Props { onView: (v: ViewId) => void; onCommand?: (c: string) => void }

const TIPS = [
  ['Feynman', 'Explique le concept que tu dois maîtriser comme si tu l’enseignais à un enfant de 10 ans. Là où tu bloques, c’est là que se cachent tes lacunes.'],
  ['Rappel actif', 'Ferme ton cahier et écris de mémoire tout ce que tu retiens du chapitre, puis compare : c’est bien plus efficace que relire.'],
  ['Répétition espacée', 'Reviens sur une notion après 1, 3, 7 puis 15 jours : tes remarques d’erreurs te la représentent automatiquement.'],
  ['Pomodoro', 'Travaille 25 minutes sans interruption, puis 5 minutes de pause. Après 4 cycles, prends une vraie pause.'],
];

export default function Dashboard({ onView, onCommand }: Props) {
  const tick = useStore();
  const subjects = getData('subjects'), grades = getData('grades'), hw = getData('homework'), events = getData('events'), errors = getData('errors'), sessions = getData('sessions');
  const [files, setFiles] = useState<LibFile[]>([]);
  useEffect(() => { let dead = false; listFiles().then(f => { if (!dead) setFiles(f); }); return () => { dead = true; }; }, [tick]);

  const avg = overallAvg(subjects, grades), goal = getData('goal');
  const pending = hw.filter(h => !h.done), urgent = pending.filter(isUrgent).length;
  const monthStart = isoOf(new Date(new Date().getFullYear(), new Date().getMonth(), 1));
  const mins = sessions.filter(s => new Date(s.date) >= new Date(monthStart + 'T00:00')).reduce((a, s) => a + s.min, 0);
  const dues = erreursDues(errors).length;
  const today = todayISO(), soon = isoAddDays(today, 7);
  const upcoming = pending.slice().sort((a, b) => (a.due || '9999').localeCompare(b.due || '9999')).slice(0, 5);
  const todayEvents = events.filter(e => e.date === today);
  const ttToday = (() => { const tt = getData('timetable'); return tt ? todaysBlocks(tt, new Date()).map(x => ({ ...x, room: x.block.room || tt.room })) : []; })();
  const nowMin = new Date().getHours() * 60 + new Date().getMinutes();
  const nextEvents = events.filter(e => e.date > today && e.date <= soon).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 4);
  const avgs = subjects.map(s => ({ s, a: subjAvg(grades, s.name) })).filter(x => x.a != null) as { s: { name: string; coef: number }; a: number }[];
  const tip = TIPS[new Date().getDate() % TIPS.length];
  const dateLabel = new Date().toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });

  const STATS = [
    { lbl: 'Moyenne générale', val: avg != null ? avg.toFixed(2) : '—', unit: avg != null ? '/20' : '', trend: goal != null && avg != null ? `objectif ${goal}/20 (${avg >= goal ? '+' : ''}${(avg - goal).toFixed(2)})` : 'aucune note', up: goal == null || avg == null || avg >= goal },
    { lbl: 'Devoirs en attente', val: String(pending.length), unit: '', trend: urgent ? `${urgent} urgent${urgent > 1 ? 's' : ''}` : 'rien d’urgent', up: !urgent },
    { lbl: 'Fichiers importés', val: String(files.length), unit: '', trend: `dont ${files.filter(f => kindOf(f) === 'pdf').length} PDF`, up: true },
    { lbl: 'Révision ce mois-ci', val: mins >= 60 ? (mins / 60).toFixed(1) : String(mins), unit: mins >= 60 ? 'h' : ' min', trend: dues ? `${dues} remarque${dues > 1 ? 's' : ''} à revoir` : 'à jour', up: !dues },
  ];

  return (
    <div className="anim-in">
      <div className="page-intro">
        <div><h2>Tableau de bord</h2><div className="sub" style={{ textTransform: 'capitalize' }}>{dateLabel} · {getClass()}</div></div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn ghost sm" onClick={() => onView('library')}><IcoBook size={14} /> Bibliothèque</button>
          <button className="btn sm" onClick={() => onCommand?.('add-homework')}><IcoPlus size={14} /> Ajouter un devoir</button>
        </div>
      </div>

      <div className="stat-grid">
        {STATS.map((s, i) => (
          <div key={i} className="stat-card"><div className="stat-lbl">{s.lbl}</div><div className="stat-val">{s.val}<small>{s.unit}</small></div><div className={`stat-trend${s.up ? ' up' : ' down'}`}>{s.trend}</div></div>
        ))}
      </div>

      <div className="dash-grid">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          <div className="card">
            <div className="section-header"><h3><IcoCal size={16} /> Aujourd’hui</h3><button className="btn ghost sm" onClick={() => onView('schedule')}>Calendrier <IcoArrowRight size={13} /></button></div>
            {!ttToday.length && !todayEvents.length && !dues && !pending.some(h => h.due === today) ? <p className="muted">Rien de prévu aujourd’hui.</p> : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {ttToday.map(x => { const etude = x.block.kind === 'etude', now = nowMin >= minutes(x.start) && nowMin < minutes(x.end); return (
                  <div key={x.block.id} className="hw-item" aria-current={now ? 'true' : undefined}><div className="hw-dot" style={{ background: etude ? 'var(--mut)' : subjColor(x.block.subject) }} /><div className="hw-body"><div className="hw-title">{fmtTime(x.start)}–{fmtTime(x.end)} · {etude ? 'Étude / Devoir' : x.block.subject}{now && <span className="chip" style={{ marginLeft: 6, fontSize: 10, padding: '1px 7px' }}>En cours</span>}</div><div className="hw-meta">{[x.room && `Salle ${x.room}`, x.block.teacher].filter(Boolean).join(' · ') || 'Cours'}</div></div></div>); })}
                {todayEvents.map(e => <div key={e.id} className="hw-item"><div className="hw-dot" style={{ background: EVCOLORS[e.type] || 'var(--mut)' }} /><div className="hw-body"><div className="hw-title">{e.time ? e.time + ' · ' : ''}{e.title}</div><div className="hw-meta">{e.subject || 'Événement'}</div></div></div>)}
                {pending.filter(h => h.due === today).map(h => <div key={h.id} className="hw-item"><div className="hw-dot urgent" /><div className="hw-body"><div className="hw-title">{h.title}</div><div className="hw-meta">À rendre aujourd’hui · {h.subject}</div></div></div>)}
                {dues > 0 && <div className="hw-item" style={{ cursor: 'pointer' }} onClick={() => onView('errors')}><IcoLightbulb size={15} style={{ color: 'var(--p)' }} /><div className="hw-body"><div className="hw-title">{dues} remarque{dues > 1 ? 's' : ''} à revoir</div><div className="hw-meta">Répétition espacée</div></div></div>}
              </div>)}
            {nextEvents.length > 0 && <div style={{ marginTop: 12, paddingTop: 10, borderTop: '1px solid var(--bd)' }}><div className="stat-lbl" style={{ marginBottom: 6 }}>Cette semaine</div>{nextEvents.map(e => <div key={e.id} className="hw-meta" style={{ marginBottom: 3 }}><b style={{ color: EVCOLORS[e.type] }}>{fmtD(e.date)}</b> · {e.title}</div>)}</div>}
          </div>

          <div className="card">
            <div className="section-header"><h3><IcoHW size={16} /> Devoirs à venir</h3><button className="btn ghost sm" onClick={() => onView('homework')}>Tous les devoirs <IcoArrowRight size={13} /></button></div>
            {!upcoming.length ? <p className="muted">Aucun devoir en attente.</p> : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>{upcoming.map(h => (
                <div key={h.id} className="hw-item"><div className={`hw-dot${isUrgent(h) ? ' urgent' : ''}`} /><div className="hw-body"><div className="hw-title">{h.title}</div>
                  <div className="hw-meta"><span>{h.subject}</span>{h.due && <><span>·</span><span style={{ color: isUrgent(h) ? '#c0392b' : 'var(--mut)', fontWeight: isUrgent(h) ? 700 : 500 }}>{isLate(h) ? 'en retard · ' : ''}{fmtD(h.due)}</span></>}
                    {isUrgent(h) && <span className="chip" style={{ background: 'rgba(192,57,43,.1)', color: '#c0392b', border: '1px solid rgba(192,57,43,.2)', fontSize: 10, padding: '1px 7px' }}>Urgent</span>}</div></div></div>))}</div>)}
          </div>

          <div className="card">
            <div className="section-header"><h3><IcoGrades size={16} /> Moyennes par matière</h3><button className="btn ghost sm" onClick={() => onView('grades')}>Détail <IcoArrowRight size={13} /></button></div>
            {!avgs.length ? <p className="muted">Ajoute une première note pour voir tes moyennes.</p> : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>{avgs.map(({ s, a }) => (
                <div key={s.name}><div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}><span style={{ fontSize: 13, fontWeight: 600 }}>{s.name}</span>
                  <span style={{ fontSize: 13.5, fontFamily: 'var(--font-head)', fontWeight: 700 }}>{a.toFixed(1)}<span style={{ fontSize: 11, color: 'var(--mut)', fontFamily: 'var(--font-main)' }}>/20</span></span></div>
                  <div className="prog-bar"><div className="prog-bar-fill" style={{ width: `${(a / 20) * 100}%`, background: subjColor(s.name) }} /></div></div>))}</div>)}
          </div>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          <div className="card">
            <h3 style={{ marginBottom: 12 }}>Actions rapides</h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              {[
                { label: 'Importer un fichier', icon: <IcoBook size={15} />, run: () => onView('library') },
                { label: 'Ajouter un devoir', icon: <IcoHW size={15} />, run: () => onCommand?.('add-homework') },
                { label: 'Démarrer une révision', icon: <IcoTimer size={15} />, run: () => onCommand?.('pomodoro') },
                { label: 'Saisir une note', icon: <IcoGrades size={15} />, run: () => onCommand?.('add-grade') },
              ].map(a => <button key={a.label} className="btn ghost" style={{ justifyContent: 'flex-start', width: '100%', padding: '9px 12px', fontSize: 13 }} onClick={a.run}>{a.icon}{a.label}</button>)}
            </div>
          </div>

          <div className="card">
            <div className="section-header"><h3><IcoBook size={16} /> Fichiers récents</h3><button className="btn ghost sm" onClick={() => onView('library')}>Voir tout <IcoArrowRight size={13} /></button></div>
            {!files.length ? <p className="muted">Aucun fichier importé.</p> : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>{files.slice(0, 4).map(f => (
                <div key={f.id} style={{ display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer', padding: '6px 8px', borderRadius: 8 }} onClick={() => onView('library')}>
                  <IcoBook size={20} style={{ color: subjColor(f.subject || 'x'), flexShrink: 0 }} />
                  <div style={{ flex: 1, minWidth: 0 }}><div style={{ fontSize: 13, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{f.name}</div><div style={{ fontSize: 11.5, color: 'var(--mut)' }}>{f.subject || 'Sans matière'} · {fmtD(isoOf(new Date(f.date)))}</div></div></div>))}</div>)}
          </div>

          <div className="card" style={{ background: 'color-mix(in srgb, var(--p) 6%, var(--card))', borderColor: 'color-mix(in srgb, var(--p) 20%, var(--bd))' }}>
            <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}><IcoStar size={18} style={{ color: 'var(--p)', flexShrink: 0, marginTop: 2 }} />
              <div><div style={{ fontWeight: 700, fontSize: 13.5, marginBottom: 4, color: 'var(--p)', fontFamily: 'var(--font-head)' }}>Conseil du jour — {tip[0]}</div><div style={{ fontSize: 12.5, color: 'var(--txt)', lineHeight: 1.6 }}>{tip[1]}</div></div></div>
          </div>
        </div>
      </div>
    </div>
  );
}
