import { useEffect, useState } from 'react';
import { IcoLightbulb, IcoPlus } from '../components/Icons';
import { Cols, Field, Modal } from '../components/ui';
import type { ErrorItem, RemarkGenre } from '../lib/model';
import { GENRE_LABEL, REMARK_GENRES } from '../lib/model';
import { getData, setData, update, useStore } from '../lib/store';
import { erreursDues, migrateErrors, planifier } from '../lib/leitner';
import { subjColor } from '../lib/calc';
import { toast } from '../lib/toast';
import { fmtD, todayISO, uid } from '../lib/util';
import { removeObject } from '../lib/deletion';

export function ErrorForm({ id, onClose }: { id?: string; onClose: () => void }) {
  const cur = id ? getData('errors').find(e => e.id === id) : undefined;
  const subjects = getData('subjects');
  const [f, setF] = useState({ genre: (cur?.genre || 'erreur') as RemarkGenre, texte: cur?.texte || '', subject: cur?.subject || subjects[0]?.name || '', chapter: cur?.chapter || '', question: cur?.question || '', mistake: cur?.mistake || '', method: cur?.method || '' });
  const set = (k: keyof typeof f, v: string) => setF(p => ({ ...p, [k]: v }));
  const save = () => {
    if (f.genre === 'erreur' ? !f.question.trim() && !f.mistake.trim() : !f.texte.trim()) return toast(f.genre === 'erreur' ? 'Décris au moins la question ou l’erreur' : 'Écris ta remarque', 'warn');
    const rec: ErrorItem = { fileId: null, linkType: null, linkId: null, date: todayISO(), boite: 0, prochaineRevision: todayISO(), links: [], source: null, ...(cur || {}), ...f, id: cur?.id || uid() };
    setData('errors', cur ? getData('errors').map(e => (e.id === cur.id ? rec : e)) : [...getData('errors'), rec]);
    toast(cur ? 'Remarque modifiée' : 'Remarque ajoutée'); onClose();
  };
  const del = async () => {
    const all = getData('errors'), idx = all.findIndex(e => e.id === id), removed = all[idx]; if (!removed) return;
    const ok = await removeObject({ type: 'remark', id: id as string }, 'cette remarque', {
      remove: () => setData('errors', getData('errors').filter(e => e.id !== id)),
      restore: () => { const a = getData('errors').slice(); a.splice(idx, 0, removed); setData('errors', a); }, done: 'Remarque supprimée' });
    if (ok) onClose();
  };
  return (
    <Modal size="md" title={cur ? 'Modifier la remarque' : 'Nouvelle remarque'} onClose={onClose} footer={<>
      {cur && <button className="btn danger ghost" onClick={del}>Supprimer</button>}<span style={{ flex: 1 }} />
      <button className="btn ghost" onClick={onClose}>Annuler</button><button className="btn" onClick={save}>Enregistrer</button></>}>
      <Field label="Genre"><select className="input" value={f.genre} onChange={e => set('genre', e.target.value)}>{REMARK_GENRES.map(g => <option key={g} value={g}>{GENRE_LABEL[g]}</option>)}</select></Field>
      <Cols>
        <Field label="Matière"><select className="input" value={f.subject} onChange={e => set('subject', e.target.value)}>{subjects.map(s => <option key={s.name}>{s.name}</option>)}</select></Field>
        <Field label="Chapitre"><input className="input" value={f.chapter} onChange={e => set('chapter', e.target.value)} /></Field>
      </Cols>
      {f.genre !== 'erreur' && <Field label="Ma remarque"><textarea className="input" rows={3} value={f.texte} onChange={e => set('texte', e.target.value)} /></Field>}
      {f.genre === 'erreur' && <>
      <Field label="Question / énoncé"><textarea className="input" rows={2} value={f.question} onChange={e => set('question', e.target.value)} /></Field>
      <Field label="Mon erreur"><textarea className="input" rows={2} value={f.mistake} onChange={e => set('mistake', e.target.value)} /></Field>
      <Field label="Méthode / correction"><textarea className="input" rows={2} value={f.method} onChange={e => set('method', e.target.value)} /></Field></>}
    </Modal>
  );
}

/* Séance de répétition espacée (Leitner) : on montre la question, l'élève se souvient, puis « Réussi » / « À revoir ». */
function ReviewSession({ onClose }: { onClose: () => void }) {
  const [queue] = useState(() => erreursDues(getData('errors')).map(e => e.id));
  const [i, setI] = useState(0); const [show, setShow] = useState(false);
  const cur = getData('errors').find(e => e.id === queue[i]);
  const answer = (ok: boolean) => { if (cur) update('errors', es => es.map(e => (e.id === cur.id ? planifier(e, ok) : e))); setShow(false); setI(n => n + 1); };
  const finished = !cur;
  return (
    <Modal title={finished ? 'Séance terminée' : `Révision ${i + 1}/${queue.length}`} onClose={onClose} footer={finished ? <button className="btn" onClick={onClose}>Fermer</button> : show ? <><button className="btn ghost" onClick={() => answer(false)}>À revoir</button><button className="btn green" onClick={() => answer(true)}>Réussi</button></> : <button className="btn" onClick={() => setShow(true)}>Afficher la correction</button>}>
      {finished ? <p>{queue.length ? 'Bravo, tout est revu pour aujourd’hui.' : 'Aucune remarque à revoir aujourd’hui.'}</p> : (<>
        <div className="badge">{cur.subject}{cur.chapter ? ' · ' + cur.chapter : ''}</div>
        <div><div className="field-lbl">Question</div><p style={{ marginTop: 4 }}>{cur.question || '—'}</p></div>
        {show && <><div><div className="field-lbl">Mon erreur</div><p style={{ marginTop: 4 }}>{cur.mistake || '—'}</p></div><div><div className="field-lbl">Méthode</div><p style={{ marginTop: 4 }}>{cur.method || '—'}</p></div></>}
      </>)}
    </Modal>
  );
}

export function ErrorsView() {
  useStore();
  const errors = getData('errors'); const dues = erreursDues(errors);
  const [edit, setEdit] = useState<string | null | undefined>(undefined);
  const [rev, setRev] = useState(false); const [subj, setSubj] = useState('');
  useEffect(() => { const m = migrateErrors(getData('errors')); if (m.changed) setData('errors', m.list); }, []);
  const week = errors.filter(e => e.date >= new Date(Date.now() - 7 * 864e5).toISOString().slice(0, 10)).length;
  const list = errors.filter(e => !subj || e.subject === subj).slice().reverse();
  return (
    <div className="anim-in">
      <div className="page-intro"><div><h2>Remarques</h2><div className="sub">Erreurs, choses à retenir, questions, idées — la répétition espacée te les représente au bon moment.</div></div>
        <div className="row"><button className="btn ghost sm" onClick={() => setRev(true)} disabled={!dues.length}><IcoLightbulb size={14} /> Réviser ({dues.length})</button><button className="btn sm" onClick={() => setEdit(null)}><IcoPlus size={14} /> Ajouter</button></div></div>
      <div className="stat-grid">
        {([['Total', errors.length], ['Cette semaine', week], ['À revoir aujourd’hui', dues.length], ['Maîtrisées (boîte 5)', errors.filter(e => (e.boite ?? 0) >= 4).length]] as [string, number][]).map(([l, v]) => <div key={l} className="stat-card"><div className="stat-lbl">{l}</div><div className="stat-val">{v}</div></div>)}
      </div>
      <div className="tabs" style={{ marginTop: 18 }}><select className="input" style={{ width: 'auto' }} value={subj} onChange={e => setSubj(e.target.value)}><option value="">Toutes matières</option>{getData('subjects').map(s => <option key={s.name}>{s.name}</option>)}</select></div>
      {!list.length ? <div className="card"><p className="muted">Aucune remarque pour l’instant.</p></div> : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>{list.map(e => (
          <div key={e.id} className="list-item" style={{ cursor: 'pointer', borderLeft: `3px solid ${subjColor(e.subject)}` }} onClick={() => setEdit(e.id)}>
            <IcoLightbulb size={16} style={{ color: 'var(--p)', marginTop: 2, flexShrink: 0 }} />
            <div className="body"><h4>{e.mistake || e.question || e.texte}</h4>
              <div className="row muted" style={{ gap: 6, marginTop: 3, fontSize: 12 }}><span>{e.subject}{e.chapter ? ' · ' + e.chapter : ''}</span><span className="badge">{GENRE_LABEL[e.genre || 'erreur']}</span>{e.source?.type === 'file' && e.source.page != null && <span className="badge">dans un fichier · p.{e.source.page}</span>}<span className="badge">Boîte {(e.boite ?? 0) + 1}/5</span>{e.prochaineRevision && <span>revoir le {fmtD(e.prochaineRevision)}</span>}</div>
              {typeof e.quote === 'string' && e.quote && <div className="muted" style={{ marginTop: 4, fontSize: 12.5, fontStyle: 'italic' }}>« {e.quote} »</div>}
              {e.method && <div className="muted" style={{ marginTop: 4, fontSize: 12.5 }}>{e.method}</div>}</div>
          </div>))}</div>)}
      {edit !== undefined && <ErrorForm id={edit || undefined} onClose={() => setEdit(undefined)} />}
      {rev && <ReviewSession onClose={() => setRev(false)} />}
    </div>
  );
}
