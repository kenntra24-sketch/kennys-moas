import { useState } from 'react';
import { IcoPlus, IcoTarget } from '../components/Icons';
import { AskText } from '../components/ui';
import { overallAvg } from '../lib/calc';
import { getData, setData, useStore } from '../lib/store';
import { toast } from '../lib/toast';

export function GoalsView() {
  useStore();
  const goal = getData('goal'), avg = overallAvg(getData('subjects'), getData('grades'));
  const [ask, setAsk] = useState(false);
  const gap = avg != null && goal != null ? avg - goal : null;
  return (
    <div className="anim-in">
      <div className="page-intro"><div><h2>Objectifs</h2><div className="sub">Définis ta moyenne visée et suis ta progression.</div></div>
        <button className="btn sm" onClick={() => setAsk(true)}><IcoPlus size={14} /> {goal == null ? 'Définir un objectif' : 'Modifier'}</button></div>
      <div className="card">
        {goal == null ? (
          <div style={{ textAlign: 'center', padding: '32px 24px' }}><IcoTarget size={40} style={{ color: 'var(--p)' }} /><h3 style={{ fontSize: 18, margin: '12px 0 8px' }}>Aucun objectif défini</h3>
            <p className="muted" style={{ marginBottom: 18 }}>Fixe une moyenne générale à atteindre (sur 20).</p><button className="btn" onClick={() => setAsk(true)}>Définir un objectif</button></div>
        ) : (<>
          <div className="stat-grid" style={{ marginBottom: 16 }}>
            <div className="stat-card"><div className="stat-lbl">Objectif</div><div className="stat-val">{goal}<small>/20</small></div></div>
            <div className="stat-card"><div className="stat-lbl">Moyenne actuelle</div><div className="stat-val">{avg != null ? avg.toFixed(2) : '—'}</div></div>
            <div className="stat-card"><div className="stat-lbl">Écart</div><div className="stat-val" style={{ color: gap != null && gap >= 0 ? 'var(--s)' : '#c0392b' }}>{gap != null ? (gap >= 0 ? '+' : '') + gap.toFixed(2) : '—'}</div></div>
          </div>
          <div className="bar-h" style={{ height: 12 }}><i style={{ width: `${avg != null ? Math.min(100, (avg / goal) * 100) : 0}%` }} /></div>
        </>)}
      </div>
      {ask && <AskText title="Objectif" label="Objectif de moyenne générale (/20)" type="number" initial={goal ?? 14} onClose={() => setAsk(false)} onOk={v => { const n = parseFloat(v); if (!isNaN(n) && n > 0 && n <= 20) { setData('goal', n); toast('Objectif enregistré'); } else toast('Valeur invalide (0–20)', 'warn'); }} />}
    </div>
  );
}
