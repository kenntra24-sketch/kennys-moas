import { useState } from 'react';
import { IcoGrades, IcoPlus } from '../components/Icons';
import { Cols, Field, FileField, Modal } from '../components/ui';
import { GRADE_SCALES, GRADE_TYPES, type Grade } from '../lib/model';
import { getData, setData, useStore } from '../lib/store';
import { SubjectIcon } from '../components/SubjectIcon';
import { gradeDateISO, gradeDisplayScore, overallAvg, subjAvg, subjColor } from '../lib/calc';
import { toast } from '../lib/toast';
import { fmtD, todayISO, uid } from '../lib/util';
import { removeObject } from '../lib/deletion';

const typeLabel = (t?: string) => GRADE_TYPES.find(x => x[0] === t)?.[1] || t || 'Note';
const col = (v: number | null) => (v == null ? 'inherit' : v >= 14 ? 'var(--s)' : v < 10 ? '#c0392b' : 'var(--txt)');

export function GradeForm({ id, presetSubject, onClose }: { id?: string; presetSubject?: string; onClose: () => void }) {
  const g = id ? getData('grades').find(x => x.id === id) : undefined;
  const subjects = getData('subjects'), hws = getData('homework');
  const [subject, setSubject] = useState(g?.subject || presetSubject || subjects[0]?.name || '');
  const [raw, setRaw] = useState(g ? String(g.rawScore) : '');
  const [scale, setScale] = useState(g ? (GRADE_SCALES.includes(g.maxScore) ? String(g.maxScore) : 'custom') : '20');
  const [custom, setCustom] = useState(g && !GRADE_SCALES.includes(g.maxScore) ? String(g.maxScore) : '600');
  const [coef, setCoef] = useState(String(g?.coef ?? 1));
  const [type, setType] = useState(g?.type || 'devoir');
  const [date, setDate] = useState(g ? gradeDateISO(g) : todayISO());
  const [hw, setHw] = useState(g?.homeworkId || '');
  const [desc, setDesc] = useState(g?.desc || '');
  const [fileId, setFileId] = useState<string | null>(g?.fileId ?? null);
  const max = scale === 'custom' ? parseFloat(custom) : parseFloat(scale);
  const r = parseFloat(raw);
  const conv = Number.isFinite(r) && Number.isFinite(max) && max > 0 ? (r / max) * 20 : null;
  const save = () => {
    if (!Number.isFinite(r) || !Number.isFinite(max) || r < 0 || max <= 0 || r > max) return toast('Note ou barème invalide', 'warn');
    let co = parseFloat(coef); if (isNaN(co) || co <= 0) co = 1;
    const rec: Grade = { ...(g || {}), id: g?.id || uid(), subject, rawScore: r, maxScore: max, value: (r / max) * 20, coef: co, type, date, homeworkId: hw || null, desc, fileId };
    setData('grades', g ? getData('grades').map(x => (x.id === g.id ? rec : x)) : [...getData('grades'), rec]);
    toast(g ? 'Note modifiée' : 'Note ajoutée'); onClose();
  };
  return (
    <Modal title={g ? 'Modifier la note' : 'Ajouter une note'} onClose={onClose} footer={<>
      {g && <button className="btn danger ghost" onClick={async () => { if (await removeGrade(g.id)) onClose(); }}>Supprimer</button>}
      <span style={{ flex: 1 }} /><button className="btn ghost" onClick={onClose}>Annuler</button><button className="btn" onClick={save}>Enregistrer</button></>}>
      <Field label="Matière"><select className="input" value={subject} onChange={e => setSubject(e.target.value)}>{subjects.map(s => <option key={s.name}>{s.name}</option>)}</select></Field>
      <Cols>
        <Field label="Note obtenue"><input className="input" type="number" min={0} step="0.01" value={raw} onChange={e => setRaw(e.target.value)} placeholder="ex. 15" autoFocus /></Field>
        <Field label="Barème"><select className="input" value={scale} onChange={e => setScale(e.target.value)}>{GRADE_SCALES.map(v => <option key={v} value={v}>{v}/20</option>)}<option value="custom">Personnalisé…</option></select></Field>
      </Cols>
      {scale === 'custom' && <Field label="Barème personnalisé"><input className="input" type="number" min={0.01} step="0.01" value={custom} onChange={e => setCustom(e.target.value)} /></Field>}
      <div className="muted">{conv != null ? `Équivalent : ${conv.toFixed(2)}/20` : 'Saisis la note et le barème pour voir la conversion sur 20.'}</div>
      <Cols>
        <Field label="Coefficient"><input className="input" type="number" min={0.5} step="0.5" value={coef} onChange={e => setCoef(e.target.value)} /></Field>
        <Field label="Type d’évaluation"><select className="input" value={type} onChange={e => setType(e.target.value)}>{GRADE_TYPES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></Field>
      </Cols>
      <Cols>
        <Field label="Date"><input className="input" type="date" value={date} onChange={e => setDate(e.target.value)} /></Field>
        <Field label="Devoir associé"><select className="input" value={hw} onChange={e => setHw(e.target.value)}><option value="">— Aucun —</option>{hws.map(h => <option key={h.id} value={h.id}>{h.title}{h.subject ? ' · ' + h.subject : ''}</option>)}</select></Field>
      </Cols>
      <Field label="Description"><input className="input" value={desc} onChange={e => setDesc(e.target.value)} placeholder="Chapitre, contrôle, devoir…" /></Field>
      <Field label="Preuve / sujet rendu"><FileField value={fileId} onChange={setFileId} subject={subject} /></Field>
    </Modal>
  );
}
export async function removeGrade(id: string): Promise<boolean> {
  const all = getData('grades'); const idx = all.findIndex(x => x.id === id); const removed = all[idx]; if (!removed) return false;
  return removeObject({ type: 'result', id }, 'cette note', {
    remove: () => setData('grades', getData('grades').filter(x => x.id !== id)),
    restore: () => { const a = getData('grades').slice(); a.splice(idx, 0, removed); setData('grades', a); }, done: 'Note supprimée' });
}

export function GradesView() {
  useStore();
  const subjects = getData('subjects'), grades = getData('grades');
  const [edit, setEdit] = useState<string | null | undefined>(undefined);
  const [preset, setPreset] = useState('');
  const avg = overallAvg(subjects, grades);
  const rows = subjects.map(s => ({ s, avg: subjAvg(grades, s.name), g: grades.filter(x => x.subject === s.name).sort((a, b) => gradeDateISO(a).localeCompare(gradeDateISO(b))) }));
  const ranked = rows.filter(r => r.avg != null).sort((a, b) => b.avg! - a.avg!);
  const best = ranked[0], worst = ranked.length > 1 ? ranked[ranked.length - 1] : undefined;
  const open = (id: string | null, s = '') => { setPreset(s); setEdit(id); };
  return (
    <div className="anim-in">
      <div className="page-intro">
        <div><h2>Notes & Progression</h2><div className="sub">{avg != null ? `Moyenne générale : ${avg.toFixed(2)}/20` : 'Aucune note pour l’instant'}</div></div>
        <button className="btn sm" onClick={() => open(null)}><IcoPlus size={14} /> Ajouter une note</button>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(160px, 1fr))', gap: 10, marginBottom: 16 }}>
        <div className="stat-card" style={{ padding: '12px 14px' }}><div className="stat-lbl">Moyenne générale</div><div className="row" style={{ alignItems: 'baseline', gap: 6 }}><div className="stat-val" style={{ fontSize: 32 }}>{avg != null ? avg.toFixed(2) : '—'}<small>/20</small></div></div></div>
        <div className="stat-card" style={{ padding: '12px 14px' }}><div className="stat-lbl">Meilleure moyenne</div><div className="row" style={{ alignItems: 'baseline', gap: 6, flexWrap: 'wrap' }}><span className="stat-val" style={{ fontSize: 18 }}>{best ? best.s.name : '—'}</span>{best && <span className="stat-trend up" style={{ margin: 0 }}>{best.avg!.toFixed(2)}/20</span>}</div></div>
        <div className="stat-card" style={{ padding: '12px 14px' }}><div className="stat-lbl">Moyenne la plus basse</div><div className="row" style={{ alignItems: 'baseline', gap: 6, flexWrap: 'wrap' }}><span className="stat-val" style={{ fontSize: 18 }}>{worst ? worst.s.name : '—'}</span>{worst && <span className="stat-trend down" style={{ margin: 0 }}>{worst.avg!.toFixed(2)}/20</span>}</div></div>
      </div>
      {!subjects.length ? <div className="card"><p className="muted">Ajoute d’abord tes matières et coefficients dans Réglages.</p></div> : (
        <div className="card" style={{ overflowX: 'auto' }}>
          <table className="grid-tbl">
            <thead><tr><th>Matière</th><th>Coef</th><th>Notes</th><th>Moyenne</th><th /></tr></thead>
            <tbody>{rows.map(({ s, avg: a, g }) => (
              <tr key={s.name}>
                <td><div className="row" style={{ flexWrap: 'nowrap' }}><SubjectIcon name={s.name} icon={s.icon} size={16} /><b>{s.name}</b></div></td>
                <td className="muted">×{s.coef}</td>
                <td><div className="row" style={{ gap: 5 }}>{g.map(x => { const d = gradeDisplayScore(x); return (
                  <button key={x.id} className="chip chip-btn" style={{ color: col(d.value) }} onClick={() => open(x.id)} title={`${typeLabel(x.type)} · ${fmtD(gradeDateISO(x))}${x.desc ? ' · ' + x.desc : ''}`}>{d.raw}/{d.max}{x.coef !== 1 && <small> ({x.coef})</small>}</button>); })}</div></td>
                <td><div className="row" style={{ flexWrap: 'nowrap', gap: 10 }}><b style={{ fontFamily: 'var(--font-head)', fontSize: 16, color: col(a) }}>{a != null ? a.toFixed(2) : '—'}</b>{a != null && <div className="prog-bar" style={{ flex: 1, minWidth: 60 }}><div className="prog-bar-fill" style={{ width: `${(a / 20) * 100}%`, background: subjColor(s.name) }} /></div>}</div></td>
                <td><button className="btn ghost sm" onClick={() => open(null, s.name)}>+ note</button></td>
              </tr>))}</tbody>
          </table>
        </div>
      )}
      {!grades.length && subjects.length > 0 && <p className="muted" style={{ marginTop: 14 }}><IcoGrades size={14} /> Clique sur « + note » dans une matière pour commencer.</p>}
      {edit !== undefined && <GradeForm id={edit || undefined} presetSubject={preset} onClose={() => setEdit(undefined)} />}
    </div>
  );
}
