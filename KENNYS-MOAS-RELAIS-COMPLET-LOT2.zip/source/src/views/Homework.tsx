import { SubjectIcon } from '../components/SubjectIcon';
import { useMemo, useState } from 'react';
import { IcoHW, IcoPlus } from '../components/Icons';
import { Cols, Confirm, Field, FileField, Modal } from '../components/ui';
import { SELECTABLE_TASK_TYPES, TASK_TYPES, type Homework } from '../lib/model';
import { getData, setData, useStore } from '../lib/store';
import { subjColor } from '../lib/calc';
import { toast } from '../lib/toast';
import { fmtD, isoAddDays, todayISO, uid } from '../lib/util';
import { removeObject, removeObjects } from '../lib/deletion';
import { relatedCount } from '../lib/relations';

const typeLabel = (t: string) => TASK_TYPES.find(x => x[0] === t)?.[1] || t || 'Devoir';
const normType = (t?: string) => (({ leçon: 'autre', lecon: 'autre', exposé: 'autre', expose: 'autre' } as Record<string, string>)[t || ''] || t || 'devoir');
export const isUrgent = (h: Homework) => !h.done && (h.priority === 'haute' || (!!h.due && h.due <= isoAddDays(todayISO(), 1)));
export const isLate = (h: Homework) => !h.done && !!h.due && h.due < todayISO();
export const REMINDERS: [string, string][] = [['', 'Aucun'], ['60', '1 h avant'], ['1440', '1 jour avant'], ['2880', '2 jours avant']];

export function HomeworkForm({ id, onClose, presetSubject }: { id?: string; onClose: () => void; presetSubject?: string }) {
  const subjects = getData('subjects');
  const cur = id ? getData('homework').find(h => h.id === id) : undefined;
  const [f, setF] = useState<Partial<Homework>>(cur || { title: '', subject: presetSubject || '', due: '', priority: 'normale', type: 'devoir', desc: '', reminder: null });
  const set = (k: keyof Homework, v: unknown) => setF(p => ({ ...p, [k]: v }));
  const types = SELECTABLE_TASK_TYPES.includes(normType(f.type)) ? SELECTABLE_TASK_TYPES : [...SELECTABLE_TASK_TYPES, normType(f.type)];
  const save = () => {
    if (!f.title?.trim()) return toast('Titre requis', 'warn');
    const rec = { fileId: null, links: [], done: false, ...(cur || {}), ...f, title: f.title.trim(), type: normType(f.type), id: cur?.id || uid() } as Homework;
    setData('homework', cur ? getData('homework').map(h => (h.id === cur.id ? rec : h)) : [...getData('homework'), rec]);
    if (rec.reminder && 'Notification' in window && Notification.permission === 'default') Notification.requestPermission();
    toast(cur ? 'Devoir modifié' : 'Devoir ajouté'); onClose();
  };
  const del = async () => {
    const all = getData('homework'); const idx = all.findIndex(h => h.id === id); const removed = all[idx]; if (!removed) return;
    const ok = await removeObject({ type: 'homework', id: id as string }, `« ${removed.title} »`, {
      remove: () => setData('homework', getData('homework').filter(h => h.id !== id)),
      restore: () => { const a = getData('homework').slice(); a.splice(idx, 0, removed); setData('homework', a); }, done: 'Devoir supprimé' });
    if (ok) onClose();
  };
  return (
    <Modal title={cur ? 'Modifier le devoir' : 'Ajouter un devoir'} onClose={onClose} footer={<>
      {cur && <button className="btn danger ghost" onClick={del}>Supprimer</button>}
      <span style={{ flex: 1 }} /><button className="btn ghost" onClick={onClose}>Annuler</button><button className="btn" onClick={save}>Enregistrer</button></>}>
      <Field label="Titre"><input className="input" value={f.title || ''} onChange={e => set('title', e.target.value)} placeholder="Exercices p.142" autoFocus /></Field>
      <Cols>
        <Field label="Matière"><select className="input" value={f.subject || ''} onChange={e => set('subject', e.target.value)}><option value="">—</option>{subjects.map(s => <option key={s.name}>{s.name}</option>)}</select></Field>
        <Field label="Catégorie"><select className="input" value={normType(f.type)} onChange={e => set('type', e.target.value)}>{types.map(t => <option key={t} value={t}>{typeLabel(t)}</option>)}</select></Field>
      </Cols>
      <Cols>
        <Field label="Échéance"><input className="input" type="date" value={f.due || ''} onChange={e => set('due', e.target.value)} /></Field>
        <Field label="Priorité"><select className="input" value={f.priority || 'normale'} onChange={e => set('priority', e.target.value)}><option value="basse">Basse</option><option value="normale">Normale</option><option value="haute">Haute</option></select></Field>
      </Cols>
      <Field label="Rappel"><select className="input" value={f.reminder || ''} onChange={e => set('reminder', e.target.value || null)}>{REMINDERS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></Field>
      <Field label="Fichier associé"><FileField value={f.fileId as string | null} onChange={v => set('fileId', v)} subject={f.subject || ''} /></Field>
      <Field label="Description"><textarea className="input" rows={3} value={f.desc || ''} onChange={e => set('desc', e.target.value)} /></Field>
    </Modal>
  );
}

export function HomeworkView() {
  useStore();
  const items = getData('homework');
  const [status, setStatus] = useState<'all' | 'pending' | 'done'>('pending');
  const [cat, setCat] = useState('all');
  const [subj, setSubj] = useState('');
  const [edit, setEdit] = useState<string | null | undefined>(undefined);
  const [confirmDone, setConfirmDone] = useState(false);

  const list = useMemo(() => items
    .filter(h => (status === 'all' ? true : status === 'pending' ? !h.done : h.done))
    .filter(h => cat === 'all' || normType(h.type) === cat)
    .filter(h => !subj || h.subject === subj)
    .sort((a, b) => (a.done === b.done ? (a.due || '9999').localeCompare(b.due || '9999') : a.done ? 1 : -1)), [items, status, cat, subj]);
  const pending = items.filter(h => !h.done).length;
  const toggle = (id: string) => setData('homework', getData('homework').map(h => (h.id === id ? { ...h, done: !h.done } : h)));

  return (
    <div className="anim-in">
      <div className="page-intro">
        <div><h2>Devoirs</h2><div className="sub">{pending} devoir{pending !== 1 ? 's' : ''} en attente{items.some(isLate) ? ` · ${items.filter(isLate).length} en retard` : ''}</div></div>
        <div className="row"><button className="btn sm" onClick={() => setEdit(null)}><IcoPlus size={14} /> Ajouter</button></div>
      </div>
      <div className="tabs">
        {(['pending', 'all', 'done'] as const).map(s => <button key={s} className={`btn sm${status === s ? '' : ' ghost'}`} onClick={() => setStatus(s)}>{s === 'all' ? 'Tous' : s === 'pending' ? 'À faire' : 'Terminés'}</button>)}
        <span style={{ width: 8 }} />
        <select className="input" style={{ width: 'auto' }} value={cat} onChange={e => setCat(e.target.value)} aria-label="Catégorie"><option value="all">Toutes catégories</option>{TASK_TYPES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
        <select className="input" style={{ width: 'auto' }} value={subj} onChange={e => setSubj(e.target.value)} aria-label="Matière"><option value="">Toutes matières</option>{getData('subjects').map(s => <option key={s.name}>{s.name}</option>)}</select>
        {items.some(h => h.done) && <button className="btn ghost sm" onClick={() => setConfirmDone(true)}>Vider les terminés</button>}
      </div>
      {!list.length ? (
        <div className="card" style={{ textAlign: 'center', padding: 32 }}><IcoHW size={32} style={{ color: 'var(--mut)' }} /><p className="muted" style={{ marginTop: 10 }}>{items.length ? 'Aucun devoir ne correspond à ces filtres.' : 'Aucun devoir pour l’instant.'}</p>
          <button className="btn" style={{ marginTop: 12 }} onClick={() => setEdit(null)}><IcoPlus size={14} /> Ajouter un devoir</button></div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {list.map(h => (
            <div key={h.id} className="list-item" style={{ opacity: h.done ? 0.65 : 1, borderLeft: h.subject ? `3px solid ${subjColor(h.subject)}` : undefined }}>
              <button className={`check${h.done ? ' on' : ''}${isUrgent(h) ? ' urgent' : ''}`} onClick={() => toggle(h.id)} aria-label={h.done ? 'Marquer à faire' : 'Marquer fait'}>
                {h.done && <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M20 6 9 17l-5-5" /></svg>}
              </button>
              <div className="body" style={{ cursor: 'pointer' }} onClick={() => setEdit(h.id)}>
                <h4 style={{ textDecoration: h.done ? 'line-through' : 'none' }}>{h.title}</h4>
                <div className="row" style={{ marginTop: 4, gap: 6, fontSize: 12, color: 'var(--mut)' }}>
                  {h.subject && <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}><SubjectIcon name={h.subject} icon={getData('subjects').find(x => x.name === h.subject)?.icon} size={13} />{h.subject}</span>}
                  {h.due && <span className={isLate(h) ? 'badge red' : ''} style={isLate(h) ? undefined : { fontWeight: isUrgent(h) ? 700 : 400, color: isUrgent(h) ? '#c0392b' : undefined }}>{isLate(h) ? 'En retard · ' : '· '}{fmtD(h.due)}</span>}
                  <span className="badge">{typeLabel(normType(h.type))}</span>
                  {isUrgent(h) && !isLate(h) && <span className="badge red">Urgent</span>}
                </div>
                {h.desc && <div className="muted" style={{ marginTop: 4, fontSize: 12.5 }}>{h.desc}</div>}
              </div>
            </div>
          ))}
        </div>
      )}
      {edit !== undefined && <HomeworkForm id={edit || undefined} presetSubject={subj} onClose={() => setEdit(undefined)} />}
      {confirmDone && (() => { const doneRefs = items.filter(h => h.done).map(h => ({ type: 'homework' as const, id: h.id })); const linked = doneRefs.filter(r => relatedCount(r) > 0).length;
        return <Confirm message={`Supprimer tous les devoirs terminés (${doneRefs.length}) ?${linked ? ` ${linked} sont encore reliés à d'autres éléments : les liens seront retirés, ces éléments restent.` : ''}`} danger okLabel="Supprimer" onClose={() => setConfirmDone(false)}
          onOk={() => { const snap = getData('homework'); removeObjects(doneRefs, { remove: () => setData('homework', getData('homework').filter(h => !h.done)), restore: () => setData('homework', snap), done: 'Devoirs terminés supprimés' }); }} />; })()}
    </div>
  );
}
