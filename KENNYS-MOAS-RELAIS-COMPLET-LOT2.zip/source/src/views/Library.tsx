import { useEffect, useMemo, useState } from 'react';
import DropZone from '../components/DropZone';
import { FileViewer } from '../components/FileViewer';
import { AskText, Field, Modal } from '../components/ui';
import { IcoBook, IcoCloudUp, IcoFile, IcoGrid, IcoImage, IcoList, IcoPdf, IcoSearch, IcoStar, IcoEdit, IcoTrash } from '../components/Icons';
import type { LibFile } from '../lib/db';
import { fileCategory, fileCategoryLabel, kindOf, listFiles, openTracked, patchFile, removeFile, importFiles, HW_IMPORT_TYPES, LIB_IMPORT_TYPES } from '../lib/files';
import { getData, setData, useStore } from '../lib/store';
import { subjColor } from '../lib/calc';
import { toast } from '../lib/toast';
import { fmtD, fmtSize, isoOf } from '../lib/util';
import type { ViewId } from '../types';

const Ico = ({ f, size = 22 }: { f: LibFile; size?: number }) => { const k = kindOf(f); return k === 'pdf' ? <IcoPdf size={size} /> : k === 'image' ? <IcoImage size={size} /> : <IcoFile size={size} />; };

function EditFile({ f, onClose }: { f: LibFile; onClose: () => void }) {
  const [name, setName] = useState(f.name); const [subject, setSubject] = useState(f.subject); const [tags, setTags] = useState((f.tags || []).join(', ')); const [category, setCategory] = useState<string>(fileCategory(f) || '');
  return (
    <Modal title="Modifier le fichier" onClose={onClose} footer={<><button className="btn ghost" onClick={onClose}>Annuler</button><button className="btn" onClick={async () => { await patchFile(f.id, { name: name.trim() || f.name, subject, category: (category || null) as LibFile['category'], tags: [...new Set(tags.split(',').map(t => t.trim().toLowerCase()).filter(Boolean))] }); toast('Fichier modifié'); onClose(); }}>Enregistrer</button></>}>
      <Field label="Nom"><input className="input" value={name} onChange={e => setName(e.target.value)} /></Field>
      <Field label="Matière"><select className="input" value={subject} onChange={e => setSubject(e.target.value)}><option value="">— Aucune —</option>{getData('subjects').map(s => <option key={s.name}>{s.name}</option>)}</select></Field>
      <Field label="Catégorie"><select className="input" value={category} onChange={e => setCategory(e.target.value)}><option value="">— Non classé —</option>{LIB_IMPORT_TYPES.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></Field>
      <Field label="Étiquettes" hint="Séparées par des virgules"><input className="input" value={tags} onChange={e => setTags(e.target.value)} /></Field>
    </Modal>
  );
}

export default function Library({ onView }: { onView?: (v: ViewId) => void }) {
  const tick = useStore();
  const subjects = getData('subjects');
  const [files, setFiles] = useState<LibFile[]>([]);
  const [mode, setMode] = useState<'grid' | 'list'>('grid'); const [libView, setLibView] = useState<'subjects' | 'files'>('subjects');
  const [active, setActive] = useState<string | null>(null); const [q, setQ] = useState(''); const [type, setType] = useState('all'); const [favOnly, setFavOnly] = useState(false);
  const [open, setOpen] = useState<LibFile | null>(null); const [edit, setEdit] = useState<LibFile | null>(null); const [newSubj, setNewSubj] = useState(false);
  useEffect(() => { let dead = false; listFiles().then(l => { if (!dead) setFiles(l); }); return () => { dead = true; }; }, [tick]);

  const filtered = useMemo(() => files.filter(f => {
    if (active && f.subject !== active) return false;
    if (favOnly && !f.fav) return false;
    if (type !== 'all' && kindOf(f) !== type) return false;
    const s = q.trim().toLowerCase();
    return !s || f.name.toLowerCase().includes(s) || (f.tags || []).some(t => t.includes(s)) || (f.subject || '').toLowerCase().includes(s);
  }), [files, active, q, type, favOnly]);
  const count = (n: string) => files.filter(f => f.subject === n).length;
  const handleFiles = async (fs: File[]) => { await importFiles(fs, { subject: active || '' }); setLibView('files'); };
  const listView = libView === 'files' || !!active;

  return (
    <div className="anim-in">
      <div className="page-intro">
        <div>
          <h2>{active ? (<><span style={{ color: 'var(--mut)', fontWeight: 400, fontSize: 20, cursor: 'pointer' }} onClick={() => { setActive(null); setLibView('subjects'); }}>Bibliothèque</span>{' › '}{active}</>) : 'Bibliothèque'}</h2>
          <div className="sub">{active ? `${filtered.length} document${filtered.length !== 1 ? 's' : ''} dans ${active}` : `${files.length} document${files.length !== 1 ? 's' : ''} · ${subjects.length} matières`}</div>
        </div>
        <div className="row">
          <button className="btn ghost sm" onClick={() => setLibView(libView === 'subjects' ? 'files' : 'subjects')}><IcoBook size={14} />{libView === 'subjects' ? 'Voir les fichiers' : 'Voir par matière'}</button>
          <button className="btn ghost sm" title="Ouvre les réglages de sauvegarde Drive (sauvegarde tes données, pas les fichiers)" onClick={() => onView?.('settings')}><IcoCloudUp size={14} /> Sauvegarde Drive</button>
        </div>
      </div>
      <div style={{ marginBottom: 24 }}><DropZone onFiles={handleFiles} /></div>

      {!listView && (<>
        <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--mut)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 12 }}>Matières</div>
        <div className="subjects-grid" style={{ marginBottom: 28 }}>
          {subjects.map(s => { const c = subjColor(s.name), n = count(s.name); return (
            <button key={s.name} className="subj-card" style={{ borderTopColor: c, textAlign: 'left', width: '100%' }} onClick={() => { setActive(s.name); setLibView('files'); }}>
              <div className="subj-ico" style={{ background: `${c}18`, color: c }}><IcoBook size={18} /></div>
              <div className="subj-name">{s.name}</div><div className="subj-count">{n} fichier{n !== 1 ? 's' : ''}</div>
            </button>); })}
          <button className="subj-card" style={{ borderTop: '2px dashed var(--bd)', opacity: 0.6, justifyContent: 'center', alignItems: 'center', flexDirection: 'column' }} title="Ajouter une matière" onClick={() => setNewSubj(true)}>
            <span style={{ fontSize: 22 }}>+</span><span style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--mut)' }}>Nouvelle matière</span></button>
        </div>
      </>)}

      {listView && (<>
        <div className="row" style={{ marginBottom: 16, gap: 10 }}>
          <div style={{ position: 'relative', flex: 1, minWidth: 180 }}><IcoSearch size={14} style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--mut)', pointerEvents: 'none' }} />
            <input className="input" type="search" placeholder="Filtrer les fichiers…" value={q} onChange={e => setQ(e.target.value)} style={{ paddingLeft: 32 }} /></div>
          <select className="input" style={{ width: 'auto' }} value={active || ''} onChange={e => setActive(e.target.value || null)} aria-label="Matière"><option value="">Toutes les matières</option>{subjects.map(s => <option key={s.name}>{s.name}</option>)}</select>
          <select className="input" style={{ width: 'auto' }} value={type} onChange={e => setType(e.target.value)} aria-label="Type"><option value="all">Tous les types</option><option value="pdf">PDF</option><option value="image">Images</option><option value="doc">Documents</option></select>
          <button className={`btn sm${favOnly ? '' : ' ghost'}`} onClick={() => setFavOnly(v => !v)} title="Favoris"><IcoStar size={13} /></button>
          <div className="view-toggle"><button className={mode === 'grid' ? 'active' : ''} onClick={() => setMode('grid')} title="Vue grille"><IcoGrid size={14} /></button><button className={mode === 'list' ? 'active' : ''} onClick={() => setMode('list')} title="Vue liste"><IcoList size={14} /></button></div>
        </div>
        {!filtered.length && <div style={{ textAlign: 'center', padding: '40px 24px', color: 'var(--mut)' }}><div style={{ fontFamily: 'var(--font-head)', fontSize: 18, fontWeight: 600, marginBottom: 6 }}>{files.length ? `Aucun résultat${q ? ` pour « ${q} »` : ''}` : 'Aucun fichier'}</div>{!files.length && <div style={{ fontSize: 13.5 }}>Importe des fichiers avec la zone ci-dessus.</div>}</div>}
        {mode === 'grid' ? (
          <div className="files-grid">{filtered.map(f => { const c = subjColor(f.subject || 'x'); return (
            <div key={f.id} className="fcard" style={{ cursor: 'pointer' }} onClick={() => { openTracked(f.id); setOpen(f); }}>
              <div className="fcard-cover" style={{ background: `${c}12`, color: c }}><Ico f={f} size={40} /></div>
              <div className="fcard-body"><div className="fcard-name" style={{ overflow: 'hidden', display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical' }}><>{f.fav && <IcoStar size={12} style={{ color: 'var(--s)', marginRight: 5 }} />}{f.name}</></div>
                <div className="fcard-meta"><span>{fmtSize(f.size)}</span><span>·</span><span>{fmtD(isoOf(new Date(f.date)))}</span></div>
                <div className="row" style={{ gap: 4 }}>{fileCategoryLabel(f) && <span className="fcard-tag">{fileCategoryLabel(f)}</span>}{f.homeworkType && <span className="fcard-tag">{HW_IMPORT_TYPES.find(t => t[0] === f.homeworkType)?.[1] || 'Devoir'}</span>}{f.subject && <span className="fcard-tag">{f.subject}</span>}{(f.tags || []).map(t => <span key={t} className="fcard-tag">{t}</span>)}</div></div>
            </div>); })}</div>
        ) : (
          <div className="files-list">{filtered.map(f => (
            <div key={f.id} className="frow"><div className="frow-ico" style={{ color: subjColor(f.subject || 'x') }}><Ico f={f} /></div>
              <div className="frow-body" style={{ cursor: 'pointer' }} onClick={() => { openTracked(f.id); setOpen(f); }}><div className="frow-name"><>{f.fav && <IcoStar size={12} style={{ color: 'var(--s)', marginRight: 5 }} />}{f.name}</></div><div className="frow-meta">{f.subject || 'Sans matière'} · {fmtSize(f.size)} · {fmtD(isoOf(new Date(f.date)))}</div></div>
              <div className="row" style={{ gap: 4 }}>{(f.tags || []).map(t => <span key={t} className="fcard-tag">{t}</span>)}</div>
              <div className="frow-actions"><button className="icon-btn" title="Favori" style={{ width: 30, height: 30 }} onClick={() => patchFile(f.id, { fav: !f.fav })}><IcoStar size={14} /></button>
                <button className="icon-btn" title="Modifier" style={{ width: 30, height: 30 }} onClick={() => setEdit(f)}><IcoEdit size={13} /></button>
                <button className="icon-btn" title="Supprimer" style={{ width: 30, height: 30 }} onClick={() => removeFile(f.id)}><IcoTrash size={13} /></button></div></div>))}</div>
        )}
        {mode === 'grid' && filtered.length > 0 && <p className="muted" style={{ marginTop: 12 }}>Astuce : passe en vue liste pour ajouter aux favoris, modifier ou supprimer un fichier.</p>}
      </>)}
      {open && <FileViewer key={open.id} file={open} onClose={() => setOpen(null)} />}
      {edit && <EditFile f={edit} onClose={() => setEdit(null)} />}
      {newSubj && <AskText title="Nouvelle matière" label="Nom de la matière" onClose={() => setNewSubj(false)} onOk={n => { if (!n) return; if (subjects.some(s => s.name.toLowerCase() === n.toLowerCase())) return toast('Cette matière existe déjà', 'warn'); setData('subjects', [...subjects, { name: n, coef: 1 }]); toast('Matière ajoutée'); }} />}
    </div>
  );
}
