import { IcoTimer } from '../components/Icons';
import { getData, useStore } from '../lib/store';
import { mmss, pause, pendingTag, setDuration, setTag, start, stop, useTimer } from '../lib/timer';
import { subjColor } from '../lib/calc';
import { METHODS } from './StubViews';
import { SpeechTrainer } from './SpeechTrainer';

const DURS: [number, string][] = [[900, '15 min'], [1500, '25 min'], [2700, '45 min'], [3600, '1 heure'], [5400, '1 h 30']];

export function ReviewsView() {
  useStore();
  const t = useTimer(); const subjects = getData('subjects'); const sessions = getData('sessions');
  const since = Date.now() - 7 * 864e5;
  const by: Record<string, number> = {}; sessions.filter(s => s.date >= since).forEach(s => { const k = s.subject || 'Non tagué'; by[k] = (by[k] || 0) + s.min; });
  const week = Object.entries(by).sort((a, b) => b[1] - a[1]); const total = week.reduce((a, [, m]) => a + m, 0);
  return (
    <div className="anim-in">
      <div className="page-intro"><div><h2>Révisions</h2><div className="sub">Lance une séance, entraîne-toi à parler en public, suis ton historique.</div></div></div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 20 }}>
        <div className="card" style={{ textAlign: 'center' }}>
          <div className="timer-big" style={{ color: t.running ? 'var(--p)' : 'var(--txt)' }}>{mmss(t.rem)}</div>
          <div className="row" style={{ justifyContent: 'center', margin: '14px 0' }}>{DURS.map(([s, l]) => <button key={s} className={`btn sm${t.dur === s ? '' : ' ghost'}`} onClick={() => setDuration(s)}>{l}</button>)}</div>
          <div style={{ maxWidth: 260, margin: '0 auto 14px' }}><select className="input" value={pendingTag()?.subject || ''} onChange={e => setTag(e.target.value)} aria-label="Matière de la session"><option value="">Matière (optionnel)</option>{subjects.map(s => <option key={s.name}>{s.name}</option>)}</select></div>
          <div className="row" style={{ justifyContent: 'center' }}>
            <button className="btn" onClick={() => (t.running || t.rem < t.dur ? pause() : start())}>{t.running ? 'Pause' : t.rem < t.dur && t.rem > 0 ? 'Reprendre' : 'Démarrer'}</button>
            <button className="btn ghost" onClick={stop}>Arrêter</button></div>
          <p className="muted" style={{ marginTop: 12, fontSize: 12 }}>Le chrono survit au changement de page et au rechargement.</p>
        </div>
        <div className="card">
          <h3 style={{ marginBottom: 12 }}>Cette semaine</h3>
          {!week.length ? <p className="muted">Aucune session enregistrée sur les 7 derniers jours.</p> : (<>
            <p className="muted" style={{ marginBottom: 10 }}>{total} min au total</p>
            {week.map(([s, m]) => <div key={s} style={{ marginBottom: 10 }}><div className="row spread" style={{ fontSize: 13 }}><b>{s}</b><span className="muted">{m} min</span></div><div className="bar-h"><i style={{ width: `${(m / total) * 100}%`, background: subjColor(s) }} /></div></div>)}</>)}
        </div>
        <SpeechTrainer />
        <div className="card">
          <h3 style={{ marginBottom: 14 }}><IcoTimer size={16} style={{ verticalAlign: '-3px' }} /> Méthodes de révision</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>{METHODS.map(m => (
            <div key={m.name} className="list-item"><div className="body"><div style={{ fontWeight: 700, fontSize: 13.5, color: m.color }}>{m.name}</div><div className="muted" style={{ marginTop: 2 }}>{m.desc}</div></div></div>))}</div>
        </div>
      </div>
    </div>
  );
}
