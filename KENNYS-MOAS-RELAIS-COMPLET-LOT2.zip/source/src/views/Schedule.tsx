import { useMemo, useState } from 'react';
import { IcoCal, IcoChevronLeft, IcoChevronRight, IcoPlus, IcoTrash } from '../components/Icons';
import { AskText, Cols, Confirm, Field, FileField, Modal } from '../components/ui';
import { DAYS, EVCOLORS, EVENT_TYPES, HOURS, type CalEvent } from '../lib/model';
import { getData, getClass, setData, useStore } from '../lib/store';
import { hourMin, normHour, subjColor } from '../lib/calc';
import { exportICS } from '../lib/ics';
import { toast } from '../lib/toast';
import { fmtD, isoAddDays, isoOf, pad, todayISO, uid } from '../lib/util';
import { removeObject } from '../lib/deletion';
import { ClassTimetableView } from './ClassTimetable';

const RM: [string, string][] = [['', 'Aucun'], ['5', '5 min avant'], ['15', '15 min avant'], ['30', '30 min avant'], ['60', '1 h avant'], ['1440', '1 jour avant']];

export function EventForm({ id, date, onClose }: { id?: string; date?: string; onClose: () => void }) {
  const cur = id ? getData('events').find(e => e.id === id) : undefined;
  const subjects = getData('subjects');
  const [f, setF] = useState({ title: cur?.title || '', type: cur?.type || 'devoir', subject: cur?.subject || '', date: cur?.date || date || todayISO(), time: cur?.time || '', end: '', desc: cur?.desc || '', reminder: cur?.reminder || '' });
  const [fileId, setFileId] = useState<string | null>(cur?.fileId ?? null);
  const set = (k: keyof typeof f, v: string) => setF(p => ({ ...p, [k]: v }));
  const save = () => {
    if (!f.title.trim()) return toast('Titre requis', 'warn');
    if (f.end && f.end < f.date) return toast('La date de fin doit être après la date de début', 'warn');
    const base = { title: f.title.trim(), type: f.type, subject: f.subject, time: f.time, desc: f.desc, fileId, reminder: f.reminder || null, links: cur?.links || [] };
    let recs: CalEvent[];
    if (f.end && f.end > f.date) { /* période de plusieurs jours : une entrée par jour (compatible export .ics) */
      const dates: string[] = []; let d = f.date, guard = 0;
      while (d <= f.end && guard < 370) { dates.push(d); d = isoAddDays(d, 1); guard++; }
      if (d <= f.end) return toast('Période trop longue (max ~1 an)', 'warn');
      recs = dates.map(dt => ({ id: uid(), ...base, date: dt }));
      setData('events', [...getData('events').filter(e => e.id !== id), ...recs]);
    } else {
      const rec: CalEvent = { id: id || uid(), ...base, date: f.date };
      setData('events', id ? getData('events').map(e => (e.id === id ? rec : e)) : [...getData('events'), rec]);
    }
    if (base.reminder && 'Notification' in window && Notification.permission === 'default') Notification.requestPermission();
    toast(id ? 'Événement modifié' : 'Événement créé'); onClose();
  };
  const del = async () => {
    const before = getData('events'); const idx = before.findIndex(e => e.id === id); const removed = before[idx]; if (!removed) return;
    const ok = await removeObject({ type: 'event', id: id as string }, `« ${removed.title} »`, {
      remove: () => setData('events', getData('events').filter(e => e.id !== id)),
      restore: () => { const a = getData('events').slice(); a.splice(idx, 0, removed); setData('events', a); }, done: 'Événement supprimé' });
    if (ok) onClose();
  };
  return (
    <Modal title={id ? 'Modifier l’événement' : 'Nouvel événement'} onClose={onClose} footer={<>
      {id && <button className="btn danger ghost" onClick={del}>Supprimer</button>}<span style={{ flex: 1 }} /><button className="btn ghost" onClick={onClose}>Annuler</button><button className="btn" onClick={save}>Enregistrer</button></>}>
      <Field label="Titre"><input className="input" value={f.title} onChange={e => set('title', e.target.value)} autoFocus /></Field>
      <Cols><Field label="Type"><select className="input" value={f.type} onChange={e => set('type', e.target.value)}>{EVENT_TYPES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></Field>
        <Field label="Matière"><select className="input" value={f.subject} onChange={e => set('subject', e.target.value)}><option value="">—</option>{subjects.map(s => <option key={s.name}>{s.name}</option>)}</select></Field></Cols>
      <Cols><Field label="Date"><input className="input" type="date" value={f.date} onChange={e => set('date', e.target.value)} /></Field>
        <Field label="Heure"><input className="input" type="time" value={f.time} onChange={e => set('time', e.target.value)} /></Field></Cols>
      {!id && <Field label="Date de fin (optionnel — période de plusieurs jours, ex. congés)"><input className="input" type="date" value={f.end} onChange={e => set('end', e.target.value)} /></Field>}
      <Field label="Description"><textarea className="input" rows={2} value={f.desc} onChange={e => set('desc', e.target.value)} /></Field>
      <Field label="Rappel"><select className="input" value={f.reminder} onChange={e => set('reminder', e.target.value)}>{RM.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></Field>
      <Field label="Fichier associé"><FileField value={fileId} onChange={setFileId} subject={f.subject} /></Field>
    </Modal>
  );
}

function Timetable() {
  const sc = getData('schedule'), extra = getData('extraHours'), hiddenH = getData('hiddenHours'), hiddenD = getData('hiddenDays'), subjects = getData('subjects');
  // Toute heure de base (HOURS) masquée par l'utilisateur est retirée ; dédoublonnée par VALEUR (08h ≠ 8h mais représentent
  // la même heure) pour qu'un créneau ajouté à l'identique d'un existant ne crée jamais une ligne « en double / superposée ».
  const hrs = useMemo(() => {
    const base = HOURS.filter(h => !hiddenH.includes(h));
    const seen = new Map<number, string>();
    for (const h of [...base, ...extra]) { const m = hourMin(h); if (!seen.has(m)) seen.set(m, h); }
    return [...seen.values()].sort((a, b) => hourMin(a) - hourMin(b));
  }, [extra, hiddenH]);
  const days = useMemo(() => DAYS.filter(d => !hiddenD.includes(d)), [hiddenD]);
  // Grille recentrée sur les heures effectivement utilisées : les lignes vides en début/fin ne s'affichent
  // pas par défaut (elles restent accessibles via « Afficher toutes les heures »), sans jamais toucher aux
  // données (hrs / hiddenHours / extraHours / schedule restent inchangés).
  const [showAllHours, setShowAllHours] = useState(false);
  const collapsedHrs = useMemo(() => {
    const used = hrs.map((h, i) => (days.some(d => sc[d + h]) ? i : -1)).filter(i => i >= 0);
    if (used.length === 0) return hrs;
    const lo = Math.max(0, used[0] - 1), hi = Math.min(hrs.length - 1, used[used.length - 1] + 1);
    return hrs.slice(lo, hi + 1);
  }, [hrs, sc, days]);
  const hiddenCount = hrs.length - collapsedHrs.length;
  const visibleHrs = showAllHours ? hrs : collapsedHrs;
  const [cell, setCell] = useState<string | null>(null); const [addH, setAddH] = useState(false);
  const [rmH, setRmH] = useState<string | null>(null); const [rmD, setRmD] = useState<string | null>(null);
  const [subj, setSubj] = useState(''); const [room, setRoom] = useState('');
  const usedSubjects = useMemo(() => [...new Set(Object.values(sc).map(c => c.subject))].sort(), [sc]);
  const openCell = (k: string) => { setSubj(sc[k]?.subject || ''); setRoom(sc[k]?.room || ''); setCell(k); };
  // Supprimer une heure = la masquer si elle vient du socle par défaut (réversible depuis les puces « Créneaux masqués »),
  // ou la retirer de la liste si elle a été ajoutée à la main (comportement inchangé pour ces créneaux-là).
  const doRmHour = (h: string) => {
    if (HOURS.includes(h)) setData('hiddenHours', [...hiddenH, h]); else setData('extraHours', extra.filter(x => x !== h));
    const s2 = { ...sc }; DAYS.forEach(d => delete s2[d + h]); setData('schedule', s2); toast('Créneau supprimé', 'ok', { label: 'Annuler', cb: () => { setData('schedule', sc); if (HOURS.includes(h)) setData('hiddenHours', hiddenH); else setData('extraHours', extra); } });
  };
  const doRmDay = (d: string) => {
    setData('hiddenDays', [...hiddenD, d]); const s2 = { ...sc }; hrs.forEach(h => delete s2[d + h]); setData('schedule', s2);
    toast(`${d} masqué`, 'ok', { label: 'Annuler', cb: () => { setData('schedule', sc); setData('hiddenDays', hiddenD); } });
  };
  const addHour = (raw: string) => {
    const h = normHour(raw); if (!h) return toast('Format attendu : 08h ou 08h30', 'warn');
    if (hiddenH.includes(h)) { setData('hiddenHours', hiddenH.filter(x => x !== h)); return toast('Créneau rétabli'); }
    if (hrs.some(x => hourMin(x) === hourMin(h))) return toast('Ce créneau existe déjà', 'warn');
    setData('extraHours', [...extra, h]); toast('Créneau ajouté');
  };
  return (
    <div className="card" style={{ overflowX: 'auto' }}>
      <div className="row spread" style={{ marginBottom: 10, flexWrap: 'wrap', gap: 8 }}>
        <h3 style={{ margin: 0 }}>Emploi du temps</h3>
        <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
          {hiddenD.length > 0 && <div className="row" style={{ gap: 4 }}>{hiddenD.map(d => <button key={d} className="chip chip-btn" title={`Réafficher ${d}`} onClick={() => setData('hiddenDays', hiddenD.filter(x => x !== d))}><IcoPlus size={11} /> {d}</button>)}</div>}
          {hiddenH.length > 0 && <div className="row" style={{ gap: 4 }}>{hiddenH.map(h => <button key={h} className="chip chip-btn" title={`Réafficher ${h}`} onClick={() => setData('hiddenHours', hiddenH.filter(x => x !== h))}><IcoPlus size={11} /> {h}</button>)}</div>}
          <button className="btn ghost sm" onClick={() => setAddH(true)}><IcoPlus size={13} /> Créneau</button>
        </div>
      </div>
      <table className="edt"><thead><tr><th />{days.map(d => (
        <th key={d}><span className="row" style={{ justifyContent: 'center', gap: 3 }}>{d}
          {days.length > 1 && <button className="mini edt-x" title={`Masquer ${d}`} onClick={() => (hrs.some(h => sc[d + h]) ? setRmD(d) : doRmDay(d))}><IcoTrash size={11} /></button>}
        </span></th>
      ))}</tr></thead>
        <tbody>{visibleHrs.map(h => (
          <tr key={h}><th><span className="row" style={{ gap: 3, justifyContent: 'flex-end' }}>{h}
            <button className="mini edt-x" title="Supprimer ce créneau" onClick={() => (days.some(d => sc[d + h]) ? setRmH(h) : doRmHour(h))}><IcoTrash size={11} /></button>
          </span></th>
            {days.map(d => { const x = sc[d + h]; const color = x ? subjColor(x.subject) : ''; return (
              <td key={d} className={x ? 'filled' : ''} onClick={() => openCell(d + h)} title={x ? x.subject + (x.room ? ' · ' + x.room : '') : ''} style={x ? { background: `${color}26`, borderColor: `${color}80`, borderLeft: `3px solid ${color}`, color } : undefined}>
                {x && <><div style={{ fontSize: 12 }}>{x.subject}</div>{x.room && <div style={{ fontSize: 10.5, color: 'var(--mut)', fontWeight: 400 }}>{x.room}</div>}</>}</td>); })}</tr>))}</tbody></table>
      {hiddenCount > 0 && !showAllHours && (
        <button className="btn ghost sm" style={{ marginTop: 8 }} onClick={() => setShowAllHours(true)}>
          + {hiddenCount} heure{hiddenCount > 1 ? 's' : ''} masquée{hiddenCount > 1 ? 's' : ''}
        </button>
      )}
      {showAllHours && hiddenCount > 0 && (
        <button className="btn ghost sm" style={{ marginTop: 8 }} onClick={() => setShowAllHours(false)}>Réduire la grille</button>
      )}
      {usedSubjects.length > 0 && <div className="row" style={{ gap: 10, flexWrap: 'wrap', marginTop: 12, paddingTop: 10, borderTop: '1px solid var(--bd)' }}>
        {usedSubjects.map(name => <span key={name} className="row" style={{ gap: 5, fontSize: 11.5, color: 'var(--mut)' }}><span style={{ width: 9, height: 9, borderRadius: 3, background: subjColor(name), flex: '0 0 auto' }} />{name}</span>)}
      </div>}
      {cell && <Modal title={'Cours — ' + cell} onClose={() => setCell(null)} footer={<><button className="btn ghost" onClick={() => setCell(null)}>Annuler</button><button className="btn" onClick={() => { const s2 = { ...sc }; if (subj) s2[cell] = { subject: subj, room }; else delete s2[cell]; setData('schedule', s2); setCell(null); toast('Emploi du temps mis à jour'); }}>Enregistrer</button></>}>
        <Field label="Matière"><select className="input" value={subj} onChange={e => setSubj(e.target.value)}><option value="">— Libre —</option>{subjects.map(s => <option key={s.name}>{s.name}</option>)}</select></Field>
        <Field label="Salle"><input className="input" value={room} onChange={e => setRoom(e.target.value)} /></Field></Modal>}
      {addH && <AskText title="Nouveau créneau" label="Format attendu : 08h ou 08h30" onClose={() => setAddH(false)} onOk={addHour} />}
      {rmH && <Confirm message={`Le créneau ${rmH} contient des cours. Les supprimer aussi ?`} danger okLabel="Supprimer" onOk={() => doRmHour(rmH)} onClose={() => setRmH(null)} />}
      {rmD && <Confirm message={`${rmD} contient des cours. Les supprimer aussi ?`} danger okLabel="Masquer" onOk={() => doRmDay(rmD)} onClose={() => setRmD(null)} />}
    </div>
  );
}

function Calendar() {
  const events = getData('events'), hw = getData('homework');
  const now = new Date(); const [y, setY] = useState(now.getFullYear()); const [m, setM] = useState(now.getMonth());
  const [edit, setEdit] = useState<{ id?: string; date?: string } | null>(null); const [day, setDay] = useState<string | null>(null);
  const first = new Date(y, m, 1); const lead = (first.getDay() + 6) % 7; const start = new Date(y, m, 1 - lead);
  const cells = Array.from({ length: 42 }, (_, i) => { const d = new Date(start); d.setDate(start.getDate() + i); return d; });
  type Item = { key: string; label: string; color: string; ev?: string };
  const byDay = (iso: string): Item[] => [
    ...events.filter(e => e.date === iso).map(e => ({ key: e.id, label: (e.time ? e.time + ' ' : '') + e.title, color: EVCOLORS[e.type] || '#64748b', ev: e.id })),
    ...hw.filter(h => h.due === iso && !h.done).map(h => ({ key: 'h' + h.id, label: '↗ ' + h.title, color: EVCOLORS.devoir })),
  ];
  const shift = (n: number) => { const d = new Date(y, m + n, 1); setY(d.getFullYear()); setM(d.getMonth()); };
  const dayItems = day ? byDay(day) : [];
  return (
    <div className="card">
      <div className="row spread" style={{ marginBottom: 12 }}>
        <div className="row"><button className="icon-btn" onClick={() => shift(-1)} aria-label="Mois précédent"><IcoChevronLeft size={16} /></button>
          <h3 style={{ margin: 0, minWidth: 150, textAlign: 'center', textTransform: 'capitalize' }}>{first.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })}</h3>
          <button className="icon-btn" onClick={() => shift(1)} aria-label="Mois suivant"><IcoChevronRight size={16} /></button></div>
        <div className="row"><button className="btn ghost sm" onClick={() => { setY(now.getFullYear()); setM(now.getMonth()); }}>Aujourd’hui</button>
          <button className="btn ghost sm" onClick={() => { exportICS(events, hw, getClass()); toast('Calendrier exporté (.ics)'); }}>Exporter (.ics)</button>
          <button className="btn sm" onClick={() => setEdit({})}><IcoPlus size={13} /> Événement</button></div>
      </div>
      <div className="cal-grid">
        {['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'].map(d => <div key={d} className="cal-dow">{d}</div>)}
        {cells.map(d => { const iso = isoOf(d); const items = byDay(iso); return (
          <button key={iso} className={`cal-cell${d.getMonth() !== m ? ' out' : ''}${iso === todayISO() ? ' today' : ''}`} onClick={() => setDay(iso)}>
            <span className="cal-num">{d.getDate()}</span>
            {items.slice(0, 3).map(it => <span key={it.key} className="cal-ev" style={{ background: it.color }}>{it.label}</span>)}
            {items.length > 3 && <span className="muted" style={{ fontSize: 10 }}>+{items.length - 3}</span>}
          </button>); })}
      </div>
      {day && !edit && <Modal title={fmtD(day)} onClose={() => setDay(null)} footer={<><button className="btn ghost" onClick={() => setDay(null)}>Fermer</button><button className="btn" onClick={() => setEdit({ date: day })}><IcoPlus size={13} /> Ajouter</button></>}>
        {!dayItems.length ? <p className="muted">Rien de prévu ce jour-là.</p> : dayItems.map(it => (
          <div key={it.key} className="list-item" style={{ cursor: it.ev ? 'pointer' : 'default', borderLeft: `3px solid ${it.color}` }} onClick={() => it.ev && setEdit({ id: it.ev })}><div className="body"><h4>{it.label}</h4></div></div>))}</Modal>}
      {edit && <EventForm id={edit.id} date={edit.date} onClose={() => { setEdit(null); setDay(null); }} />}
    </div>
  );
}

export function ScheduleView() {
  useStore();
  const [tab, setTab] = useState<'week' | 'month' | 'edt'>('month');
  return (
    <div className="anim-in">
      <div className="page-intro"><div><h2>Emploi du temps</h2><div className="sub">Grille hebdomadaire et calendrier des événements, contrôles et échéances.</div></div>
        <div className="seg"><button className={tab === 'month' ? 'active' : ''} onClick={() => setTab('month')}><IcoCal size={13} /> Calendrier</button><button className={tab === 'edt' ? 'active' : ''} onClick={() => setTab('edt')}>Emploi du temps</button><button className={tab === 'week' ? 'active' : ''} onClick={() => setTab('week')}>Semaine type (ancien)</button></div></div>
      {tab === 'week' ? <Timetable /> : tab === 'edt' ? <ClassTimetableView /> : <Calendar />}
    </div>
  );
}
