import { useEffect, useRef, useState } from 'react';
import { IcoPlus, IcoDownload, IcoEdit, IcoTrash } from '../components/Icons';
import { AskText, Confirm, Field } from '../components/ui';
import { SubjectIcon, SUBJECT_ICONS, SUGGESTED_SUBJECTS, guessIcon } from '../components/SubjectIcon';
import { CLASSES } from '../lib/model';
import { allClassNames, getClass, getCustomClasses, getData, getSettings, saveSettings, setClass, setCustomClasses, setData, useStore } from '../lib/store';
import { PALETTE, subjColor } from '../lib/calc';
import { mergeSubject } from '../lib/subjects';
import { chooseOption } from '../lib/choose';
import { autoBackup, exportFull, exportLight, importJSON, listAutoBackups, resetAll, restoreAutoBackup } from '../lib/backup';
import { exportICS } from '../lib/ics';
import { connectDrive, disconnectDrive, driveConfigured, driveFolderLink, pullFromDrive, pushToDrive, remoteInfo, useDriveStatus, type RemoteInfo } from '../lib/drive';
import { dbAll, type LibFile } from '../lib/db';
import { download, slug, todayISO } from '../lib/util';
import { toast } from '../lib/toast';
import type { Theme } from '../types';

const SWATCHES: [string, string][] = [
  ['#5f6f5b', 'Sauge'], ['#5e789f', 'Bleu ardoise'], ['#b86a49', 'Terracotta'], ['#75637f', 'Prune'],
  ['#9b793b', 'Ocre'], ['#8b5d68', 'Rose terre'], ['#4f7774', 'Eucalyptus'], ['#7a6b5a', 'Noisette'],
];
const SECONDARY_SWATCHES: [string, string][] = [
  ['#b86a49', 'Terracotta'], ['#9b793b', 'Ocre'], ['#5e789f', 'Bleu'], ['#75637f', 'Prune'], ['#4f7774', 'Eucalyptus'],
];
const FONTS: [string, string][] = [
  ['inter', 'Inter — net et contemporain'], ['manrope', 'Manrope — doux et précis'], ['dm-sans', 'DM Sans — simple et lisible'],
  ['nunito', 'Nunito Sans — plus chaleureux'], ['ibm-plex', 'IBM Plex Sans — plus technique'], ['mono', 'IBM Plex Mono — machine à écrire'],
];
const HEADING_FONTS: [string, string][] = [
  ['fraunces', 'Fraunces — éditorial'], ['source-serif', 'Source Serif 4 — classique'], ['lora', 'Lora — carnet'], ['inter', 'Inter — sobre'], ['space-grotesk', 'Space Grotesk — moderne'],
];
const SURFACES: [string, string][] = [['paper', 'Papier'], ['linen', 'Lin clair'], ['white', 'Blanc cassé'], ['glass', 'Verre (translucide)']];
const RADII: [string, string][] = [['soft', 'Doux'], ['round', 'Arrondi'], ['sharp', 'Structuré']];
const LAYOUTS: [string, string][] = [['normal', 'Équilibré'], ['wide', 'Large'], ['compact', 'Étroit']];
const TEXT_SIZES: [string, string][] = [['normal', 'Normal'], ['large', 'Grand'], ['xlarge', 'Très grand']];
const lbl: React.CSSProperties = { fontSize: 12, fontWeight: 700, color: 'var(--mut)', textTransform: 'uppercase', letterSpacing: '.06em', marginBottom: 8 };

export function applyAppearance() {
  const s = getSettings(), r = document.documentElement.style;
  r.setProperty('--p', s.primaryCustom === false ? '#5f6f5b' : (s.primary || '#5f6f5b'));
  r.setProperty('--s', s.secondaryCustom === false ? '#b86a49' : (s.secondary || '#b86a49'));
  const bodyFonts: Record<string, string> = {
    inter: "'Inter', -apple-system, system-ui, sans-serif", manrope: "'Manrope', -apple-system, system-ui, sans-serif",
    'dm-sans': "'DM Sans', -apple-system, system-ui, sans-serif", nunito: "'Nunito Sans', -apple-system, system-ui, sans-serif",
    'ibm-plex': "'IBM Plex Sans', -apple-system, system-ui, sans-serif", mono: "'IBM Plex Mono', ui-monospace, monospace",
    system: "'Inter', -apple-system, system-ui, sans-serif", serif: "'Lora', ui-serif, Georgia, serif",
  };
  const headingFonts: Record<string, string> = {
    fraunces: "'Fraunces', Georgia, serif", 'source-serif': "'Source Serif 4', Georgia, serif", lora: "'Lora', Georgia, serif",
    inter: "'Inter', -apple-system, system-ui, sans-serif", 'space-grotesk': "'Space Grotesk', -apple-system, system-ui, sans-serif",
  };
  r.setProperty('--font-main', bodyFonts[s.font] || bodyFonts.inter);
  r.setProperty('--font-head', headingFonts[s.headingFont || 'fraunces'] || headingFonts.fraunces);
  document.documentElement.setAttribute('data-surface', s.surface || 'paper');
  const glass = s.surface === 'glass';
  const radiusMap: Record<string, [string, string]> = glass
    ? { soft: ['22px', '14px'], round: ['28px', '17px'], sharp: ['12px', '8px'] }   // le verre appelle des arrondis plus généreux
    : { soft: ['15px', '10px'], round: ['20px', '13px'], sharp: ['9px', '6px'] };
  const [radius, small] = radiusMap[s.radius || 'soft'] || radiusMap.soft;
  r.setProperty('--r', radius); r.setProperty('--r-sm', small);
  (r as any).zoom = ({ large: '1.1', xlarge: '1.22' } as Record<string, string>)[s.textSize || 'normal'] || '1'; // taille de l'affichage
  document.documentElement.setAttribute('data-density', s.density);
  document.documentElement.setAttribute('data-layout', s.layout || 'normal');
}

export function SettingsView({ theme, onTheme }: { theme: Theme; onTheme: (t: Theme) => void }) {
  const tick = useStore();
  const subjects = getData('subjects'); const set = getSettings(); const cls = getClass();
  const [ask, setAsk] = useState<null | { kind: 'add' } | { kind: 'ren'; i: number } | { kind: 'cls' }>(null);
  const [confirm, setConfirm] = useState<null | { kind: 'del'; i: number } | { kind: 'reset' } | { kind: 'restore'; id: number } | { kind: 'drive' }>(null);
  const drive = useDriveStatus(); const [dInfo, setDInfo] = useState<RemoteInfo | undefined>(undefined);
  const fmtD = (iso?: string) => iso ? new Date(iso).toLocaleString('fr-FR', { dateStyle: 'medium', timeStyle: 'short' }) : '—';
  const [bks, setBks] = useState<{ id: number }[]>([]); const inp = useRef<HTMLInputElement>(null); const [nFiles, setNFiles] = useState(0);
  useEffect(() => { listAutoBackups().then(setBks); dbAll<LibFile>('files').then(f => setNFiles(f.length)); }, [tick]);

  const renameSubject = (i: number, n: string) => {
    const old = subjects[i]?.name; if (!n || !old || n === old) return;
    if (subjects.some((x, j) => j !== i && x.name.toLowerCase() === n.toLowerCase())) return toast('Cette matière existe déjà', 'warn');
    setData('subjects', subjects.map((x, j) => (j === i ? { ...x, name: n } : x)));
    setData('grades', getData('grades').map(x => (x.subject === old ? { ...x, subject: n } : x)));
    setData('homework', getData('homework').map(x => (x.subject === old ? { ...x, subject: n } : x)));
    setData('errors', getData('errors').map(x => (x.subject === old ? { ...x, subject: n } : x)));
    setData('events', getData('events').map(x => (x.subject === old ? { ...x, subject: n } : x)));
    setData('schedule', Object.fromEntries(Object.entries(getData('schedule')).map(([k, v]) => [k, v && v.subject === old ? { ...v, subject: n } : v])));
    dbAll<LibFile>('files').then(async fs => { const { dbPut } = await import('../lib/db'); for (const f of fs) if (f.subject === old && f.classId === getClass()) await dbPut('files', { ...f, subject: n }); });
    toast('Matière renommée');
  };
  const moveSubject = (i: number, d: number) => { const j = i + d; if (j < 0 || j >= subjects.length) return; const a = [...subjects]; [a[i], a[j]] = [a[j], a[i]]; setData('subjects', a); };
  const setSubjectColor = (i: number, color: string | undefined) => setData('subjects', subjects.map((x, j) => { if (j !== i) return x; const { color: _old, ...rest } = x; return color ? { ...rest, color } : rest; }));
  const setSubjectIcon = (i: number, icon: string | undefined) => setData('subjects', subjects.map((x, j) => { if (j !== i) return x; const { icon: _old, ...rest } = x; return icon ? { ...rest, icon } : rest; }));
  const addSuggested = (n: string) => { if (subjects.some(x => x.name.toLowerCase() === n.toLowerCase())) return; setData('subjects', [...subjects, { name: n, coef: 1 }]); toast(`« ${n} » ajoutée`); };
  const mergeInto = async (i: number) => {
    const from = subjects[i]?.name; if (!from) return;
    const others = subjects.filter((_, j) => j !== i); if (!others.length) return toast('Il faut une autre matière pour regrouper', 'warn');
    const to = await chooseOption(`Regrouper « ${from} » dans…`, others.map(o => ({ key: o.name, label: o.name, desc: 'Notes, devoirs, remarques, fichiers et cours passent ici. « ' + from + ' » sera supprimée.' })));
    if (!to) return;
    const undo = await mergeSubject(from, to);
    toast(`« ${from} » regroupée dans « ${to} »`, 'ok', { label: 'Annuler', cb: () => { void undo(); } });
  };
  const exportSubject = (name: string) => {
    const pick = <T extends { subject: string }>(a: T[]) => a.filter(x => x.subject === name);
    const data = { version: 1, subject: name, class: cls, exportedAt: new Date().toISOString(), coef: subjects.find(s => s.name === name)?.coef, grades: pick(getData('grades')), homework: pick(getData('homework')), errors: pick(getData('errors')), events: pick(getData('events')) };
    download(`kennys-moas-${slug(name)}-${todayISO()}.json`, new Blob([JSON.stringify(data)], { type: 'application/json' })); toast(`Matière « ${name} » exportée`);
  };
  const update = (p: Partial<typeof set>) => { saveSettings({ ...set, ...p }); applyAppearance(); };

  return (
    <div className="anim-in">
      <div className="page-intro"><div><h2>Réglages</h2><div className="sub">Personnalise ton expérience KENNY'S MOAS</div></div></div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 20, alignItems: 'start' }}>
        <div className="card">
          <h3 style={{ margin: '0 0 12px' }}>Classe</h3>
          <Field label="Classe active"><select className="input" value={cls} onChange={e => setClass(e.target.value)}>
            {Object.entries(CLASSES).map(([g, l]) => <optgroup key={g} label={g}>{l.map(c => <option key={c}>{c}</option>)}</optgroup>)}
            {getCustomClasses().length > 0 && <optgroup label="Personnalisées">{getCustomClasses().map(c => <option key={c}>{c}</option>)}</optgroup>}</select></Field>
          <button className="btn ghost sm" style={{ marginTop: 10 }} onClick={() => setAsk({ kind: 'cls' })}><IcoPlus size={13} /> Classe personnalisée</button>
          <p className="muted" style={{ marginTop: 8, fontSize: 12 }}>Chaque classe a ses propres matières, notes, devoirs et emploi du temps.</p>
        </div>

        <div className="card">
          <div className="row spread" style={{ marginBottom: 12 }}><h3 style={{ margin: 0 }}>Matières & coefficients</h3><button className="btn sm" onClick={() => setAsk({ kind: 'add' })}><IcoPlus size={13} /> Ajouter</button></div>
          {!subjects.length && <p className="muted">Aucune matière.</p>}
          {SUGGESTED_SUBJECTS.some(n => !subjects.some(x => x.name.toLowerCase() === n.toLowerCase())) && (
            <div style={{ marginBottom: 10 }}>
              <div className="muted" style={{ fontSize: 12, marginBottom: 6 }}>Matières courantes — touche pour ajouter :</div>
              <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
                {SUGGESTED_SUBJECTS.filter(n => !subjects.some(x => x.name.toLowerCase() === n.toLowerCase())).map(n => (
                  <button key={n} className="chip-btn chip" onClick={() => addSuggested(n)} aria-label={`Ajouter la matière ${n}`}>+ {n}</button>))}
              </div>
            </div>)}
          {subjects.map((s, i) => (
            <div key={s.name + i} style={{ padding: '8px 0', borderBottom: '1px solid var(--bd)' }}>
              <div className="row" style={{ flexWrap: 'nowrap' }}>
                <SubjectIcon name={s.name} icon={s.icon} size={20} />
                <b style={{ flex: 1, fontSize: 13.5 }}>{s.name}</b>
                <input className="input" type="number" min={0.5} step={0.5} defaultValue={s.coef} style={{ width: 64 }} aria-label={`Coefficient ${s.name}`}
                  onBlur={e => { let v = parseFloat(e.target.value); if (isNaN(v) || v <= 0) v = 1; e.target.value = String(v); if (v !== s.coef) { setData('subjects', subjects.map((x, j) => (j === i ? { ...x, coef: v } : x))); toast('Coefficient mis à jour'); } }} />
                <button className="mini" title="Monter" aria-label={`Monter ${s.name}`} disabled={i === 0} onClick={() => moveSubject(i, -1)}><span aria-hidden="true">↑</span></button>
                <button className="mini" title="Descendre" aria-label={`Descendre ${s.name}`} disabled={i === subjects.length - 1} onClick={() => moveSubject(i, 1)}><span aria-hidden="true">↓</span></button>
                <button className="mini" title="Exporter cette matière" aria-label={`Exporter ${s.name}`} onClick={() => exportSubject(s.name)}><IcoDownload size={13} /></button>
                <button className="mini" title="Renommer" aria-label={`Renommer ${s.name}`} onClick={() => setAsk({ kind: 'ren', i })}><IcoEdit size={13} /></button>
                <button className="mini" title="Regrouper dans une autre matière" aria-label={`Regrouper ${s.name} dans une autre matière`} onClick={() => void mergeInto(i)}><span aria-hidden="true">⇢</span></button>
                <button className="mini" title="Supprimer" aria-label={`Supprimer ${s.name}`} onClick={() => setConfirm({ kind: 'del', i })}><IcoTrash size={13} /></button>
              </div>
              <div className="row" style={{ gap: 6, marginTop: 8, flexWrap: 'wrap' }} role="group" aria-label={`Icône de ${s.name}`}>
                {Object.entries(SUBJECT_ICONS).map(([k, v]) => { const cur = (s.icon && SUBJECT_ICONS[s.icon] ? s.icon : guessIcon(s.name)) === k; return (
                  <button key={k} className="mini" title={v.label} aria-label={`Icône ${v.label} pour ${s.name}`} aria-pressed={cur}
                    style={{ width: 30, height: 30, borderRadius: 8, border: cur ? '2px solid var(--txt)' : '1px solid var(--bd)', display: 'grid', placeItems: 'center' }}
                    onClick={() => setSubjectIcon(i, k)}><SubjectIcon name={s.name} icon={k} size={18} /></button>); })}
                {s.icon && <button className="btn ghost sm" onClick={() => setSubjectIcon(i, undefined)}>Icône automatique</button>}
              </div>
              <div className="row" style={{ gap: 6, marginTop: 8, flexWrap: 'wrap' }} role="group" aria-label={`Couleur de ${s.name}`}>
                {PALETTE.map(c => (
                  <button key={c} className="mini" title={c} aria-label={`Couleur ${c} pour ${s.name}`} aria-pressed={subjColor(s.name).toLowerCase() === c}
                    style={{ width: 26, height: 26, borderRadius: 8, background: c, border: subjColor(s.name).toLowerCase() === c ? '3px solid var(--txt)' : '1px solid var(--bd)' }}
                    onClick={() => setSubjectColor(i, c)} />))}
                <label className="muted" style={{ fontSize: 12, display: 'flex', alignItems: 'center', gap: 6 }}>Autre couleur
                  <input type="color" value={subjColor(s.name)} aria-label={`Couleur libre pour ${s.name}`} onChange={e => setSubjectColor(i, e.target.value)} style={{ width: 32, height: 26, padding: 0, border: 0, background: 'none' }} />
                </label>
                {s.color && <button className="btn ghost sm" onClick={() => setSubjectColor(i, undefined)}>Couleur automatique</button>}
              </div>
            </div>))}
        </div>

        <div className="card appearance-card">
          <div className="appearance-heading">
            <div><h3 style={{ margin: 0 }}>Apparence</h3><p className="muted" style={{ marginTop: 4 }}>Compose une interface plus personnelle, sans effets lumineux.</p></div>
            <div className="appearance-sample"><span className="sample-dot" /><span>Aa</span></div>
          </div>
          <div style={lbl}>Thème</div>
          <div className="choice-row">{([['light', 'Clair'], ['dark', 'Sombre'], ['auto', 'Auto']] as [Theme, string][]).map(([t, l]) => <button key={t} className={`choice-chip${theme === t ? ' active' : ''}`} onClick={() => { onTheme(t); saveSettings({ ...getSettings(), mode: t }); }}>{l}</button>)}</div>

          <div style={lbl}>Couleur d’accent</div>
          <div className="swatches swatches-labelled">{SWATCHES.map(([c, name]) => <button key={c} className={`swatch swatch-lg${set.primaryCustom !== false && set.primary === c ? ' on' : ''}`} style={{ background: c }} aria-label={name} title={name} onClick={() => update({ primary: c, primaryCustom: true })} />)}
            <button className="swatch-reset" onClick={() => update({ primary: '#5f6f5b', primaryCustom: false })}>Défaut</button></div>

          <div style={lbl}>Couleur secondaire</div>
          <div className="swatches swatches-labelled" style={{ marginBottom: 16 }}>{SECONDARY_SWATCHES.map(([c, name]) => <button key={c} className={`swatch swatch-lg${set.secondaryCustom !== false && set.secondary === c ? ' on' : ''}`} style={{ background: c }} aria-label={name} title={name} onClick={() => update({ secondary: c, secondaryCustom: true })} />)}</div>

          <div className="appearance-two-col">
            <div><div style={lbl}>Police du texte</div><select className="input" value={set.font || 'inter'} onChange={e => update({ font: e.target.value })}>{FONTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></div>
            <div><div style={lbl}>Police des titres</div><select className="input" value={set.headingFont || 'fraunces'} onChange={e => update({ headingFont: e.target.value })}>{HEADING_FONTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></div>
          </div>

          <div className="appearance-two-col" style={{ marginTop: 14 }}>
            <div><div style={lbl}>Surface</div><div className="choice-row wrap">{SURFACES.map(([v, l]) => <button key={v} className={`choice-chip${(set.surface || 'paper') === v ? ' active' : ''}`} onClick={() => update({ surface: v })}>{l}</button>)}</div></div>
            <div><div style={lbl}>Arrondis</div><div className="choice-row wrap">{RADII.map(([v, l]) => <button key={v} className={`choice-chip${(set.radius || 'soft') === v ? ' active' : ''}`} onClick={() => update({ radius: v })}>{l}</button>)}</div></div>
          </div>

          <div style={{ marginTop: 16 }}><div style={lbl}>Densité</div><div className="choice-row">{([['compact', 'Compact'], ['comfortable', 'Standard']] as [string, string][]).map(([v, l]) => <button key={v} className={`choice-chip${set.density === v ? ' active' : ''}`} onClick={() => update({ density: v })}>{l}</button>)}</div></div>
          <div style={{ marginTop: 14 }}><div style={lbl}>Taille du texte et de l’affichage</div><div className="choice-row">{TEXT_SIZES.map(([v, l]) => <button key={v} className={`choice-chip${(set.textSize || 'normal') === v ? ' active' : ''}`} onClick={() => update({ textSize: v })}>{l}</button>)}</div></div>
          <div style={{ marginTop: 14 }}><div style={lbl}>Navigation</div><div className="choice-row">{LAYOUTS.map(([v, l]) => <button key={v} className={`choice-chip${(set.layout || 'normal') === v ? ' active' : ''}`} onClick={() => update({ layout: v })}>{l}</button>)}</div></div>
        </div>
        <div className="card">
          <h3 style={{ margin: '0 0 10px' }}>Sauvegarde & données</h3>
          <p className="muted" style={{ marginBottom: 14, lineHeight: 1.6 }}>Tes données restent sur cet appareil ({nFiles} fichier{nFiles !== 1 ? 's' : ''} en bibliothèque). Exporte-les régulièrement comme copie de sécurité.</p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <button className="btn ghost" style={{ justifyContent: 'flex-start' }} onClick={exportLight}>Exporter (JSON, sans contenu des fichiers)</button>
            <button className="btn ghost" style={{ justifyContent: 'flex-start' }} onClick={exportFull}>Exporter complet (avec fichiers)</button>
            <button className="btn ghost" style={{ justifyContent: 'flex-start' }} onClick={() => exportICS(getData('events'), getData('homework'), cls)}>Exporter calendrier (.ics)</button>
            <button className="btn ghost" style={{ justifyContent: 'flex-start' }} onClick={() => inp.current?.click()}>Importer une sauvegarde</button>
            <input ref={inp} type="file" accept="application/json,.json" hidden onChange={e => { const f = e.target.files?.[0]; if (f) importJSON(f); e.target.value = ''; }} />
            <button className="btn ghost" style={{ justifyContent: 'flex-start', color: '#c0392b', borderColor: '#c0392b' }} onClick={() => setConfirm({ kind: 'reset' })}>Tout réinitialiser</button>
          </div>
        </div>

        <div className="card" id="gdriveCard">
          <div className="row spread" style={{ marginBottom: 10 }}><h3 style={{ margin: 0 }}>Sauvegarde Drive</h3><span className="badge">{drive === 'connected' ? 'Connecté' : drive === 'syncing' ? 'Sauvegarde en cours…' : drive === 'offline' ? 'Hors ligne' : drive === 'error' ? 'Erreur' : 'Non connecté'}</span></div>
          <p className="muted" style={{ marginBottom: 12, fontSize: 12.5, lineHeight: 1.6 }}>Sauvegarde tes données (cours, devoirs, notes, réglages) dans un dossier « KENNY’S MOAS » de ton Drive (visible dans Mon Drive, avec une copie par jour). L’appli ne voit que ce dossier, aucun autre fichier de ton Drive. Les fichiers de la bibliothèque ne sont pas inclus.</p>
          {drive !== 'disconnected' && <p className="muted" style={{ marginBottom: 10, fontSize: 12.5 }}>Dernière sauvegarde sur Drive : {dInfo === undefined ? 'inconnue (clique sur « Vérifier »)' : dInfo === null ? 'aucune' : fmtD(dInfo.modifiedTime)}</p>}
          {drive !== 'disconnected' && driveFolderLink() && <p style={{ marginBottom: 10, fontSize: 12.5 }}><a href={driveFolderLink()} target="_blank" rel="noreferrer" style={{ textDecoration: 'underline' }}>Ouvrir le dossier « KENNY’S MOAS » dans Google Drive</a></p>}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {!driveConfigured() ? <p className="muted" style={{ fontSize: 12.5, lineHeight: 1.6 }}>Google Drive n’est pas encore configuré sur cet appareil. Crée le fichier <code>config.local.js</code> à partir de <code>config.local.example.js</code> (voir le README, section « Google Drive »).</p> : drive === 'disconnected' ? <button className="btn" style={{ justifyContent: 'flex-start' }} onClick={async () => { const i = await connectDrive(); if (i !== undefined) setDInfo(i); }}>Se connecter à Google Drive</button> : <>
              <button className="btn" style={{ justifyContent: 'flex-start' }} disabled={drive === 'syncing'} onClick={async () => { const i = await pushToDrive(); if (i) setDInfo(i); }}>Sauvegarder maintenant sur Drive</button>
              <button className="btn ghost" style={{ justifyContent: 'flex-start' }} disabled={drive === 'syncing'} onClick={() => setConfirm({ kind: 'drive' })}>Restaurer depuis Drive</button>
              <button className="btn ghost" style={{ justifyContent: 'flex-start' }} disabled={drive === 'syncing'} onClick={async () => { const i = await remoteInfo(); if (i !== undefined) { setDInfo(i); if (!i) toast('Aucune sauvegarde sur Drive pour l’instant', 'warn'); } }}>Vérifier la sauvegarde sur Drive</button>
              <button className="btn ghost" style={{ justifyContent: 'flex-start' }} onClick={() => { disconnectDrive(); setDInfo(undefined); }}>Se déconnecter</button>
            </>}
          </div>
          <p className="muted" style={{ marginTop: 12, fontSize: 11.5, lineHeight: 1.5 }}>Besoin de sauvegarder aussi les fichiers, de consulter l’historique ou d’importer via Google Picker ? <a href="./legacy/index.html" target="_blank" rel="noopener" style={{ color: 'var(--p)', fontWeight: 700 }}>Ouvre la synchronisation avancée</a> (version d’origine).</p>
        </div>

        <div className="card">
          <div className="row spread" style={{ marginBottom: 10 }}><h3 style={{ margin: 0 }}>Sauvegardes automatiques</h3><button className="btn ghost sm" onClick={async () => { await autoBackup(true); setBks(await listAutoBackups()); toast('Instantané créé'); }}>Créer maintenant</button></div>
          <p className="muted" style={{ marginBottom: 10, fontSize: 12.5 }}>Un instantané léger est pris toute seule pendant l’usage (5 conservés). Les fichiers de la bibliothèque n’en font pas partie.</p>
          {!bks.length ? <p className="muted">Aucune sauvegarde pour l’instant.</p> : bks.map(b => (
            <div key={b.id} className="row spread" style={{ padding: '7px 0', borderBottom: '1px solid var(--bd)' }}><span style={{ fontSize: 13 }}>{new Date(b.id).toLocaleString('fr-FR', { dateStyle: 'medium', timeStyle: 'short' })}</span><button className="btn ghost sm" onClick={() => setConfirm({ kind: 'restore', id: b.id })}>Restaurer</button></div>))}
        </div>
      </div>

      <p className="muted" style={{ textAlign: 'center', marginTop: 18, fontSize: 12 }}>KENNY’S MOAS · version {typeof __APP_VERSION__ !== 'undefined' && __APP_VERSION__ ? __APP_VERSION__ : 'développement'}</p>

      {ask?.kind === 'add' && <AskText title="Nouvelle matière" label="Nom de la matière" onClose={() => setAsk(null)} onOk={n => { if (!n) return; if (subjects.some(s => s.name.toLowerCase() === n.toLowerCase())) return toast('Cette matière existe déjà', 'warn'); setData('subjects', [...subjects, { name: n, coef: 1 }]); toast('Matière ajoutée'); }} />}
      {ask?.kind === 'ren' && <AskText title="Renommer la matière" label="Nouveau nom" initial={subjects[ask.i]?.name} onClose={() => setAsk(null)} onOk={n => renameSubject(ask.i, n)} />}
      {ask?.kind === 'cls' && <AskText title="Classe personnalisée" label="Nom de la classe" onClose={() => setAsk(null)} onOk={n => { if (!n) return; if (allClassNames().includes(n)) return toast('Cette classe existe déjà', 'warn'); setCustomClasses([...getCustomClasses(), n]); setClass(n); toast('Classe créée'); }} />}
      {confirm?.kind === 'del' && <Confirm danger okLabel="Supprimer" message={`Supprimer la matière « ${subjects[confirm.i]?.name} » ? Ses notes, devoirs et remarques restent enregistrés mais ne seront plus rattachés à une matière existante. (Pour les garder, utilise plutôt le bouton ⇢ « Regrouper ».)`} onClose={() => setConfirm(null)} onOk={() => { const before = subjects; setData('subjects', subjects.filter((_, j) => j !== (confirm as { i: number }).i)); toast('Matière supprimée', 'ok', { label: 'Annuler', cb: () => setData('subjects', before) }); }} />}
      {confirm?.kind === 'reset' && <Confirm danger okLabel="Tout supprimer" message="Tout supprimer (toutes classes, fichiers compris) ? Cette action est irréversible." onClose={() => setConfirm(null)} onOk={resetAll} />}
      {confirm?.kind === 'drive' && <Confirm danger okLabel="Restaurer" message="Restaurer la sauvegarde de Google Drive ? Elle est fusionnée avec tes données actuelles : les éléments présents dans la sauvegarde remplacent ceux de cet appareil." onClose={() => setConfirm(null)} onOk={() => { pullFromDrive(); }} />}
      {confirm?.kind === 'restore' && <Confirm danger okLabel="Restaurer" message="Restaurer cet instantané ? Tes données actuelles (notes, devoirs, réglages…) seront remplacées. Les fichiers de la bibliothèque ne sont pas concernés." onClose={() => setConfirm(null)} onOk={() => restoreAutoBackup((confirm as { id: number }).id)} />}
    </div>
  );
}
