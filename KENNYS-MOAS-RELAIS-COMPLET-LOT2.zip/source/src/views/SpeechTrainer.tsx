import { useEffect, useRef, useState } from 'react';
import { IcoLightbulb, IcoTimer } from '../components/Icons';
import { LS, getData, setData } from '../lib/store';
import { toast } from '../lib/toast';
import { mmss } from '../lib/timer';
import { AFFIRMATIONS, CONSTRAINTS, NOTIONS, PREP, TIPS, TOPIC_CATS, TOTAL_TOPICS, pickFromList, pickTopic, pickWords, type Topic, type TopicCat } from '../lib/speechTopics';

/* Entraînement à la prise de parole : un sujet tiré au hasard, un minuteur, quelques règles simples.
   Règles de l'exercice : parler FORT, parler de façon INTELLIGIBLE (articuler, pas trop vite), faire un petit discours structuré.
   Tout est local : le micro (facultatif) ne sert qu'à afficher le niveau de la voix, rien n'est enregistré ni envoyé. */
type Phase = 'idle' | 'prep' | 'speak' | 'done';
interface SpeechLog { date: number; min: number; topic: string; cat: string; scores?: Record<string, number>; voice?: number | null; loud?: number | null }
const LOG_KEY = 'me:speechLog', SEEN_KEY = 'me:speechSeen', SUBJECT = 'Prise de parole';
const DURS: [number, string][] = [[60, '1 min'], [120, '2 min'], [180, '3 min'], [300, '5 min'], [600, '10 min']];
type Act = 'discours' | 'impromptu' | 'camps' | 'explique';
const ACTS: [Act, string, string, number, boolean][] = [
  ['discours', 'Discours', 'Un sujet, un vrai petit discours : accroche, idées, conclusion.', 120, true],
  ['impromptu', 'Impromptu', 'Pas de préparation : tu réponds tout de suite, 1 minute.', 60, false],
  ['camps', 'Deux camps', 'Une affirmation : 1 minute POUR, puis 1 minute CONTRE. Ça apprend à argumenter.', 60, true],
  ['explique', 'Explique ton cours', 'Explique une notion (ou une de tes remarques) à voix haute, sans regarder. Si tu sais l’expliquer, tu l’as compris.', 90, false],
];
const CRITERIA: [string, string][] = [['voix', 'Voix forte'], ['clarte', 'Clarté'], ['structure', 'Structure'], ['rythme', 'Rythme']];

function beep(freq = 880, ms = 220) {
  try {
    const C = (window as any).AudioContext || (window as any).webkitAudioContext; if (!C) return;
    const ctx = new C(); const o = ctx.createOscillator(), g = ctx.createGain(); o.frequency.value = freq; g.gain.value = 0.08; o.connect(g); g.connect(ctx.destination);
    o.start(); setTimeout(() => { o.stop(); ctx.close?.(); }, ms);
  } catch { /* le son est facultatif */ }
}

export function SpeechTrainer() {
  const [cat, setCat] = useState<TopicCat | 'tout'>('tout');
  const [topic, setTopic] = useState<Topic | null>(null);
  const [dur, setDur] = useState(120); const [prepOn, setPrepOn] = useState(true); const [wordsOn, setWordsOn] = useState(false); const [consOn, setConsOn] = useState(false); const [micOn, setMicOn] = useState(false);
  const [words, setWords] = useState<string[]>([]); const [cons, setCons] = useState('');
  const [act, setAct] = useState<Act>('discours'); const [side, setSide] = useState(0);
  const [phase, setPhase] = useState<Phase>('idle'); const [left, setLeft] = useState(0);
  const [log, setLog] = useState<SpeechLog[]>(() => LS.g<SpeechLog[]>(LOG_KEY, []));
  const [summary, setSummary] = useState<{ min: number; voice: number | null; loud: number | null; logged: boolean } | null>(null);
  const [tip, setTip] = useState(() => TIPS[Math.floor(Math.random() * TIPS.length)]);
  const endRef = useRef(0); const startRef = useRef(0); const warned = useRef(false);
  const seen = useRef<string[]>(LS.g<string[]>(SEEN_KEY, []));
  const meter = useRef<HTMLDivElement>(null); const mic = useRef<{ ctx: AudioContext; stream: MediaStream; raf: number } | null>(null);
  const st = useRef({ frames: 0, voice: 0, loud: 0 });
  const durRef = useRef(dur); durRef.current = dur;

  const draw = (c: TopicCat | 'tout' = cat, a: Act = act) => {
    let t: Topic;
    if (a === 'camps') { const x = pickFromList(AFFIRMATIONS, seen.current); t = { text: x, cat: 'debat', key: x }; }
    else if (a === 'explique') {
      const mine = getData('errors').filter(e => e.genre !== 'erreur' && (e.texte || '').trim().length > 8);
      if (mine.length && Math.random() < 0.7) {
        const e = mine[Math.floor(Math.random() * mine.length)]; const full = (e.texte || '').trim(); const cue = full.split(/\s+/).slice(0, 8).join(' ');
        t = { text: `Explique à voix haute, sans regarder (${e.subject || 'ton cours'}) : « ${cue}${full.length > cue.length ? '…' : ''} »`, cat: 'explique', reveal: full, key: e.id };
      } else { const n = pickFromList(NOTIONS, seen.current); t = { text: `Explique ${n}, comme à quelqu’un qui découvre le sujet.`, cat: 'explique', key: n }; }
    } else t = pickTopic(c, seen.current);
    seen.current = [...seen.current, t.key || t.text].slice(-80); LS.s(SEEN_KEY, seen.current);
    setTopic(t); setSide(0); setWords(wordsOn ? pickWords() : []); setCons(consOn ? CONSTRAINTS[Math.floor(Math.random() * CONSTRAINTS.length)] : '');
    setTip(TIPS[Math.floor(Math.random() * TIPS.length)]); setPhase('idle'); setSummary(null);
  };
  const chooseAct = (a: Act) => { const p = ACTS.find(x => x[0] === a)!; setAct(a); setDur(p[3]); setPrepOn(p[4]); draw(cat, a); };
  const nextSide = () => { setSide(1); setSummary(null); beginSpeak(); };

  const stopMic = () => {
    const m = mic.current; if (!m) return; cancelAnimationFrame(m.raf); m.stream.getTracks().forEach(t => t.stop()); m.ctx.close?.().catch(() => {}); mic.current = null;
    if (meter.current) meter.current.style.width = '0%';
  };
  const startMic = async () => {
    st.current = { frames: 0, voice: 0, loud: 0 };
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const C = (window as any).AudioContext || (window as any).webkitAudioContext; const ctx: AudioContext = new C();
      const an = ctx.createAnalyser(); an.fftSize = 1024; ctx.createMediaStreamSource(stream).connect(an); const buf = new Float32Array(an.fftSize);
      const state = { ctx, stream, raf: 0 }; mic.current = state;
      const loop = () => {
        an.getFloatTimeDomainData(buf); let s = 0; for (let i = 0; i < buf.length; i++) s += buf[i] * buf[i];
        const rms = Math.sqrt(s / buf.length); st.current.frames++; if (rms > 0.015) { st.current.voice++; if (rms > 0.05) st.current.loud++; }
        if (meter.current) meter.current.style.width = Math.min(100, rms * 600) + '%';
        state.raf = requestAnimationFrame(loop);
      };
      loop();
    } catch { toast('Micro indisponible ou refusé — l’exercice continue sans mesure de la voix.', 'warn'); setMicOn(false); }
  };

  const beginSpeak = () => {
    startRef.current = Date.now(); endRef.current = Date.now() + durRef.current * 1000; warned.current = false; setLeft(durRef.current); setPhase('speak'); beep(880, 160);
    if (micOn) startMic();
  };
  const begin = () => {
    if (!topic) return; setSummary(null); setSide(0);
    if (prepOn) { endRef.current = Date.now() + 30000; setLeft(30); setPhase('prep'); } else beginSpeak();
  };
  const finish = (natural: boolean) => {
    const secs = Math.round((Date.now() - startRef.current) / 1000); const s = st.current; stopMic();
    const voice = micOn && s.frames > 60 ? s.voice / s.frames : null; const loud = micOn && s.voice > 30 ? s.loud / s.voice : null;
    setSummary({ min: Math.max(1, Math.round(secs / 60)), voice, loud, logged: secs >= 30 }); setPhase('done'); beep(natural ? 660 : 520, natural ? 400 : 160);
    if (secs >= 30 && topic) {
      const entry: SpeechLog = { date: Date.now(), min: Math.max(1, Math.round(secs / 60)), topic: (act === 'camps' ? (side === 0 ? 'POUR · ' : 'CONTRE · ') : '') + topic.text, cat: act, voice, loud };
      const next = [...log, entry].slice(-200); setLog(next); LS.s(LOG_KEY, next);
      setData('sessions', [...getData('sessions'), { date: entry.date, min: entry.min, done: natural, subject: SUBJECT, links: [] }]);
    }
  };
  const finishRef = useRef(finish); finishRef.current = finish; const beginRef = useRef(beginSpeak); beginRef.current = beginSpeak;

  useEffect(() => {
    if (phase !== 'prep' && phase !== 'speak') return;
    const id = setInterval(() => {
      const r = Math.max(0, Math.ceil((endRef.current - Date.now()) / 1000)); setLeft(r);
      if (phase === 'speak' && r === 30 && !warned.current && durRef.current > 60) { warned.current = true; beep(740, 120); }
      if (r === 0) { if (phase === 'prep') beginRef.current(); else finishRef.current(true); }
    }, 200);
    return () => clearInterval(id);
  }, [phase]);
  useEffect(() => () => stopMic(), []);

  const rate = (k: string, v: number) => {
    const next = log.slice(); const last = next[next.length - 1]; if (!last) return; next[next.length - 1] = { ...last, scores: { ...(last.scores || {}), [k]: v } }; setLog(next); LS.s(LOG_KEY, next);
  };
  const lastScores = log[log.length - 1]?.scores || {};
  const totalMin = log.reduce((a, l) => a + l.min, 0);
  const feedback = (() => {
    if (!summary) return [] as string[]; const out: string[] = [];
    if (summary.voice != null) { out.push(summary.voice < 0.35 ? 'Beaucoup de silence : essaie de moins t’arrêter, même si tu cherches tes mots.' : 'Bon débit : tu as parlé la plus grande partie du temps.'); }
    if (summary.loud != null) out.push(summary.loud < 0.4 ? 'Ta voix était souvent faible : parle plus fort, comme si on t’écoutait depuis le fond de la salle.' : 'Ta voix portait bien. Continue ainsi.');
    return out;
  })();

  return (
    <div className="card speech-card" style={{ gridColumn: '1 / -1' }}>
      <div className="row spread" style={{ marginBottom: 6 }}>
        <h3><IcoTimer size={16} style={{ verticalAlign: '-3px' }} /> Entraînement à parler en public</h3>
        <span className="muted" style={{ fontSize: 12 }}>{TOTAL_TOPICS.toLocaleString('fr-FR')} sujets possibles</span>
      </div>
      <p className="muted" style={{ marginBottom: 12 }}>Un sujet tiré au hasard, un minuteur, et tu parles. <b>Règles :</b> parle <b>fort</b>, de façon <b>intelligible</b> (articule, pas trop vite) et fais un vrai petit discours : accroche, idées, conclusion.</p>

      <div className="row" style={{ flexWrap: 'wrap', gap: 6, marginBottom: 6 }} role="tablist" aria-label="Activité">
        {ACTS.map(([k, l]) => <button key={k} role="tab" aria-selected={act === k} className={`btn sm${act === k ? '' : ' ghost'}`} disabled={phase === 'prep' || phase === 'speak'} onClick={() => chooseAct(k)}>{l}</button>)}
      </div>
      <p className="muted" style={{ fontSize: 12.5, marginBottom: 10 }}>{ACTS.find(x => x[0] === act)![2]}</p>
      {(act === 'discours' || act === 'impromptu') && <div className="row" style={{ flexWrap: 'wrap', gap: 6, marginBottom: 10 }}>
        {TOPIC_CATS.map(([k, l]) => <button key={k} className={`btn sm${cat === k ? '' : ' ghost'}`} disabled={phase === 'prep' || phase === 'speak'} onClick={() => { setCat(k); draw(k); }}>{l}</button>)}
      </div>}
      <div className="row" style={{ flexWrap: 'wrap', gap: 6, marginBottom: 10, alignItems: 'center' }}>
        <span className="muted" style={{ fontSize: 12.5 }}>Durée :</span>
        {DURS.map(([s, l]) => <button key={s} className={`btn sm${dur === s ? '' : ' ghost'}`} disabled={phase === 'prep' || phase === 'speak'} onClick={() => setDur(s)}>{l}</button>)}
        <input className="input" type="number" min={1} max={30} style={{ width: 70 }} aria-label="Durée personnalisée en minutes" disabled={phase === 'prep' || phase === 'speak'}
          value={Math.round(dur / 60)} onChange={e => { const m = Math.min(30, Math.max(1, Number(e.target.value) || 1)); setDur(m * 60); }} /><span className="muted" style={{ fontSize: 12.5 }}>min</span>
      </div>
      <div className="row" style={{ flexWrap: 'wrap', gap: 14, marginBottom: 14 }}>
        <label className="row" style={{ gap: 6, fontSize: 13, flexWrap: 'nowrap', alignItems: 'flex-start' }}><input type="checkbox" checked={prepOn} onChange={e => setPrepOn(e.target.checked)} /> 30 s de préparation</label>
        <label className="row" style={{ gap: 6, fontSize: 13, flexWrap: 'nowrap', alignItems: 'flex-start' }}><input type="checkbox" checked={wordsOn} onChange={e => { setWordsOn(e.target.checked); setWords(e.target.checked ? pickWords() : []); }} /> 3 mots imposés</label>
        <label className="row" style={{ gap: 6, fontSize: 13, flexWrap: 'nowrap', alignItems: 'flex-start' }}><input type="checkbox" checked={consOn} onChange={e => { setConsOn(e.target.checked); setCons(e.target.checked ? CONSTRAINTS[Math.floor(Math.random() * CONSTRAINTS.length)] : ''); }} /> Une contrainte</label>
        <label className="row" style={{ gap: 6, fontSize: 13, flexWrap: 'nowrap', alignItems: 'flex-start' }}><input type="checkbox" checked={micOn} onChange={e => setMicOn(e.target.checked)} /> Mesurer ma voix (micro, rien n’est enregistré)</label>
      </div>

      <div className="speech-topic" role="status" aria-live="polite">
        {topic ? <>
          <div className="speech-cat">{act === 'camps' ? `Deux camps — tu défends le camp ${side === 0 ? 'POUR' : 'CONTRE'}` : act === 'explique' ? 'Explique ton cours' : TOPIC_CATS.find(([k]) => k === topic.cat)?.[1]}</div>
          <div className="speech-text">{topic.text}</div>
          {words.length > 0 && <div className="speech-extra"><b>Mots à placer :</b> {words.map(w => <span key={w} className="badge">{w}</span>)}</div>}
          {cons && <div className="speech-extra"><b>Contrainte :</b> {cons}</div>}
        </> : <div className="muted">Appuie sur « Tirer un sujet » pour commencer.</div>}
      </div>

      {(phase === 'prep' || phase === 'speak') && <div style={{ textAlign: 'center', margin: '14px 0' }}>
        <div className="muted" style={{ fontSize: 13, fontWeight: 700 }}>{phase === 'prep' ? 'PRÉPARATION — réfléchis à ton plan' : 'À TOI DE PARLER'}</div>
        <div className="timer-big" style={{ color: phase === 'speak' ? 'var(--p)' : 'var(--txt)' }}>{mmss(left)}</div>
        {phase === 'speak' && micOn && <div className="speech-meter" aria-hidden="true"><div ref={meter} /></div>}
        {phase === 'prep' && <div className="speech-prep">{PREP.map(([l, n, d], i) => <div key={i}><b>{l}</b> {n}<span className="muted"> — {d}</span></div>)}</div>}
      </div>}

      <div className="row" style={{ justifyContent: 'center', gap: 8, margin: '12px 0' }}>
        {phase === 'idle' || phase === 'done' ? <>
          <button className="btn ghost" onClick={() => draw()}><IcoLightbulb size={14} /> {topic ? 'Autre sujet' : 'Tirer un sujet'}</button>
          {topic && <button className="btn" onClick={begin}>{phase === 'done' ? 'Recommencer' : 'Commencer'}</button>}
        </> : <>
          {phase === 'prep' && <button className="btn" onClick={beginSpeak}>Je suis prêt</button>}
          <button className="btn ghost" onClick={() => { if (phase === 'speak') finish(false); else setPhase('idle'); }}>{phase === 'speak' ? 'Terminer' : 'Annuler'}</button>
        </>}
      </div>
      <p className="muted" style={{ fontSize: 12.5, textAlign: 'center' }}>Astuce : {tip}</p>

      {phase === 'done' && summary && <div className="speech-done">
        <h4>Bravo, {summary.min} min de prise de parole</h4>
        {topic?.reveal && <div className="rd-quote" style={{ marginTop: 8 }}><span><b>Ce que tu avais noté :</b> {topic.reveal}</span></div>}
        {act === 'explique' && !topic?.reveal && <p className="muted" style={{ marginTop: 6 }}>Retrouve ta leçon : as-tu oublié une idée importante ? Refais-le en la plaçant.</p>}
        {act === 'camps' && side === 0 && <div style={{ marginTop: 10 }}><button className="btn" onClick={nextSide}>Maintenant : défends le camp CONTRE</button></div>}
        {feedback.map(f => <p key={f} className="muted" style={{ marginTop: 4 }}>{f}</p>)}
        <div className="muted" style={{ marginTop: 8, fontSize: 12.5 }}>Note-toi honnêtement (1 = à travailler, 5 = très bien) :</div>
        {CRITERIA.map(([k, l]) => <div key={k} className="row" style={{ gap: 6, marginTop: 6, alignItems: 'center' }}>
          <span style={{ width: 100, fontSize: 13 }}>{l}</span>
          {[1, 2, 3, 4, 5].map(n => <button key={n} className={`btn sm${lastScores[k] === n ? '' : ' ghost'}`} style={{ minWidth: 34 }} aria-pressed={lastScores[k] === n} onClick={() => rate(k, n)}>{n}</button>)}
        </div>)}
        <p className="muted" style={{ marginTop: 8, fontSize: 12 }}>{summary.logged ? `Ta séance est ajoutée à « Cette semaine » sous « ${SUBJECT} ».` : 'Séance trop courte (moins de 30 s) : elle n’est pas enregistrée.'}</p>
      </div>}

      {log.length > 0 && <div style={{ marginTop: 16 }}>
        <div className="row spread" style={{ fontSize: 13 }}><b>Mon historique</b><span className="muted">{log.length} discours · {totalMin} min</span></div>
        <div style={{ marginTop: 6 }}>{log.slice(-5).reverse().map(l => <div key={l.date} className="speech-hist"><span>{l.topic}</span><span className="muted">{l.min} min · {new Date(l.date).toLocaleDateString('fr-FR')}</span></div>)}</div>
      </div>}
    </div>
  );
}
