import React, { useState } from 'react';
import { IcoTimer, IcoBook, IcoCal, IcoTarget } from '../components/Icons';

/* Anciennes vues « maquette » remplacées par des vues réelles : Homework.tsx, Grades.tsx, Schedule.tsx, Reviews.tsx,
   Errors.tsx, Goals.tsx, Settings.tsx. Ce fichier ne garde que la FAQ et la liste des méthodes de révision. */

export const METHODS = [
  { name: 'Rappel actif', desc: 'Essaie de te rappeler le contenu sans regarder tes notes.', icon: <IcoTimer size={18} />, color: '#5f6f5b' },
  { name: 'Technique Feynman', desc: 'Explique le concept comme si tu enseignais à un enfant.', icon: <IcoBook size={18} />, color: '#b86a49' },
  { name: 'Répétition espacée', desc: 'Révise à intervalles croissants pour ancrer en mémoire long terme.', icon: <IcoCal size={18} />, color: '#75637f' },
  { name: 'Cartes mémoire', desc: "Flashcards : question d'un côté, réponse de l'autre.", icon: <IcoTarget size={18} />, color: '#5e789f' },
];

/* ── FAQ ── */
const FAQ_ITEMS = [
  { q: 'Comment importer un fichier PDF ?', a: 'Va dans Bibliothèque, puis glisse-dépose ton fichier dans la zone d\'import, ou clique dessus pour parcourir tes fichiers.' },
  { q: 'Mes données sont-elles en sécurité ?', a: 'Oui, toutes tes données restent sur ton appareil (localStorage + IndexedDB). Rien n\'est envoyé à un serveur sans ton accord explicite.' },
  { q: 'Comment activer la synchro Google Drive ?', a: 'Dans Réglages → Google Drive, clique sur « Se connecter avec Google ». Tu dois d\'abord créer un projet Google Cloud (voir SETUP.md).' },
  { q: 'L\'appli fonctionne-t-elle hors ligne ?', a: 'Oui, grâce au Service Worker. Une fois chargée, l\'application fonctionne entièrement hors ligne.' },
  { q: 'Comment exporter mon emploi du temps ?', a: 'Dans Réglages → Sauvegarde, clique sur « Exporter calendrier (.ics) » pour créer un fichier importable dans Google Calendar, Apple Calendar ou Outlook.' },
];

export function FaqView() {
  const [open, setOpen] = useState<number | null>(null);
  return (
    <div className="anim-in">
      <div className="page-intro">
        <div>
          <h2>Aide & FAQ</h2>
          <div className="sub">Questions fréquentes sur KENNY'S MOAS</div>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: 20, alignItems: 'start' }}>
        <div className="card">
          <h3 style={{ margin: '0 0 14px', fontSize: 16 }}>Questions fréquentes</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {FAQ_ITEMS.map((item, i) => (
              <div key={i} style={{ border: '1px solid var(--bd)', borderRadius: 10, overflow: 'hidden' }}>
                <button
                  onClick={() => setOpen(open === i ? null : i)}
                  style={{ width: '100%', padding: '12px 14px', textAlign: 'left', display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontWeight: 700, fontSize: 13.5 }}
                >
                  {item.q}
                  <span style={{ color: 'var(--p)', fontWeight: 700, fontSize: 18, lineHeight: 1, transform: open === i ? 'rotate(45deg)' : 'none', transition: '.18s' }}>+</span>
                </button>
                {open === i && (
                  <div style={{ padding: '0 14px 14px', fontSize: 13.5, color: 'var(--mut)', lineHeight: 1.65 }}>
                    {item.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
        <div className="card">
          <h3 style={{ margin: '0 0 12px', fontSize: 16 }}>À propos de KENNY'S MOAS</h3>
          <p style={{ fontSize: 13.5, color: 'var(--mut)', lineHeight: 1.7, marginBottom: 14 }}>
            KENNY'S MOAS est une application scolaire tout-en-un conçue pour les lycéens : notes, devoirs, emploi du temps, bibliothèque de documents, révisions et suivi de progression.
          </p>
          <p style={{ fontSize: 13.5, color: 'var(--mut)', lineHeight: 1.7 }}>
            L'application fonctionne entièrement hors ligne (PWA) et peut être installée sur ton téléphone ou ordinateur depuis le navigateur.
          </p>
          <div style={{ marginTop: 16, padding: '12px 14px', background: 'var(--bg)', borderRadius: 9, fontSize: 12.5, color: 'var(--mut)' }}>
            Version fusion · Design Phase 1 + fonctions de la refonte 2026-09-19-F
          </div>
        </div>
      </div>
    </div>
  );
}
