/// <reference types="vite/client" />

/** Version produit (package.json), injectée au build. Absente en aperçu de développement. */
declare const __APP_VERSION__: string | undefined
