/* Tests pièce 1 — `pnpm test` (node:test + tsx). Aucun navigateur requis : localStorage et IndexedDB sont simulés en mémoire. */
import test from 'node:test';
import assert from 'node:assert/strict';

// ── localStorage en mémoire ──
const mem = new Map<string, string>();
(globalThis as any).localStorage = { getItem: (k: string) => (mem.has(k) ? mem.get(k)! : null), setItem: (k: string, v: string) => void mem.set(k, String(v)), removeItem: (k: string) => void mem.delete(k), key: (i: number) => [...mem.keys()][i] ?? null, get length() { return mem.size; } };
// ── IndexedDB minimal en mémoire (assez pour lib/db.ts) ──
const stores: Record<string, Map<any, any>> = { files: new Map(), annot: new Map(), read: new Map(), backups: new Map() };
const KEYP: Record<string, string> = { files: 'id', annot: 'key', read: 'id', backups: 'id' };
(globalThis as any).indexedDB = { open() {
  const r: any = {}; const db = { objectStoreNames: { contains: () => true }, transaction(st: string) {
    const tx: any = {}; const done = () => setTimeout(() => tx.oncomplete && tx.oncomplete(), 0);
    const req = (fn: () => any) => { const q: any = {}; q.result = fn(); done(); return q; };
    tx.objectStore = () => ({ put: (v: any) => req(() => { stores[st].set(v[KEYP[st]], v); return v[KEYP[st]]; }), get: (k: any) => req(() => stores[st].get(k)), delete: (k: any) => req(() => stores[st].delete(k)), getAll: () => req(() => [...stores[st].values()]) });
    return tx; } };
  setTimeout(() => { r.result = db; r.onupgradeneeded && r.onupgradeneeded(); r.onsuccess && r.onsuccess(); }, 0); return r; } };

const { LS, getData, setData, setClass } = await import('../src/lib/store');
const R = await import('../src/lib/relations');
const M = await import('../src/lib/migrate');
const F = await import('../src/lib/files');
const { dbPut, dbGet, dbAll } = await import('../src/lib/db');

const D = await import('../src/lib/deletion');
const { onToast } = await import('../src/lib/toast');

const CL = 'Première A';
const reset = () => { mem.clear(); Object.values(stores).forEach(s => s.clear()); setClass(CL); };
const hw = (id: string, extra: object = {}) => ({ id, title: 'Devoir ' + id, subject: 'Français', due: '', priority: 'normale', type: 'devoir', desc: '', fileId: null, reminder: null, done: false, links: [], ...extra });
const rem = (id: string, extra: object = {}) => ({ id, subject: 'Français', chapter: '', question: 'q' + id, mistake: 'm' + id, method: '', fileId: null, linkType: null, linkId: null, date: '2026-09-01', boite: 2, prochaineRevision: '2026-10-01', links: [], ...extra });
const H = (id: string) => ({ type: 'homework' as const, id }), Rm = (id: string) => ({ type: 'remark' as const, id });
const lastToast = () => { let t: any = null; const off = onToast(x => { t = x; }); return { get: () => t, off }; };

/* Reproduit exactement le geste de Homework.tsx « Vider les terminés ». */
const viderLesTermines = () => {
  const snap = getData('homework'); const refs = snap.filter((h: any) => h.done).map((h: any) => H(h.id));
  return D.removeObjects(refs, { remove: () => setData('homework', getData('homework').filter((h: any) => !h.done)), restore: () => setData('homework', snap), done: 'Devoirs terminés supprimés' });
};
const setup = () => {
  reset();
  setData('homework', [hw('h1', { done: true }), hw('h2', { done: true }), hw('h3')] as any); setData('errors', [rem('r1'), rem('r2')] as any);
  R.linkObjects(H('h1'), Rm('r1')); R.linkObjects(H('h2'), Rm('r1')); R.linkObjects(H('h2'), Rm('r2')); R.linkObjects(H('h3'), Rm('r2')); R.linkObjects(H('h1'), H('h2'));
};

test('« Vider les terminés » : plus aucun lien orphelin vers les devoirs supprimés', () => {
  setup(); viderLesTermines();
  assert.deepEqual(getData('homework').map((h: any) => h.id), ['h3']);
  const err = getData('errors'); assert.deepEqual(err.find((e: any) => e.id === 'r1').links, [], 'r1 ne pointe plus vers h1/h2');
  assert.deepEqual(err.find((e: any) => e.id === 'r2').links, [{ type: 'homework', id: 'h3' }], 'le lien vers h3 (non supprimé) reste');
  assert.deepEqual(getData('homework')[0].links, [{ type: 'remark', id: 'r2' }]);
  assert.deepEqual(R.checkIntegrity(null).log, [], 'aucun orphelin détecté après coup');
});
test('« Vider les terminés » : un seul Annuler remet les devoirs ET tous les liens, à l\'identique', () => {
  setup(); const before = JSON.stringify({ h: getData('homework'), e: getData('errors') });
  const t = lastToast(); viderLesTermines(); const act = t.get().action; t.off(); assert.ok(act && act.label === 'Annuler');
  act.cb(); assert.equal(JSON.stringify({ h: getData('homework'), e: getData('errors') }), before);
});
test('« Vider les terminés » : sans devoir terminé ni lien, rien d\'autre n\'est touché', () => {
  reset(); setData('homework', [hw('a'), hw('b', { done: true })] as any); setData('errors', [rem('r')] as any);
  viderLesTermines(); assert.deepEqual(getData('homework').map((h: any) => h.id), ['a']); assert.equal(getData('errors').length, 1);
});
test('removeObject (suppression unitaire) : liens retirés, puis Annuler remet tout', async () => {
  setup(); const before = JSON.stringify({ h: getData('homework'), e: getData('errors') });
  const { onChoose } = await import('../src/lib/choose'); const offC = onChoose(r => r.onPick('ok')); // l'utilisateur confirme
  const t = lastToast();
  const okk = await D.removeObject(H('h1'), 'ce devoir', { remove: () => setData('homework', getData('homework').filter((h: any) => h.id !== 'h1')), restore: () => setData('homework', JSON.parse(before).h), done: 'Devoir supprimé' });
  offC(); assert.equal(okk, true);
  assert.ok(!getData('errors').some((e: any) => (e.links || []).some((l: any) => l.id === 'h1')), 'aucun lien vers h1');
  const act = t.get().action; t.off(); act.cb();
  assert.equal(JSON.stringify({ h: getData('homework'), e: getData('errors') }), before);
});
test('remarque supprimée depuis le lecteur : liens retirés, Annuler remet la remarque et ses liens', () => {
  setup(); const before = JSON.stringify({ h: getData('homework'), e: getData('errors') });
  const t = lastToast(); // même séquence que FileViewer.deleteRemark
  const snap = getData('errors'); const refs = R.removeAllReferencesTo(Rm('r1')); setData('errors', getData('errors').filter((e: any) => e.id !== 'r1'));
  assert.ok(!getData('homework').some((h: any) => (h.links || []).some((l: any) => l.id === 'r1')), 'aucun devoir ne pointe vers r1');
  setData('errors', snap); refs.undo(); t.off();
  assert.equal(JSON.stringify({ h: getData('homework'), e: getData('errors') }), before);
});
