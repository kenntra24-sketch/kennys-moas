/* Tests pièce 1 — `pnpm test` (node:test + tsx). Aucun navigateur requis : localStorage et IndexedDB sont simulés en mémoire. */
import test from 'node:test';
import assert from 'node:assert/strict';

// ── localStorage en mémoire ──
const mem = new Map<string, string>();
(globalThis as any).localStorage = { getItem: (k: string) => (mem.has(k) ? mem.get(k)! : null), setItem: (k: string, v: string) => void mem.set(k, String(v)), removeItem: (k: string) => void mem.delete(k), key: (i: number) => [...mem.keys()][i] ?? null, get length() { return mem.size; } };
// ── IndexedDB minimal en mémoire (assez pour lib/db.ts) ──
const stores: Record<string, Map<any, any>> = { files: new Map(), annot: new Map(), read: new Map(), backups: new Map() };
const KEYP: Record<string, string> = { files: 'id', annot: 'key', read: 'id', backups: 'id' };
(globalThis as any).indexedDB = { open() {
  const r: any = {}; const db = { objectStoreNames: { contains: () => true }, transaction(st: string) {
    const tx: any = {}; const done = () => setTimeout(() => tx.oncomplete && tx.oncomplete(), 0);
    const req = (fn: () => any) => { const q: any = {}; q.result = fn(); done(); return q; };
    tx.objectStore = () => ({ put: (v: any) => req(() => { stores[st].set(v[KEYP[st]], v); return v[KEYP[st]]; }), get: (k: any) => req(() => stores[st].get(k)), delete: (k: any) => req(() => stores[st].delete(k)), getAll: () => req(() => [...stores[st].values()]) });
    return tx; } };
  setTimeout(() => { r.result = db; r.onupgradeneeded && r.onupgradeneeded(); r.onsuccess && r.onsuccess(); }, 0); return r; } };

const { LS, getData, setData, setClass } = await import('../src/lib/store');
const R = await import('../src/lib/relations');
const M = await import('../src/lib/migrate');
const F = await import('../src/lib/files');
const { dbPut, dbGet, dbAll } = await import('../src/lib/db');

const CL = 'Première A';
const reset = () => { mem.clear(); Object.values(stores).forEach(s => s.clear()); setClass(CL); };
const hw = (id: string, extra: object = {}) => ({ id, title: 'Devoir ' + id, subject: 'Français', due: '', priority: 'normale', type: 'devoir', desc: '', fileId: null, reminder: null, done: false, links: [], ...extra });
const rem = (id: string, extra: object = {}) => ({ id, subject: 'Français', chapter: '', question: 'q' + id, mistake: 'm' + id, method: '', fileId: null, linkType: null, linkId: null, date: '2026-09-01', boite: 2, prochaineRevision: '2026-10-01', links: [], ...extra });
const H = (id: string) => ({ type: 'homework' as const, id }), Rm = (id: string) => ({ type: 'remark' as const, id }), Fi = (id: string) => ({ type: 'file' as const, id });

test('linkObjects : bidirectionnel et idempotent', () => {
  reset(); setData('homework', [hw('h1')] as any); setData('errors', [rem('r1')] as any);
  assert.equal(R.linkObjects(H('h1'), Rm('r1')), true);
  assert.equal(R.linkObjects(H('h1'), Rm('r1')), false, 'deuxième appel : rien à changer');
  assert.equal(R.linkObjects(Rm('r1'), H('h1')), false, 'sens inverse : déjà relié');
  assert.deepEqual(getData('homework')[0].links, [{ type: 'remark', id: 'r1' }]);
  assert.deepEqual(getData('errors')[0].links, [{ type: 'homework', id: 'h1' }]);
  assert.equal(R.linkObjects(H('h1'), H('h1')), false, 'jamais de lien sur soi-même');
  assert.equal(R.linkObjects(H('h1'), Rm('inconnu')), false, 'objet du store inexistant');
});
test('unlinkObjects retire les deux côtés et les anciens champs', () => {
  reset(); setData('homework', [hw('h1', { fileId: 'f1' })] as any); setData('errors', [rem('r1')] as any);
  R.linkObjects(H('h1'), Rm('r1')); R.linkObjects(Rm('r1'), Fi('f1'), { page: 17 });
  assert.equal(R.unlinkObjects(H('h1'), Rm('r1')), true);
  assert.deepEqual(getData('homework')[0].links, []); assert.deepEqual((getData('errors')[0].links || []).filter(l => l.type === 'homework'), []);
  assert.equal(R.unlinkObjects(H('h1'), Fi('f1')), true); assert.equal(getData('homework')[0].fileId, null);
  assert.equal(R.unlinkObjects(H('h1'), Rm('r1')), false, 'idempotent');
});
test('page : stockée sur le lien vers le fichier, jamais inventée', () => {
  reset(); setData('errors', [rem('r1'), rem('r2')] as any);
  R.linkObjects(Rm('r1'), Fi('f1'), { page: 17 }); R.linkObjects(Rm('r2'), Fi('f1'));
  const rel = R.getRelated(Fi('f1')).remark!;
  assert.deepEqual(rel.map(l => [l.id, l.page]).sort(), [['r1', 17], ['r2', undefined]]);
  R.linkObjects(Rm('r1'), H('nope') as any); // pas de page sur un lien non-fichier
  assert.equal(R.getRelated(Rm('r1')).file![0].page, 17);
});
test('getRelated : groupé par type, anciens champs + index inverse, sans doublon', () => {
  reset();
  setData('homework', [hw('h1', { fileId: 'f1' })] as any);
  setData('grades', [{ id: 'g1', subject: 'Français', rawScore: 12, maxScore: 20, value: 12, coef: 1, date: '2026-09-02', homeworkId: 'h1', fileId: 'f1' }] as any);
  setData('errors', [rem('r1', { linkType: 'homework', linkId: 'h1' })] as any);
  const f = R.getRelated(Fi('f1')); assert.deepEqual(Object.keys(f).sort(), ['homework', 'result']);
  const h = R.getRelated(H('h1')); assert.equal(h.file!.length, 1); assert.equal(h.result!.length, 1); assert.equal(h.remark!.length, 1);
  assert.equal(R.describeRelated(H('h1')), '1 fichier, 1 note et 1 remarque');
  assert.equal(R.describeRelated(Fi('f1')), '1 devoir et 1 note');
  assert.equal(R.describeRelated(Fi('vide')), '');
});
test('removeAllReferencesTo : nettoie liens + anciens champs, et undo remet tout', () => {
  reset(); setData('homework', [hw('h1', { fileId: 'f1' }), hw('h2')] as any); setData('errors', [rem('r1')] as any);
  R.linkObjects(Rm('r1'), Fi('f1'), { page: 3 }); R.linkObjects(H('h2'), Fi('f1'));
  const before = JSON.stringify([getData('homework'), getData('errors')]);
  const { count, undo } = R.removeAllReferencesTo(Fi('f1'));
  assert.equal(count, 3); assert.equal(R.describeRelated(Fi('f1')), '');
  assert.equal(getData('homework')[0].fileId, null);
  undo(); assert.equal(JSON.stringify([getData('homework'), getData('errors')]), before);
});
test('repointReferences : réaffecte liens et fileId, sans doublon', () => {
  reset(); setData('homework', [hw('h1', { fileId: 'NEW' }), hw('h2', { links: [{ type: 'file', id: 'OLD' }, { type: 'file', id: 'NEW' }] })] as any);
  assert.equal(R.repointReferences(Fi('NEW'), Fi('OLD')), 2);
  assert.equal(getData('homework')[0].fileId, 'OLD');
  assert.deepEqual(getData('homework')[1].links, [{ type: 'file', id: 'OLD' }]);
  assert.equal(R.repointReferences(Fi('NEW'), Fi('OLD')), 0, 'idempotent');
});
test('checkIntegrity : orphelins réparés, réciprocité ajoutée, idempotent', () => {
  reset(); setData('homework', [hw('h1', { fileId: 'ghost', links: [{ type: 'remark', id: 'r1' }, { type: 'remark', id: 'disparu' }, { type: 'file', id: 'ok' }, { type: 'inconnu-futur', id: 'x' }] })] as any);
  setData('errors', [rem('r1')] as any);
  const r1 = R.checkIntegrity(new Set(['ok']));
  assert.equal(r1.removed, 2, 'lien vers la remarque disparue + ancien champ fileId pendant');
  assert.ok(getData('homework')[0].links.some((l: any) => l.type === 'inconnu-futur'), 'entrée inconnue conservée');
  assert.equal(getData('homework')[0].fileId, null);
  assert.deepEqual(getData('errors')[0].links, [{ type: 'homework', id: 'h1' }], 'réciprocité');
  const snap = JSON.stringify([getData('homework'), getData('errors')]);
  const r2 = R.checkIntegrity(new Set(['ok'])); assert.equal(r2.removed + r2.added, 0); assert.equal(JSON.stringify([getData('homework'), getData('errors')]), snap);
});
test('checkIntegrity sans liste de fichiers : ne supprime aucun lien vers un fichier', () => {
  reset(); setData('homework', [hw('h1', { fileId: 'f1', links: [{ type: 'file', id: 'f1' }] })] as any);
  assert.equal(R.checkIntegrity(null).removed, 0); assert.equal(getData('homework')[0].fileId, 'f1');
});

/* ── Migration : jeu de données v1.4.1 reconstitué (forme réelle : erreurs avec boîte Leitner, fileId, linkType/linkId) ── */
const seedV141 = (cl: string) => {
  const K = (k: string) => `me:${cl}:${k}`;
  LS.s(K('subjects'), [{ name: 'Français', coef: 3 }, { name: 'Mathématiques', coef: 4 }]);
  LS.s(K('homework'), [hw('h1', { fileId: 'f1', desc: 'Importé depuis un fichier' }), hw('h2')]);
  LS.s(K('grades'), [{ id: 'g1', subject: 'Français', rawScore: 12, maxScore: 20, value: 12, coef: 2, type: 'devoir', date: '2026-09-02', homeworkId: 'h1', fileId: 'f1', champInconnu: 42 }]);
  LS.s(K('events'), [{ id: 'e1', title: 'Contrôle', type: 'controle', subject: 'Français', date: '2026-10-05', time: '08:00', desc: '', fileId: null, reminder: null, links: [] }]);
  LS.s(K('sessions'), [{ date: 1790000000000, min: 25, done: true, subject: 'Français' }]);
  LS.s(K('errors'), [rem('r1', { boite: 3, prochaineRevision: '2026-11-01', fileId: 'f1' }), rem('r2', { linkType: 'homework', linkId: 'h1', boite: 0 }), rem('r3', { extraLegacy: 'garde-moi' })]);
};
test('migration v1.4.1 → schéma 2 : aucune perte, Leitner intact, idempotente', () => {
  reset(); seedV141(CL); seedV141('Terminale C');
  const before = JSON.parse(JSON.stringify({ errors: getData('errors'), grades: getData('grades') }));
  assert.equal(M.migrateAllClasses(), true);
  const errs = getData('errors');
  assert.equal(errs.length, 3);
  for (const [i, e] of errs.entries()) {
    assert.equal(e.genre, 'erreur');
    for (const k of ['question', 'mistake', 'method', 'boite', 'prochaineRevision', 'fileId', 'linkType', 'linkId', 'date', 'subject']) assert.deepEqual((e as any)[k], (before.errors[i] as any)[k], k + ' conservé');
  }
  assert.equal((errs[2] as any).extraLegacy, 'garde-moi');
  assert.deepEqual(errs[0].links, [{ type: 'file', id: 'f1' }]); assert.deepEqual(errs[0].source, { type: 'file', id: 'f1' });
  assert.deepEqual(errs[1].links, [{ type: 'homework', id: 'h1' }]); assert.equal(errs[2].source, null);
  const g: any = getData('grades')[0]; assert.equal(g.champInconnu, 42); assert.equal(g.homeworkId, 'h1'); assert.equal(g.fileId, 'f1');
  assert.deepEqual(g.links, [{ type: 'file', id: 'f1' }, { type: 'homework', id: 'h1' }]);
  assert.deepEqual(getData('homework')[0].links, [{ type: 'file', id: 'f1' }]); assert.equal(getData('homework')[0].fileId, 'f1');
  assert.deepEqual(getData('sessions')[0].links, []);
  assert.deepEqual(getData('subjects').map(s => [s.name, s.coef, s.id]), [['Français', 3, 'francais'], ['Mathématiques', 4, 'mathematiques']]);
  assert.equal(LS.g(`me:${CL}:schemaVersion`, 0), 2); assert.equal(LS.g('me:Terminale C:schemaVersion', 0), 2, 'toutes les classes migrées');
  const snap = JSON.stringify([...mem.entries()].sort());
  assert.equal(M.migrateAllClasses(), false, 'deuxième passage : rien à écrire'); assert.equal(JSON.stringify([...mem.entries()].sort()), snap);
  // les relations lisent le même résultat qu'avant la migration
  assert.equal(R.describeRelated(Fi('f1')), '1 devoir, 1 note et 1 remarque');
});
test('migration : aucune donnée = rien ne se passe, pas d\'exception', () => { reset(); assert.equal(M.migrateAllClasses(), false); });
test('catégories : mapping des anciennes valeurs', () => {
  const c = (libraryType: string | null, homeworkType: string | null = null) => M.categoryFor({ libraryType, homeworkType });
  assert.deepEqual(['cours', 'fiche-revision', 'fiche-resume', 'fiche-methode', 'fiche-explicative', 'schema', 'note-classe', 'autre-support'].map(t => c(t)), ['cours', 'fiche', 'fiche', 'fiche', 'fiche', 'fiche', 'notes', 'cours']);
  assert.deepEqual([c('Fiche de révision'), c('Fiche résumé'), c('Fiche méthode'), c('Note de classe'), c('Autre travail')], ['fiche', 'fiche', 'fiche', 'notes', 'exercice']);
  assert.equal(c(null, 'devoir'), 'exercice'); assert.equal(c(null, 'autre'), 'exercice'); assert.equal(c(null, null), null); assert.equal(c('truc-inconnu'), null);
  assert.equal(M.categoryFor({ category: 'notes', libraryType: 'cours' }), 'notes', 'une catégorie déjà posée n\'est jamais écrasée');
});
test('migrateFiles : category ajoutée, libraryType d\'origine conservé, idempotent', async () => {
  reset();
  const b = new Blob(['x']);
  await dbPut('files', { id: 'a', name: 'a.pdf', type: 'application/pdf', size: 1, date: 1, subject: '', classId: CL, fav: false, lastOpened: 0, progress: 0, blob: b, libraryType: 'fiche-methode', homeworkType: null, tags: [] });
  await dbPut('files', { id: 'b', name: 'b.pdf', type: 'application/pdf', size: 1, date: 1, subject: '', classId: CL, fav: false, lastOpened: 0, progress: 0, blob: b, libraryType: null, homeworkType: null, tags: [] });
  assert.equal(await M.migrateFiles(), 1);
  assert.equal((await dbGet<any>('files', 'a')).category, 'fiche'); assert.equal((await dbGet<any>('files', 'a')).libraryType, 'fiche-methode');
  assert.equal((await dbGet<any>('files', 'b')).category, undefined, 'non classé : on n\'invente rien');
  assert.equal(await M.migrateFiles(), 0);
});

/* ── Remplacement de fichier ── */
test('replaceFile : l\'ancien fileId survit, associations et métadonnées conservées, lecture remise à zéro', async () => {
  reset();
  const oldB = new Blob(['ancien contenu']), newB = new Blob(['nouveau contenu plus long']);
  await dbPut('files', { id: 'OLD', name: 'cours.pdf', type: 'application/pdf', size: 14, date: 1, subject: 'Français', chapter: 'ch2', classId: CL, fav: true, lastOpened: 55, progress: 80, blob: oldB, libraryType: 'cours', category: 'cours', homeworkType: null, tags: ['important'] });
  await dbPut('files', { id: 'NEW', name: 'cours (1).pdf', type: 'application/pdf', size: 25, date: 999, subject: '', classId: CL, fav: false, lastOpened: 0, progress: 0, blob: newB, libraryType: null, category: null, homeworkType: 'devoir', tags: [] });
  await dbPut('read', { id: 'OLD', page: 12, bookmarks: [{ p: 12 }] });
  setData('homework', [hw('hOld', { fileId: 'OLD' }), hw('hNew', { fileId: 'NEW', desc: 'Importé depuis un fichier' })] as any); setData('errors', [rem('r1')] as any);
  R.linkObjects(Rm('r1'), Fi('OLD'), { page: 17 });
  assert.equal(await F.replaceFile('OLD', 'NEW'), true);
  const files = await dbAll<any>('files'); assert.deepEqual(files.map(f => f.id), ['OLD'], 'un seul enregistrement, id d\'origine');
  const f = files[0];
  assert.equal(f.size, 25); assert.equal(f.date, 999); assert.equal(await f.blob.text(), 'nouveau contenu plus long');
  assert.deepEqual([f.name, f.subject, f.category, f.fav, f.tags, f.chapter, f.lastOpened], ['cours.pdf', 'Français', 'cours', true, ['important'], 'ch2', 55]);
  assert.equal(f.progress, 0); assert.equal(await dbGet('read', 'OLD'), undefined, 'page de reprise et marque-pages effacés');
  assert.deepEqual(getData('homework').map(h => h.fileId), ['OLD', 'OLD'], 'le devoir créé à l\'import pointe vers l\'id d\'origine');
  assert.deepEqual(R.getRelated(Fi('OLD')).remark, [{ type: 'remark', id: 'r1', page: 17 }], 'la remarque (page 17) est toujours reliée');
  assert.equal(R.describeRelated(Fi('NEW')), '');
});
test('mergeReplacement (pur) ne touche pas aux champs inconnus', () => {
  const old: any = { id: 'A', name: 'n', type: 't', size: 1, date: 1, blob: 'b0', progress: 50, fav: true, futur: 'x' };
  assert.deepEqual(F.mergeReplacement(old, { ...old, id: 'B', blob: 'b1', size: 9, type: 'u', date: 5 } as any), { id: 'A', name: 'n', type: 'u', size: 9, date: 5, blob: 'b1', progress: 0, fav: true, futur: 'x' });
});
