/* Tests pièce 5a — logique pure de l'emploi du temps de classe (aucun navigateur). */
import test from 'node:test';
import assert from 'node:assert/strict';
import { blockAt, coveredSlots, fmtDuration, maxSpan, minutes, missingSubjects, templateEmpty, templateTA1, weeklyMinutes } from '../src/lib/timetable';

test('minutes() lit 07h15 et 7:05', () => { assert.equal(minutes('07h15'), 435); assert.equal(minutes('14h00'), 840); assert.equal(minutes('7:05'), 425); });

test('TA1 : chaque bloc couvre exactement `span` créneaux de cours (aucun ne traverse une pause)', () => {
  const tt = templateTA1();
  for (const b of tt.blocks) assert.equal(coveredSlots(tt, b).length, b.span, `${b.day} ${b.slot} ${b.subject}`);
});

test('TA1 : aucun chevauchement entre deux blocs du même jour', () => {
  const tt = templateTA1();
  for (const d of tt.days) {
    const seen = new Set<string>();
    for (const b of tt.blocks.filter(x => x.day === d)) for (const s of coveredSlots(tt, b)) { assert.ok(!seen.has(s), `${d} ${s} occupé deux fois`); seen.add(s); }
  }
});

test('TA1 : créneaux réels (55 min le matin, 60 min l\'après-midi, récréation 15 min)', () => {
  const tt = templateTA1(); const len = (id: string) => { const s = tt.slots.find(x => x.id === id)!; return minutes(s.end) - minutes(s.start); };
  assert.equal(len('M1'), 55); assert.equal(len('M6'), 55); assert.equal(len('P1'), 15); assert.equal(len('S1'), 60); assert.equal(len('P2'), 60);
});

test('TA1 : volume horaire — Philosophie = 2×110 + 110 + 110 = 7 h 20 ; Anglais = 3×55', () => {
  const v = weeklyMinutes(templateTA1());
  assert.equal(v['Philosophie'], 110 * 4);            // lun M2-M3, mar M2-M3, mer M5-M6, ven M1-M2
  assert.equal(v['Anglais'], 55 * 3);
  assert.equal(v['Espagnol'], 55 * 3);
  assert.equal(v['Mathématiques'], 110 + 110 + 55);   // lun M4-M5, mer M1-M2, jeu M5
  assert.equal(v['EPS'], 120);                        // lun S3-S4
  assert.equal(v['Étude / Devoir'], undefined);       // l'étude n'est pas une matière
  assert.equal(fmtDuration(440), '7 h 20');
});

test('maxSpan s\'arrête aux pauses et aux autres blocs', () => {
  const tt = templateTA1();
  assert.equal(maxSpan(tt, 'Mer', 'M2'), 1);          // M2 est déjà couvert par MATHS (M1-M2) → au moins 1
  assert.equal(maxSpan(tt, 'Lun', 'M3'), 1);          // M3 lundi est couvert par PHILO ; repli à 1
  const empty = templateEmpty();
  assert.equal(maxSpan(empty, 'Lun', 'M3'), 1);       // M3 puis la récréation : 1 seul créneau
  assert.equal(maxSpan(empty, 'Lun', 'M1'), 3);       // M1-M3 avant la récréation
  assert.equal(maxSpan(empty, 'Lun', 'S1'), 4);       // tout l'après-midi
});

test('blockAt retrouve un bloc fusionné depuis son 2e créneau', () => {
  const tt = templateTA1();
  assert.equal(blockAt(tt, 'Lun', 'M3')?.subject, 'Philosophie');
  assert.equal(blockAt(tt, 'Mar', 'S4')?.kind, 'etude');
  assert.equal(blockAt(tt, 'Sam', 'M1'), undefined);
});

test('3 lectures incertaines signalées ; matières manquantes = ajout seulement', () => {
  const tt = templateTA1();
  assert.equal(tt.blocks.filter(b => b.uncertain).length, 3);
  assert.deepEqual(missingSubjects(tt, ['Français', 'anglais', 'Mathématiques']).sort(), ['AP / Musique', 'EPS', 'Espagnol', 'Histoire-Géographie', 'Philosophie', 'SVT'].sort());
});
