/* Tests pièce 5b — horaires, plusieurs emplois du temps, cours du jour, export .ics (logique pure, sans navigateur). */
import test from 'node:test';
import assert from 'node:assert/strict';
import {
  addTimetable, blockTimes, blocksOfDay, dayLabelOf, duplicateTimetable, removeActive, slotInUse, switchTimetable, templateEmpty, templateTA1,
  toInput, toStored, todaysBlocks, validateSlots,
} from '../src/lib/timetable';
import { buildTimetableICS, countIcsEvents, defaultUntil, firstOnOrAfter } from '../src/lib/timetableIcs';

test('validateSlots : le modèle TA1 est valide ; fin ≤ début, chevauchement et heure illisible sont refusés', () => {
  const tt = templateTA1(); assert.equal(validateSlots(tt.slots), null);
  const bad = structuredClone(tt.slots); bad[0].end = '07h00'; assert.match(validateSlots(bad)!, /fin doit être après le début/);
  const over = structuredClone(tt.slots); over[1].start = '08h00'; assert.match(validateSlots(over)!, /commence avant la fin/);
  const nan = structuredClone(tt.slots); nan[2].start = 'abc'; assert.match(validateSlots(nan)!, /pas lisible/);
});

test('toStored / toInput : « 07:15 » ↔ « 07h15 »', () => { assert.equal(toStored('07:15'), '07h15'); assert.equal(toInput('14h00'), '14:00'); assert.equal(toInput('xx'), ''); });

test('blockTimes : PHILO du lundi (M2-M3) = 08h10–10h00 ; DEVOIR du mardi = 14h00–18h00', () => {
  const tt = templateTA1();
  const ph = tt.blocks.find(b => b.day === 'Lun' && b.subject === 'Philosophie')!; assert.deepEqual(blockTimes(tt, ph), { start: '08h10', end: '10h00' });
  const dv = tt.blocks.find(b => b.kind === 'etude')!; assert.deepEqual(blockTimes(tt, dv), { start: '14h00', end: '18h00' });
});

test('changer l\'heure d\'un créneau change la durée du bloc (la grille est recalculée, pas figée)', () => {
  const tt = templateTA1(); tt.slots.find(s => s.id === 'M2')!.end = '09h00';
  const ph = tt.blocks.find(b => b.day === 'Lun' && b.subject === 'Philosophie')!; assert.equal(blockTimes(tt, ph)!.start, '08h10');
  assert.equal(validateSlots(tt.slots), null);
});

test('blocksOfDay : lundi triés par heure ; dayLabelOf(lundi) = Lun ; jour sans cours = []', () => {
  const tt = templateTA1(); const lun = blocksOfDay(tt, 'Lun'); assert.deepEqual(lun.map(x => x.block.subject), ['Histoire-Géographie', 'Philosophie', 'Mathématiques', 'Anglais', 'EPS']);
  const starts = lun.map(x => x.start); assert.deepEqual(starts, [...starts].sort());
  const monday = new Date('2026-10-05T09:00:00'); assert.equal(dayLabelOf(monday), 'Lun'); assert.equal(todaysBlocks(tt, monday).length, 5);
  assert.deepEqual(todaysBlocks(tt, new Date('2026-10-04T09:00:00')), []); // dimanche
});

test('plusieurs emplois du temps : ajouter / changer / dupliquer / supprimer sans jamais perdre l\'actif', () => {
  const a = { ...templateTA1(), id: 'a' }, b = { ...templateEmpty(), id: 'b', name: 'Examens' };
  let st = addTimetable(a, [], b); assert.equal(st.active.id, 'b'); assert.deepEqual(st.saved.map(t => t.id), ['a']);
  const back = switchTimetable(st.active, st.saved, 'a')!; assert.equal(back.active.id, 'a'); assert.deepEqual(back.saved.map(t => t.id), ['b']);
  assert.equal(switchTimetable(st.active, st.saved, 'inconnu'), null);
  const copy = duplicateTimetable(a, 'c', 'Copie'); copy.blocks[0].subject = 'X'; assert.notEqual(a.blocks[0].subject, 'X'); assert.equal(copy.name, 'Copie');
  const rm = removeActive([a]); assert.equal(rm.active!.id, 'a'); assert.equal(rm.saved.length, 0);
  assert.deepEqual(removeActive([]), { active: null, saved: [] });
  st = addTimetable(null, [], a); assert.equal(st.saved.length, 0);
});

test('slotInUse : un créneau couvert par un bloc ne peut pas être supprimé', () => {
  const tt = templateTA1(); assert.equal(slotInUse(tt, 'M3'), true); assert.equal(slotInUse(tt, 'S1'), true); assert.equal(slotInUse(templateEmpty(), 'S1'), false);
});

test('firstOnOrAfter / defaultUntil', () => {
  assert.equal(firstOnOrAfter('2026-09-30', 1), '2026-10-05');   // mercredi 30/09 → lundi 05/10
  assert.equal(firstOnOrAfter('2026-09-30', 3), '2026-09-30');   // le jour même
  assert.equal(defaultUntil('2026-09-30'), '2027-06-30'); assert.equal(defaultUntil('2027-03-10'), '2027-06-30');
});

test('.ics TA1 : un événement par bloc, RRULE hebdo, fuseau Africa/Abidjan, rappel, CRLF, lignes ≤ 75 car.', () => {
  const tt = templateTA1(); const ics = buildTimetableICS(tt, { from: '2026-10-05', until: '2027-06-30', alarmMin: 10 });
  assert.equal(countIcsEvents(ics), tt.blocks.length);
  assert.equal((ics.match(/BEGIN:VCALENDAR/g) || []).length, 1); assert.equal((ics.match(/END:VCALENDAR/g) || []).length, 1);
  assert.equal((ics.match(/BEGIN:VEVENT/g) || []).length, (ics.match(/END:VEVENT/g) || []).length);
  assert.equal((ics.match(/BEGIN:VALARM/g) || []).length, tt.blocks.length); assert.match(ics, /TRIGGER:-PT10M/);
  assert.match(ics, /BEGIN:VTIMEZONE\r\nTZID:Africa\/Abidjan/); assert.match(ics, /RRULE:FREQ=WEEKLY;BYDAY=MO;UNTIL=20270630T235959Z/);
  assert.match(ics, /DTSTART;TZID=Africa\/Abidjan:20261005T081000\r\nDTEND;TZID=Africa\/Abidjan:20261005T100000/); // PHILO du lundi 08h10–10h00
  assert.ok(ics.endsWith('\r\n')); assert.ok(!/[^\r]\n/.test(ics.replace(/\r\n/g, '')), 'pas de LF seul');
  for (const line of ics.split('\r\n')) assert.ok(line.length <= 75, 'ligne trop longue : ' + line);
  const uids = [...ics.matchAll(/UID:(.+)\r\n/g)].map(m => m[1]); assert.equal(new Set(uids).size, uids.length);
});

test('.ics : sans rappel → aucun VALARM ; DTSTART tombe bien le jour de BYDAY ; période vide → aucun événement ; étude nommée « Étude / Devoir »', () => {
  const tt = templateTA1(); const none = buildTimetableICS(tt, { from: '2026-10-05', until: '2027-06-30', alarmMin: null }); assert.ok(!none.includes('VALARM'));
  const names: Record<string, number> = { MO: 1, TU: 2, WE: 3, TH: 4, FR: 5 };
  for (const m of none.matchAll(/DTSTART;TZID=Africa\/Abidjan:(\d{4})(\d{2})(\d{2})T\d+\r\nDTEND[^\r]*\r\nRRULE:FREQ=WEEKLY;BYDAY=(\w\w)/g))
    assert.equal(new Date(`${m[1]}-${m[2]}-${m[3]}T12:00:00`).getDay(), names[m[4]]);
  assert.equal(countIcsEvents(buildTimetableICS(tt, { from: '2026-10-05', until: '2026-10-04', alarmMin: null })), 0);
  assert.match(none, /SUMMARY:Étude \/ Devoir/); assert.match(none, /LOCATION:D'2/); assert.match(none, /DESCRIPTION:Professeur : GNABA/);
});

test('.ics : virgules et point-virgules échappés dans le nom', () => {
  const tt = templateEmpty(); tt.name = 'TA1, salle D;2'; tt.blocks.push({ id: 'x', day: 'Lun', slot: 'M1', span: 1, subject: 'Maths, algèbre', kind: 'cours' });
  const ics = buildTimetableICS(tt, { from: '2026-10-05', until: '2027-06-30', alarmMin: null });
  assert.match(ics, /X-WR-CALNAME:TA1\\, salle D\\;2/); assert.match(ics, /SUMMARY:Maths\\, algèbre/);
});
