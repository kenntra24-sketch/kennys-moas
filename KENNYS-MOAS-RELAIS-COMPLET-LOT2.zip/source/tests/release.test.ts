/* Chaîne de publication : verify-sync doit accepter l'état publié ET détecter les cassures classiques
   (fichier manquant, artefacts de builds différents, chemin absolu, SW non estampillé). */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
// @ts-ignore — module .mjs sans types
import { verify } from '../tools/verify-sync.mjs';

const repo = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..', '..');
const copy = () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'moas-'));
  fs.cpSync(repo, tmp, { recursive: true, filter: p => !/[\\/](source|docs|legacy|\.git|\.github)([\\/]|$)/.test(p.slice(repo.length)) });
  return tmp;
};

test('l\'état publié (racine) respecte tous les invariants', () => {
  const r = verify(repo); assert.deepEqual(r.fails, []); assert.ok(r.checks > 20);
});
test('détecte un fichier indispensable manquant', () => {
  const t = copy(); fs.rmSync(path.join(t, 'app.css')); assert.ok(verify(t).fails.some((f: string) => /app\.css/.test(f)));
});
test('détecte des artefacts de builds différents (app.js modifié sans restampiller sw.js)', () => {
  const t = copy(); fs.appendFileSync(path.join(t, 'app.js'), '\n/* modif */'); assert.ok(verify(t).fails.some((f: string) => /BUILD_ID/.test(f)));
});
test('détecte un Service Worker non estampillé', () => {
  const t = copy(); const p = path.join(t, 'sw.js'); fs.writeFileSync(p, fs.readFileSync(p, 'utf8').replace(/BUILD_ID = '[^']*'/, "BUILD_ID = '__BUILD_ID__'"));
  assert.ok(verify(t).fails.some((f: string) => /BUILD_ID/.test(f)));
});
test('détecte un chemin absolu dans index.html et un fichier référencé absent', () => {
  const t = copy(); const p = path.join(t, 'index.html'); fs.writeFileSync(p, fs.readFileSync(p, 'utf8').replace('./app.css', '/app.css'));
  assert.ok(verify(t).fails.some((f: string) => /chemin absolu/.test(f)));
  const t2 = copy(); fs.rmSync(path.join(t2, 'pdf.worker.min.mjs')); assert.ok(verify(t2).fails.length > 0);
});

/* ── LOT 1.1 : une seule chaîne de dépendances (pnpm + pnpm-lock.yaml), installation reproductible ── */
const copyWithSource = () => {   // racine + .github + source/package.json + source/public (le strict nécessaire à verify)
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'moas-src-'));
  fs.cpSync(repo, tmp, { recursive: true, filter: p => { const rel = p.slice(repo.length).replace(/\\/g, '/');
    if (/^\/(docs|\.git)(\/|$)/.test(rel)) return false;
    if (/^\/source\//.test(rel) && !/^\/source\/(package\.json|public(\/|$))/.test(rel)) return false;
    return true; } });
  return tmp;
};
const editJson = (file: string, fn: (o: any) => void) => { const o = JSON.parse(fs.readFileSync(file, 'utf8')); fn(o); fs.writeFileSync(file, JSON.stringify(o, null, 2)); };

test('chaîne de dépendances : l\'état livré est cohérent (pnpm exact, un seul verrou, workflows pnpm)', () => {
  const r = verify(repo); assert.deepEqual(r.fails, []);
  const pkg = JSON.parse(fs.readFileSync(path.join(repo, 'source', 'package.json'), 'utf8'));
  assert.match(pkg.packageManager, /^pnpm@\d+\.\d+\.\d+$/);
  for (const f of ['package-lock.json', 'yarn.lock', 'npm-shrinkwrap.json']) assert.equal(fs.existsSync(path.join(repo, 'source', f)), false, f);
});
test('verrou pnpm : absent = avertissement en local, ERREUR avec requireLock (CI) ; présent = accepté', () => {
  const t = copyWithSource(); const lock = path.join(t, 'source', 'pnpm-lock.yaml'); fs.rmSync(lock, { force: true });
  const local = verify(t); assert.deepEqual(local.fails, []); assert.ok(local.warnings.some((w: string) => /pnpm-lock\.yaml/.test(w)));
  assert.ok(verify(t, { requireLock: true }).fails.some((f: string) => /pnpm-lock\.yaml absent/.test(f)));
  fs.writeFileSync(lock, "lockfileVersion: '9.0'\n"); const withLock = verify(t, { requireLock: true });
  assert.deepEqual(withLock.fails, []); assert.deepEqual(withLock.warnings, []);
});
test('détecte un second verrou (package-lock.json / yarn.lock)', () => {
  for (const f of ['package-lock.json', 'yarn.lock']) { const t = copyWithSource(); fs.writeFileSync(path.join(t, 'source', f), '{}'); assert.ok(verify(t).fails.some((m: string) => m.includes(f)), f); }
});
test('détecte un packageManager absent, non-pnpm ou non exact', () => {
  for (const pm of [undefined, 'npm@10.9.7', 'pnpm@10', 'pnpm@^10.34.3']) {
    const t = copyWithSource(); editJson(path.join(t, 'source', 'package.json'), o => { if (pm === undefined) delete o.packageManager; else o.packageManager = pm; });
    assert.ok(verify(t).fails.some((m: string) => /packageManager/.test(m)), String(pm));
  }
});
test('détecte une dépendance non figée (^ ou ~)', () => {
  const t = copyWithSource(); editJson(path.join(t, 'source', 'package.json'), o => { o.devDependencies.esbuild = '^0.27.7'; });
  assert.ok(verify(t).fails.some((m: string) => /esbuild/.test(m) && /version exacte/.test(m)));
});
test('détecte un workflow qui retombe sur npm ou installe sans verrou', () => {
  const wf = (t: string) => path.join(t, '.github', 'workflows', 'build.yml'); const src = fs.readFileSync(path.join(repo, '.github', 'workflows', 'build.yml'), 'utf8');
  const a = copyWithSource(); fs.writeFileSync(wf(a), src.replace('pnpm install --frozen-lockfile', 'npm ci')); assert.ok(verify(a).fails.some((m: string) => /npm\/yarn/.test(m)));
  const b = copyWithSource(); fs.writeFileSync(wf(b), src.replace('pnpm install --frozen-lockfile', 'pnpm install')); assert.ok(verify(b).fails.some((m: string) => /frozen-lockfile/.test(m)));
  const c = copyWithSource(); fs.writeFileSync(wf(c), src.replace('pnpm install --frozen-lockfile', 'pnpm install --no-frozen-lockfile')); assert.ok(verify(c).fails.length > 0);
  const d = copyWithSource(); fs.writeFileSync(wf(d), src.replace(/.*pnpm\/action-setup@v4\n\s+with:\n\s+package_json_file:.*\n/, '')); assert.ok(verify(d).fails.some((m: string) => /pnpm\/action-setup/.test(m)));
});

/* ── LOT 1.2 : déclenchements et blocage des workflows ── */
test('workflows : un échec bloque la publication, Node exact, génération du verrou uniquement manuelle et qui lance build.yml', () => {
  const rd = (n: string) => fs.readFileSync(path.join(repo, '.github', 'workflows', n), 'utf8');
  const b = rd('build.yml'), g = rd('generer-verrou.yml');
  assert.ok(b.indexOf('verify:ci') > -1 && b.indexOf('git commit') > b.indexOf('verify:ci'), 'la publication vient après verify:ci');
  assert.ok(!/continue-on-error|\|\|\s*true/.test(b + g));
  assert.match(b, /node-version: \d+\.\d+\.\d+/); assert.match(g, /node-version: \d+\.\d+\.\d+/);
  assert.ok(!/^\s{2}(push|pull_request|schedule|workflow_run):/m.test(g), 'générer-verrou : jamais déclenché automatiquement');
  assert.match(g, /gh workflow run build\.yml/); assert.match(g, /actions: write/);
});
test('détecte : échec masqué, publication avant les tests, Node flottant, génération de verrou déclenchée par push', () => {
  const wfp = (t: string, n: string) => path.join(t, '.github', 'workflows', n); const rd = (n: string) => fs.readFileSync(path.join(repo, '.github', 'workflows', n), 'utf8');
  const a = copyWithSource(); fs.writeFileSync(wfp(a, 'build.yml'), rd('build.yml').replace('run: pnpm test', 'run: pnpm test || true')); assert.ok(verify(a).fails.some((m: string) => /continue-on-error|\|\| true/.test(m)));
  const b = copyWithSource(); fs.writeFileSync(wfp(b, 'build.yml'), rd('build.yml').replace('node-version: 22.22.2', 'node-version: 22')); assert.ok(verify(b).fails.some((m: string) => /node-version/.test(m)));
  const c = copyWithSource(); fs.writeFileSync(wfp(c, 'generer-verrou.yml'), rd('generer-verrou.yml').replace('on:\n  workflow_dispatch:', 'on:\n  push:\n  workflow_dispatch:')); assert.ok(verify(c).fails.some((m: string) => /workflow_dispatch/.test(m)));
  const d = copyWithSource(); fs.writeFileSync(wfp(d, 'generer-verrou.yml'), rd('generer-verrou.yml').replace(/gh workflow run build\.yml/, 'echo rien')); assert.ok(verify(d).fails.some((m: string) => /build\.yml/.test(m)));
  const e = copyWithSource(); const s = rd('build.yml'); fs.writeFileSync(wfp(e, 'build.yml'), s.replace(/      - name: Enregistrer si quelque chose a changé[\s\S]*$/, '') .replace('      - name: Tests', '      - name: Enregistrer si quelque chose a changé\n        run: git commit -m x\n      - name: Tests') + '      - name: Verifier plus tard\n        run: pnpm run verify:ci\n');
  assert.ok(verify(e).fails.some((m: string) => /APRÈS les tests/.test(m)));
});
