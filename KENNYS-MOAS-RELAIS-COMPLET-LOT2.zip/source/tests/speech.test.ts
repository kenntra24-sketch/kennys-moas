/* Qualité de la banque de sujets : pas de doublons, phrases complètes, questions « à débattre » bien formées (règles du Grand oral). */
import test from 'node:test';
import assert from 'node:assert/strict';
import { AFFIRMATIONS, HAND_TOPICS, NOTIONS, pickTopic } from '../src/lib/speechTopics';

test('aucun doublon, aucune phrase trop courte', () => {
  const all = [...HAND_TOPICS.map(t => t.text), ...AFFIRMATIONS, ...NOTIONS]; assert.equal(new Set(all).size, all.length);
  for (const t of HAND_TOPICS) assert.ok(t.text.length > 25, t.text);
});
test('questions à débattre : finissent par « ? », commencent par un mot interrogatif, pas de oui/non', () => {
  for (const t of HAND_TOPICS.filter(t => t.cat === 'debat')) {
    assert.match(t.text, /\?$/, t.text); assert.match(t.text, /^(En quoi|Comment|Dans quelle mesure|Pourquoi)\b/, t.text);
  }
});
test('pickTopic évite les sujets déjà vus', () => {
  const seen = HAND_TOPICS.filter(t => t.cat === 'pitch').slice(1).map(t => t.text); const only = HAND_TOPICS.filter(t => t.cat === 'pitch')[0].text;
  for (let i = 0; i < 20; i++) assert.equal(pickTopic('pitch', seen).text, only);
});
