/* Garde-fous du Service Worker : le code de l'appli ne doit jamais être servi « cache d'abord » (sinon : « vide ton cache »),
   et la version doit être estampillée automatiquement par le build. */
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const src = fs.readFileSync(new URL('../public/sw.js', import.meta.url), 'utf8');
const staticList = src.slice(src.indexOf('const STATIC'), src.indexOf('const SHELL'));

test('sw.js : le code (index.html, app.js, app.css) n\'est pas dans la liste « cache d\'abord »', () => {
  for (const f of ['index.html', 'app.js', 'app.css', 'config.local.js']) assert.ok(!staticList.includes(f), f + ' ne doit pas être en cache d\'abord');
});
test('sw.js : version automatique (marqueur __BUILD_ID__) et revalidation réseau', () => {
  assert.match(src, /BUILD_ID = '__BUILD_ID__'/);
  assert.match(src, /cache: 'no-cache'/);
  assert.match(src, /skipWaiting/); assert.match(src, /clients\.claim/);
});
test('sw.js : ne touche jamais aux données utilisateur (aucun accès IndexedDB/localStorage)', () => {
  assert.ok(!/indexedDB|localStorage/.test(src.replace(/\/\*[\s\S]*?\*\//g, '')));   // hors commentaires
});
