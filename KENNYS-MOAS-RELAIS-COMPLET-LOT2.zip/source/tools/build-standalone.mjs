/* BUILD OFFICIEL de KENNY'S MOAS (seule chaîne de production) : esbuild, sans Vite ni Tailwind.
   Produit dist/ (index.html + app.js + app.css + sw.js + fichiers de public/), ouvrable aussi en file://
   (bundle classique IIFE, pas un module ES).
   Usage : `pnpm install --frozen-lockfile` puis `pnpm run build` dans source/. Versions figées dans package.json (esbuild, react, react-dom).
   (L'ancienne chaîne Vite/Figma est archivée dans source/figma-only/ : elle ne fonctionne pas hors Figma.) */
import { build, version as esbuildVersion } from 'esbuild';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const dist = path.join(root, 'dist');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const pinned = pkg.devDependencies?.esbuild;
if (pinned && pinned !== esbuildVersion) console.warn(`⚠ esbuild ${esbuildVersion} installé, ${pinned} attendu (package.json) : le build peut différer de celui de GitHub.`);
fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(dist, { recursive: true });

// 1) JS : bundle IIFE (fonctionne en file:// et en http://)
await build({
  entryPoints: [path.join(root, 'src/main.tsx')],
  outfile: path.join(dist, 'app.js'),
  bundle: true, format: 'iife', target: 'es2020', minify: true, jsx: 'automatic',
  define: { 'import.meta.env.PROD': 'true', 'process.env.NODE_ENV': '"production"', __APP_VERSION__: JSON.stringify(pkg.version) },
  loader: { '.css': 'empty' }, // le CSS est traité séparément (main.tsx l'importe pour Vite)
  logLevel: 'info',
});

// 2) CSS : index.css sans les directives Tailwind (aucune classe utilitaire Tailwind n'est utilisée) + équivalent du « preflight »
let css = fs.readFileSync(path.join(root, 'src/index.css'), 'utf8');
css = css.replace(/@import\s+'tailwindcss';?/, '').replace(/@theme inline\s*\{[^}]*\}/, '');
const preflight = `*,*::before,*::after{box-sizing:border-box;margin:0;padding:0;border:0 solid}
html{line-height:1.5;-webkit-text-size-adjust:100%}
h1,h2,h3,h4,h5,h6{font-size:inherit;font-weight:inherit}
a{color:inherit;text-decoration:inherit}
b,strong{font-weight:bolder}
code,kbd,pre{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;font-size:1em}
table{border-collapse:collapse;border-color:inherit;text-indent:0}
button,input,select,optgroup,textarea{font:inherit;letter-spacing:inherit;color:inherit;border-radius:0;background-color:transparent;opacity:1}
button,[type=button],[type=submit]{-webkit-appearance:button;appearance:button;cursor:pointer}
button:disabled{cursor:default}
ol,ul,menu{list-style:none}
img,svg,video,canvas,audio,iframe,embed,object{display:block;vertical-align:middle}
img,video{max-width:100%;height:auto}
textarea{resize:vertical}
::placeholder{opacity:1;color:color-mix(in oklab,currentColor 50%,transparent)}
[hidden]{display:none!important}
`;
const m = css.match(/^(@import url\([^;]*\);\s*)/); // les @import doivent rester en tête
const head = m ? m[1] : '';
if (m) css = css.slice(head.length);
fs.writeFileSync(path.join(dist, 'app.css'), head + preflight + css);

// 3) HTML + fichiers statiques (public/ → dist/)
fs.cpSync(path.join(root, 'public'), dist, { recursive: true });
// config.local.js (identifiants Google, personnel, ignoré par Git) : copié depuis public/ s'il existe, sinon fichier vide (aucune 404)
if (!fs.existsSync(path.join(dist, 'config.local.js'))) fs.writeFileSync(path.join(dist, 'config.local.js'), '/* config.local.js absent : Google Drive non configuré (voir README) */\n');
const rel = (s) => s.replace(/(href|content)="\/(?!\/)/g, '$1="./');
let html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const headExtra = html.slice(html.indexOf('<!-- KENNY'), html.indexOf('</head>'));
html = `<!doctype html>
<html lang="fr">
  <head>
    <meta charset="UTF-8" />
    <title>KENNY'S MOAS</title>
    <meta name="description" content="KENNY'S MOAS — Module d'Assistance Scolaire" />
    ${rel(headExtra).replace(/^\s+/gm, '    ')}
    <link rel="stylesheet" href="./app.css" />
  </head>
  <body>
    <div id="root"></div>
    <script src="./config.local.js"></script>
    <script src="./app.js"></script>
  </body>
</html>
`;
fs.writeFileSync(path.join(dist, 'index.html'), html);
console.log('OK → dist/ (' + fs.readdirSync(dist).length + ' entrées)');

// 4) Version automatique du Service Worker : empreinte du code livré (change seulement si le code change)
{
  const crypto = await import('node:crypto');
  const h = crypto.createHash('sha256');
  for (const f of ['app.js', 'app.css', 'index.html']) h.update(fs.readFileSync(path.join(dist, f)));
  const swp = path.join(dist, 'sw.js');
  fs.writeFileSync(swp, fs.readFileSync(swp, 'utf8').replace('__BUILD_ID__', h.digest('hex').slice(0, 10)));
}
