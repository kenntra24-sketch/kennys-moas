/* make-icons.mjs — génère le logo (SVG) et toutes les icônes PNG/ICO/splash à partir d'UN seul dessin.
   Usage : NODE_PATH=<dossier des modules globaux> node tools/make-icons.mjs   (nécessite le paquet « sharp »)
   Sorties : public/logo.svg, icon*.png, icon-*-maskable.png, icon.ico, splash/splash-WxH.png (mêmes noms/tailles qu'avant). */
import sharp from 'sharp';
import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const pub = path.join(root, 'public');
const NAVY = '#24345c', FOREST = '#3f7d56', CREAM = '#f7f1e3', PAPER = '#f2ede2';

/* Le dessin : un « K » construit comme un livre ouvert (trait épais, bouts arrondis) + une pastille verte « validé ».
   Grille 512×512. `pad` = marge de sécurité (maskable : le logo doit tenir dans le cercle central de 80 %). */
const mark = (s = 1) => `<g transform="translate(256 256) scale(${s}) translate(-256 -256)" fill="none" stroke="${CREAM}" stroke-width="46" stroke-linecap="round" stroke-linejoin="round">
    <path d="M186 132v248"/><path d="M330 138 198 262l136 118"/></g>
  <circle cx="${256 + (150) * s}" cy="${256 - (128) * s}" r="${30 * s}" fill="${FOREST}" stroke="${CREAM}" stroke-width="${10 * s}"/>`;
const logoSvg = (radius = 112, s = 1) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512" role="img" aria-label="KENNY'S MOAS">
  <rect width="512" height="512" rx="${radius}" fill="${NAVY}"/>
  ${mark(s)}
</svg>`;
fs.writeFileSync(path.join(pub, 'logo.svg'), logoSvg());

const png = (svg, size) => sharp(Buffer.from(svg), { density: 384 }).resize(size, size).png({ compressionLevel: 9 }).toBuffer();
const write = (f, buf) => fs.writeFileSync(path.join(pub, f), buf);

// icônes « any » (coins arrondis), maskable (plein cadre + logo réduit à 78 %)
for (const n of [120, 152, 167, 180, 192, 512]) write(`icon-${n}.png`, await png(logoSvg(), n));
write('icon.png', await png(logoSvg(), 512));
for (const n of [192, 512]) write(`icon-${n}-maskable.png`, await png(logoSvg(0, 0.78), n));

// icon.ico : PNG intégrés 16/32/48/64/128/256
const sizes = [16, 32, 48, 64, 128, 256];
const bufs = await Promise.all(sizes.map(n => png(logoSvg(n <= 32 ? 96 : 112), n)));
const head = Buffer.alloc(6); head.writeUInt16LE(1, 2); head.writeUInt16LE(sizes.length, 4);
let off = 6 + 16 * sizes.length; const dir = [];
sizes.forEach((n, i) => { const e = Buffer.alloc(16); e[0] = n === 256 ? 0 : n; e[1] = n === 256 ? 0 : n; e.writeUInt16LE(1, 4); e.writeUInt16LE(32, 6); e.writeUInt32LE(bufs[i].length, 8); e.writeUInt32LE(off, 12); off += bufs[i].length; dir.push(e); });
write('icon.ico', Buffer.concat([head, ...dir, ...bufs]));

// splash iOS : fond papier, logo centré + nom
const splashes = ['640x1136', '750x1334', '828x1792', '1125x2436', '1170x2532', '1179x2556', '1242x2688', '1284x2778', '1290x2796'];
fs.mkdirSync(path.join(pub, 'splash'), { recursive: true });
for (const sz of splashes) {
  const [w, h] = sz.split('x').map(Number), L = Math.round(Math.min(w, h) * 0.26);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}"><rect width="${w}" height="${h}" fill="${PAPER}"/>
    <svg x="${(w - L) / 2}" y="${h / 2 - L * 0.75}" width="${L}" height="${L}" viewBox="0 0 512 512"><rect width="512" height="512" rx="112" fill="${NAVY}"/>${mark(1)}</svg>
    <text x="${w / 2}" y="${h / 2 + L * 0.55}" text-anchor="middle" font-family="Lora, Georgia, serif" font-weight="700" font-size="${Math.round(L * 0.17)}" fill="${NAVY}" letter-spacing="${Math.round(L * 0.012)}">KENNY'S MOAS</text></svg>`;
  fs.writeFileSync(path.join(pub, 'splash', `splash-${sz}.png`), await sharp(Buffer.from(svg), { density: 72 }).png({ compressionLevel: 9 }).toBuffer());
}
console.log('OK : logo.svg, icônes, icon.ico, splash générés dans', pub);
