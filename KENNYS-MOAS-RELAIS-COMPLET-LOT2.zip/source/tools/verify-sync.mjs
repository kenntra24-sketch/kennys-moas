/* verify-sync.mjs — vérifie les INVARIANTS de l'état publié (racine du dépôt), pas des textes d'interface :
   • fichiers indispensables présents ; tout fichier référencé (index.html, manifest, listes du Service Worker) existe ;
   • aucun chemin absolu (« /xxx ») qui casserait un hébergement en sous-dossier (GitHub Pages) ;
   • sw.js : BUILD_ID = empreinte réelle de index.html + app.js + app.css → les artefacts viennent du MÊME build ;
   • (si source/ présent) sw.js racine = source/public/sw.js hors BUILD_ID ; les fichiers de public/ sont identiques à ceux de la racine ;
     la version de package.json est bien dans app.js ;
   • chaîne de dépendances : UN seul gestionnaire (pnpm, version exacte dans « packageManager »), UN seul verrou officiel
     (source/pnpm-lock.yaml), aucun package-lock.json / yarn.lock, dépendances en version exacte, workflows GitHub cohérents
     (pnpm install --frozen-lockfile, aucun « npm install/ci ») ;
   • --rebuild : recompile et compare avec la racine (la racine doit être à jour avec le source) ;
   • --require-lock : l'absence de source/pnpm-lock.yaml devient une ERREUR (utilisé par la CI) ; sans cette option, simple avertissement.
   Usage : node tools/verify-sync.mjs [dossier-racine] [--rebuild] [--require-lock]   (code de sortie 1 en cas d'échec) */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';

const REQUIRED = ['index.html', 'app.js', 'app.css', 'sw.js', 'manifest.webmanifest', 'config.local.js', 'pdf.min.mjs', 'pdf.worker.min.mjs'];
const sha = (buf) => crypto.createHash('sha256').update(buf).digest('hex');
const walk = (dir, base = dir) => fs.readdirSync(dir, { withFileTypes: true }).flatMap(e => e.isDirectory() ? walk(path.join(dir, e.name), base) : [path.relative(base, path.join(dir, e.name))]);

export function buildIdOf(root) {
  const h = crypto.createHash('sha256');
  for (const f of ['app.js', 'app.css', 'index.html']) h.update(fs.readFileSync(path.join(root, f)));
  return h.digest('hex').slice(0, 10);   // même calcul que tools/build-standalone.mjs
}

export function verify(root, { rebuild = false, requireLock = false } = {}) {
  const fails = [], warnings = []; let checks = 0; const ok = (c, msg) => { checks++; if (!c) fails.push(msg); };
  const P = (f) => path.join(root, f), has = (f) => fs.existsSync(P(f));

  for (const f of REQUIRED) ok(has(f), `fichier indispensable absent : ${f}`);
  if (fails.length) return { fails, checks, warnings };      // inutile d'aller plus loin sans les fichiers de base

  // index.html : références présentes, pas de chemin absolu
  const html = fs.readFileSync(P('index.html'), 'utf8');
  for (const m of html.matchAll(/(?:src|href)="([^"]+)"/g)) {
    const u = m[1]; if (/^(https?:|data:|mailto:|#|\/\/)/.test(u)) continue;
    ok(!u.startsWith('/'), `index.html : chemin absolu « ${u} » (casse GitHub Pages en sous-dossier)`);
    ok(has(u.replace(/^\.\//, '').split(/[?#]/)[0]), `index.html référence un fichier absent : ${u}`);
  }

  // manifest
  let mf = null; try { mf = JSON.parse(fs.readFileSync(P('manifest.webmanifest'), 'utf8')); } catch { ok(false, 'manifest.webmanifest : JSON invalide'); }
  if (mf) {
    for (const k of ['start_url', 'scope']) ok(!String(mf[k] ?? '.').startsWith('/'), `manifest : ${k} absolu « ${mf[k]} »`);
    for (const i of mf.icons || []) ok(has(String(i.src).replace(/^\.\//, '')), `manifest : icône absente ${i.src}`);
  }

  // Service Worker : même build + listes de fichiers valides
  const sw = fs.readFileSync(P('sw.js'), 'utf8');
  const id = (sw.match(/const BUILD_ID = '([^']*)'/) || [])[1];
  ok(/^[0-9a-f]{10}$/.test(id || ''), `sw.js : BUILD_ID invalide ou non estampillé (« ${id} »)`);
  ok(id === buildIdOf(root), `sw.js : BUILD_ID ${id} ≠ empreinte du code ${buildIdOf(root)} (index.html/app.js/app.css/sw.js ne viennent pas du même build)`);
  for (const [name, re] of [['STATIC', /const STATIC = \[([\s\S]*?)\]\.map/], ['SHELL', /const SHELL = \[([\s\S]*?)\]\.map/]]) {
    const body = (sw.match(re) || [])[1]; ok(!!body, `sw.js : liste ${name} introuvable`);
    for (const m of (body || '').matchAll(/'([^']+)'/g)) if (m[1] !== './') ok(has(m[1]), `sw.js ${name} : fichier absent ${m[1]}`);
  }

  // Cohérence avec le source (si présent)
  if (has('source/public/sw.js')) {
    const src = fs.readFileSync(P('source/public/sw.js'), 'utf8');
    ok(sw.replace(/const BUILD_ID = '[^']*'/, "const BUILD_ID = '__BUILD_ID__'") === src, 'sw.js racine ≠ source/public/sw.js (hors BUILD_ID)');
    for (const f of walk(P('source/public'))) {
      if (f === 'sw.js') continue;
      ok(has(f) && sha(fs.readFileSync(P(f))) === sha(fs.readFileSync(P('source/public/' + f))), `source/public/${f} absent ou différent à la racine`);
    }
    if (has('source/package.json')) {
      const v = JSON.parse(fs.readFileSync(P('source/package.json'), 'utf8')).version;
      ok(fs.readFileSync(P('app.js'), 'utf8').includes(v), `la version ${v} (package.json) n'est pas dans app.js : racine pas à jour`);
    }
    // Chaîne de dépendances : un seul gestionnaire, un seul verrou, versions exactes, workflows cohérents
    if (has('source/package.json')) {
      const pkg = JSON.parse(fs.readFileSync(P('source/package.json'), 'utf8'));
      ok(/^pnpm@\d+\.\d+\.\d+$/.test(pkg.packageManager || ''), `source/package.json : « packageManager » doit fixer pnpm à une version exacte (ex. pnpm@10.34.3) ; trouvé « ${pkg.packageManager} »`);
      for (const sect of ['dependencies', 'devDependencies']) for (const [n, v] of Object.entries(pkg[sect] || {})) ok(/^\d+\.\d+\.\d+(-[\w.]+)?$/.test(v), `source/package.json : ${n} « ${v} » n'est pas une version exacte`);
      for (const f of ['package-lock.json', 'npm-shrinkwrap.json', 'yarn.lock']) for (const d of ['source/', '']) ok(!has(d + f), `${d}${f} : second verrou interdit (le seul verrou officiel est source/pnpm-lock.yaml)`);
      if (has('source/pnpm-lock.yaml')) ok(true, '');
      else if (requireLock) ok(false, 'source/pnpm-lock.yaml absent : installation non reproductible (lance le workflow « Générer le verrou pnpm », puis commite le fichier)');
      else warnings.push('source/pnpm-lock.yaml absent : installation non reproductible tant qu\'il n\'est pas généré et commité');
      if (has('.github/workflows')) for (const f of fs.readdirSync(P('.github/workflows')).filter(n => /\.ya?ml$/.test(n))) {
        const txt = fs.readFileSync(P('.github/workflows/' + f), 'utf8').split('\n').filter(l => !l.trim().startsWith('#')).join('\n');
        ok(!/\b(npm|yarn)\s+(ci|install|i|add|run|test)\b/.test(txt), `.github/workflows/${f} : « npm/yarn » interdit (gestionnaire officiel : pnpm)`);
        ok(!/--no-frozen-lockfile|--no-package-lock|--lockfile=false/.test(txt), `.github/workflows/${f} : installation sans verrou interdite`);
        if (/pnpm\s+install/.test(txt) && !/--lockfile-only/.test(txt)) ok(/pnpm install --frozen-lockfile/.test(txt), `.github/workflows/${f} : « pnpm install » doit être « pnpm install --frozen-lockfile »`);
        ok(!/continue-on-error|\|\|\s*true/.test(txt), `.github/workflows/${f} : « continue-on-error » / « || true » interdits (un échec doit bloquer)`);
        if (/setup-node/.test(txt)) ok(/node-version:\s*['"]?\d+\.\d+\.\d+['"]?\s*$/m.test(txt), `.github/workflows/${f} : node-version doit être exacte (ex. 22.22.2)`);
        if (f === 'generer-verrou.yml') {
          ok(/workflow_dispatch/.test(txt) && !/^\s{2}(push|pull_request|schedule|workflow_run):/m.test(txt), `.github/workflows/${f} : doit rester déclenché uniquement à la main (workflow_dispatch)`);
          ok(/gh workflow run build\.yml/.test(txt) && /actions:\s*write/.test(txt), `.github/workflows/${f} : doit lancer explicitement build.yml (le commit du GITHUB_TOKEN ne le déclenche pas)`);
        }
        if (f === 'build.yml') { const iv = txt.indexOf('verify:ci'), ic = txt.indexOf('git commit'); ok(iv > -1 && ic > iv, '.github/workflows/build.yml : la publication (git commit) doit venir APRÈS les tests et verify:ci'); }
        if (f === 'build.yml') ok(/pnpm\/action-setup@/.test(txt) && /pnpm install --frozen-lockfile/.test(txt), '.github/workflows/build.yml : doit installer pnpm (pnpm/action-setup) puis « pnpm install --frozen-lockfile »');
      }
    }
    if (rebuild) {
      try { execFileSync(process.execPath, ['tools/build-standalone.mjs'], { cwd: P('source'), stdio: 'pipe' }); } catch (e) { ok(false, 'recompilation impossible : ' + String(e.message).split('\n')[0]); }
      for (const f of ['index.html', 'app.js', 'app.css', 'sw.js']) {
        const d = P('source/dist/' + f); ok(fs.existsSync(d) && sha(fs.readFileSync(d)) === sha(fs.readFileSync(P(f))), `${f} racine ≠ recompilation du source (racine pas à jour, ou esbuild différent de package.json)`);
      }
    }
  }
  return { fails, checks, warnings };
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  const args = process.argv.slice(2); const root = path.resolve(args.find(a => !a.startsWith('--')) || path.join(path.dirname(new URL(import.meta.url).pathname), '..', '..'));
  const { fails, checks, warnings } = verify(root, { rebuild: args.includes('--rebuild'), requireLock: args.includes('--require-lock') });
  console.log(`verify-sync sur ${root}`);
  for (const w of warnings) console.log('  ⚠ ' + w);
  console.log(fails.length ? fails.map(f => '  ✗ ' + f).join('\n') : `  ✓ ${checks} invariants vérifiés`);
  process.exit(fails.length ? 1 : 0);
}
